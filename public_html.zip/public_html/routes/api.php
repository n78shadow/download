<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['namespace' => 'api'], function () {
//categores api routes
    Route::apiResource('categories', 'CategoryController');
    Route::apiResource('tasting', 'TastingController');

//orders api routes
    Route::apiResource('orders', 'OrderController');

    Route::post('order/{id}/addDetails', 'OrderController@addDetails');

    Route::post('order/switch', 'OrderController@SwitchServiceStatus');
    Route::post('order/items/serve', 'OrderController@ServeItems');
    Route::post('order/services/merge', 'OrderController@MergeServices');
    Route::post('order/reOrdering', 'OrderController@ReOrderSequences');
    Route::post('order/reSequence', 'OrderController@reSequence');
    Route::post('order/transfer', 'ItemController@transferItem');
    Route::post('order/changeStatus', 'OrderController@ChangeStatus');
    Route::get('order/payment/request/{order_id}', 'OrderController@request_direct_payment');
    Route::get('order/split_by_client/request/{order_id}', 'OrderController@request_split_by_client_info');
    Route::get('order/equal_split/request/{order_id}/{split_value}', 'OrderController@request_equal_split_info');
    Route::get('order/single_invoice/request/{order_id}', 'OrderController@request_invoice_info');
    Route::get('order/request/combine', 'OrderController@request_combine_data');
    Route::post('order/split_by_clients', 'OrderController@directClientsSplit');
    Route::post('order/equal_split', 'OrderController@directEqualSplit');
    Route::post('order/custom_split', 'OrderController@directCustomSplit');
    Route::post('order/printer', 'OrderController@attachPrinter');
    Route::post('order/waiter', 'OrderController@changeWaiter');
    Route::post('payment/direct', 'OrderController@directPayment');
    Route::post('order/try_to_enter', 'OrderController@visitOrder');
    Route::post('order/leaving', 'OrderController@leavingOrder');
    Route::post('order/flip', 'OrderController@flipNotification');
    Route::post('order/refund', 'InvoiceController@reFundOrderItems');

    Route::apiResource('orderDetails', 'OrderDetailsController');
    Route::delete('order/{id}/delete/details', 'OrderDetailsController@deleteDetails');


//items api routes
    Route::apiResource('items', 'ItemController');
    Route::get('items/customizes/{id}', 'ItemController@ItemCustomizes');


//invoice api routes
    Route::apiResource('invoices', 'InvoiceController');
    Route::post('invoice/eq_split', 'InvoiceController@equal_split')->name('invoices.equal_split');
    Route::post('invoice/split_by_clients', 'InvoiceController@split_by_clients')->name('invoices.split_by_client');
    Route::post('invoice/custom_split', 'InvoiceController@custom_split')->name('invoices.custom_split');
    Route::post('invoice/combine', 'InvoiceController@combine');
    Route::post('invoice/direct_store_by_client', 'InvoiceController@storeByClients')->name('invoices.orders.split_by_client');
    Route::post('invoice/store_by_equal_split', 'InvoiceController@storeByEqualSplit')->name('invoices.order.equal_split');
    Route::post('invoice/store_by_custom_split', 'InvoiceController@storeByCustomSplit')->name('invoices.order.custom_split');
    Route::post('invoice/split/undo', 'InvoiceController@undoLastSplit');
    Route::post('invoice/print/reciept', 'InvoiceController@printInvoice');
    Route::post('invoice/reprint', 'InvoiceController@rePrint');
    Route::post('invoice/print/duplicate', 'InvoiceController@duplicatePrint');
    Route::post('invoice/resend', 'InvoiceController@reSend');
    Route::post('invoice/refund', 'InvoiceController@reFund');
    Route::post('invoice/items/refund', 'InvoiceController@reFundItems');
    Route::post('invoice/repay', 'InvoiceController@rePay');
    Route::post('invoice/cancel', 'InvoiceController@cancel');
    Route::post('invoice/fix', 'InvoiceController@fixDetails');
    Route::get('invoice/split_by_client/request/{invoice_id}', 'InvoiceController@request_split_by_client_info');
    Route::get('invoice/equal_split/request/{invoice_id}/{split_value}', 'InvoiceController@request_equal_split_info');
    Route::get('invoice/single_invoice/request/{invoice_id}', 'InvoiceController@request_invoice_info');

    Route::post('invoice/print/reciept', 'InvoiceController@printInvoice');


//payment api routes
    Route::apiResource('payments', 'PaymentGatewayController');


    Route::apiResource('deliveries', 'DeliveryController');

//auth
    Route::post('login', 'UserController@login');
    Route::post('auth/access', 'UserController@checkAccessToken');
    Route::post('auth/register', 'UserController@registerClient');
    Route::get('check/customer/{phone}', 'CustomerController@checkCustomer');
    Route::get('waiters',function (){
        return getWaiters();
    });




//punch
    Route::post('punchIn', 'PunchController@punchIn')->name('punch.in');
    Route::post('punchOut', 'PunchController@punchOut')->name('punch.out');
    Route::post('print/logins', 'PunchController@printPunchLog')->name('punch.print');

    Route::get('printers',function (){
        $branch = \App\models\Branch::getByToken(request()->client_token);
        return getPrinters($branch->id);
    });

    Route::post('category/attach/printer','CategoryController@attach_printer')->name('category.attach.printer');



    Route::get('/test',function(){
        \App\models\User::getWaiters();
    });

});



