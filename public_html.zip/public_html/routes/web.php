<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


use App\models\Product;
use App\models\Tasting;

Route::get('/','HomeController@index');
Route::get('/home','HomeController@index');
Auth::routes();

//Admin Routes
Route::group( [ 'prefix' => 'admin',  'middleware' => ['auth','rbac:is,administrator']], function()
{
    Route::get('/', function () {
        return view('admin.dashboard');
    })->name('admin.dashboard');
    Route::resource('clients','admin\ClientController');
    Route::get('branches/{id}','admin\ClientController@showBranche')->name('clients.showbranch');
    Route::get('branches/printers/{id}','admin\BranchController@printers')->name('branch.printers');
    Route::put('branches/printersUpdate/{id}','admin\BranchController@updatePrinters')->name('branch.printers.update');
    Route::resource('taxes','admin\TaxController');
    Route::post('user/branch','admin\UserController@store')->name('admin.assign.branch');
    /*Route::resource('roles','admin\RoleController');
    Route::resource('permissions','admin\PermissionController');
    Route::post('roles/permission/delete','admin\RoleController@detachPermession')->name('roles.permission.delete');
    Route::post('roles/permission/add','admin\RoleController@attachPermession')->name('roles.permission.attach');
    Route::get('roles/permissions/search','admin\RoleController@searchPermessions')->name('roles.permissions.search');
    Route::get('roles/kitchens/users','admin\RoleController@kitchensRoles')->name('admin.roles.kitchens');
    Route::get('roles/kitchens/update/{id}','admin\RoleController@kitchensRolesUpdate')->name('admin.roles.kitchensupdate');
    Route::get('roles/kitchens/search/','admin\RoleController@search')->name('roles.kitchens.search');
    Route::post('roles/kitchens/save','admin\RoleController@saveKitchens')->name('roles.kitchens.add');
    Route::post('roles/kitchens/remove','admin\RoleController@removeKitchen')->name('roles.kitchens.delete'); */
    Route::resource('branches','admin\BranchController');

    Route::put('change/password','admin\UserController@changePassword')->name('admin.password.change');

});

//


//Clients Routes
Route::group(['prefix' => 'clients' , 'middleware' => ['auth','rbac:can,login']],function(){
    // Categories Routes
    Route::group(
        [
            'middleware' => ['auth', 'rbac:can,category_admin']
        ], function () {
        Route::resource('categories','clients\CategoryController');
        Route::post('categories/attach/product','clients\CategoryController@addItem')->name('categories.attach.item');
        Route::post('categories/reordering/product','clients\CategoryController@ReOrderingCategoryProductsSequences')->name('categories.reorder.items');
        Route::post('categories/delete/product','clients\CategoryController@deleteProduct')->name('categories.delete.item');
        Route::post('categories/attach/subcategoy','clients\CategoryController@addSubCategory')->name('categories.attach.subcategory');
        Route::post('categories/products/reOrder','clients\CategoryController@reOrderProducts')->name('categories.reOrder.products');
    });

    // Tasting Routes
    Route::group(
        [
            'middleware' => ['auth', 'rbac:can,tasting_admin']
        ], function () {
        Route::resource('tastingCategories','clients\TastingController');
        Route::post('tastingCategories/createItem/{id}','clients\TastingController@saveTastItem')->name('tastingcategories.add.basic');
        Route::get('tastingCategories/getItem/{id}','clients\TastingController@getTastingData')->name('tastingcategories.get.data');
        Route::post('tastingCategories/updateItem/{id}/{tastingId}','clients\TastingController@updateTastingData')->name('tastingcategories.update.data');
        Route::post('tastingCategories/updateRplaceItem/{id}/{tastingId}','clients\TastingController@updateTastingReplace')->name('tastingcategories.update.replace');
        Route::post('tastingCategories/deleteTastingItem','clients\TastingController@deleteTastingItem')->name('tastingcategories.delete.item');
        Route::post('tastingCategories/deleteTastingReplace','clients\TastingController@deleteTastingReplace')->name('tastingcategories.delete.replace');
    });

    // Product Routes
    Route::group(
        [
            'middleware' => ['auth', 'rbac:can,items_admin']
        ], function () {
        Route::resource('items','clients\ProductController');
        Route::post('items/removeBasic','clients\ProductController@removeBasic')->name('items.remove.basic');
        Route::post('items/removeOption','clients\ProductController@removeOptional')->name('items.remove.optional');
        Route::resource('customizes','clients\CustomizeController');
        Route::delete('customizes/remove/customize','clients\CustomizeController@removeItem')->name('customizes.remove.item');
        Route::resource('customizeGroups','clients\CustomizeGroupController');
    });

    Route::get('search/items','clients\ProductController@search')->name('items.search');
    Route::get('search/category','clients\CategoryController@search')->name('categories.search');

    Route::get('/',function(){
        $branch_name = \App\models\Branch::findOrFail(\Illuminate\Support\Facades\Auth::user()->branch_id)->branch_name;
        $user = \App\models\User::findOrFail(\Illuminate\Support\Facades\Auth::user()->id);
        return view('clients.dashboard', ['branch_name' => $branch_name, 'user' => $user]);
    })->name('clients.sitemap');
    Route::view('/dashboard','clients.dashboard')->name('clients.dashboard');
    //Route::view('/category','clients.categories')->name('clients.categories');

    Route::get('/preperation',[
        'uses' => 'HomeController@preperation',
        'middleware' => ['auth', 'rbac:can,kitchen']
    ])->name('clients.preperation');

    Route::get('/supervisor',[
        'uses' => 'HomeController@supervisor',
        'middleware' => ['auth', 'rbac:can,supervisor']
    ])->name('clients.supervisor');

    Route::view('/pos','clients.pos')->name('clients.pos');

    // User Routes
    Route::group(
        [
            'middleware' => ['auth', 'rbac:can,users_admin']
        ], function () {
        Route::resource('/users','clients\UserController');
        Route::post('/users/active/user','clients\UserController@activeUser')->name('users.change.status');
        Route::get('/search/users','clients\UserController@search')->name('users.search');
        Route::get('/search/xmlBillPrint','clients\UserController@xmlBillPrint');
        Route::get('/invoice/download','clients\UserController@downloadInvoice');
        Route::get('/invoice/doDownload','clients\UserController@doDownloadInvoice')->name('download.invoice');

        Route::resource('roles','clients\RoleController');
        Route::resource('permissions','clients\PermissionController');
        Route::post('roles/permission/delete','clients\RoleController@detachPermession')->name('roles.permission.delete');
        Route::post('roles/permission/add','clients\RoleController@attachPermession')->name('roles.permission.attach');
        Route::get('roles/permissions/search','clients\RoleController@searchPermessions')->name('roles.permissions.search');
        Route::get('roles/kitchens/users','clients\RoleController@kitchensRoles')->name('roles.kitchens');
        Route::get('roles/kitchens/update/{id}','clients\RoleController@kitchensRolesUpdate')->name('admin.roles.kitchensupdate');
        Route::get('roles/kitchens/search/','clients\RoleController@search')->name('roles.kitchens.search');
        Route::post('roles/kitchens/save','clients\RoleController@saveKitchens')->name('roles.kitchens.add');
        Route::post('roles/kitchens/remove','clients\RoleController@removeKitchen')->name('roles.kitchens.delete');
    });

    // Reports Routes
    Route::group(
        [
            'middleware' => ['auth', 'rbac:can,reports']
        ], function () {
        Route::get('/reports/index',function(){
            return view('clients.reports.sitemap');
        })->name('reports.index');
        Route::get('/reports/punchInOut',function(){
            return view('clients.reports.punchInOut');
        })->name('reports.punchInOut');

        Route::get('/reports/invoice',function(){
            return view('clients.reports.invoicereport');
        })->name('reports.invoice');

        Route::get('/report/sales','clients\ReportsController@sales_by_shift')->name('reports.sales');
        Route::get('/report/invoices','clients\ReportsController@invoicesReport')->name('reports.invoices');
        Route::get('/report/punchInReport','clients\ReportsController@punchInReport')->name('reports.punchIn');
        Route::get('/report/summeryReport','clients\ReportsController@summeryReport')->name('reports.summeryReport');
        Route::resource('punches','clients\PunchController');
        Route::post('/punches/update/time','clients\PunchController@updatePunch')->name('punch.update.time');
    });

    Route::resource('printers', 'clients\PrinterController')->middleware(['auth', 'rbac:can,printers']);
    Route::post('printers/kitchen', 'clients\PrinterController@storeKitchenPrinter')->name('printers.kitchen.store')->middleware(['auth', 'rbac:can,printers']);


    Route::get('/punch',function(){
        return view('clients.punchInOut');
    })->name('punch')->middleware(['auth', 'rbac:can,punch']);
});


Route::get('/test',function(){
dd(env('APP_REMOTE_URL'));
    dd( $url = \Storage::disk('public_products')->url('upos_damas/H1u7HXtMEF8PPUhfc2h4U0880vmN0ugUhYHpSkE6.png'));
});







