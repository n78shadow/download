

const allcats = {
    props:['renderOther'],
    data: function () {
      return {
        count: 0
      }
    },
    methods:{
        

    },
    template: '#allCtgs'
  };

  module.exports = allcats;