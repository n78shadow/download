const URL = require('./config');
const masonry = require('./masonry');


const serviceComponent = {
    props:['service','index','tasting','bar','type','invoice','hold'],

    data(){
      
        return {
               
                showService:true,
                layout:masonry.bind(this)
                
             
        }
       
    },

    mounted(){
        
         if(this.service.products.length == 0){
             this.showService = false;
         }   
        
         
    },
    // activated(){
    //     console.log('service activated',this.service.service_number,this.invoice.table_number);
    // },
    // deactivated(){
    //     console.log('service deactivated',this.service.service_number,this.invoice.table_number); 
    // },
    
    watch:{
        // showService(current,old){
        //         console.log('service changed visi');;
        //         this.$emit('visibiltyChanged');
        // },
        // showall(val,oldval){
        //     this.$emit('visibiltyChanged');
        // },
        // hidestation(val,oldval){
        //     this.$emit('visibiltyChanged');
        // },
        // '$store.state.visibiltiy.showall':function(val,oldval){
        //     console.log('showall changed',val,oldval);
        //     if(!val){
        //         if(this.service.service_status != 'Called'){
        //             this.showall = false;
        //         }else if(this.isAllServed){
        //             this.showall = false;
        //         }
        //     }else{
        //         this.showall = true;
        //     }
       

        // },
        // '$store.state.visibiltiy.hideStation':function(val,oldval){
        //     console.log('hidestation changed',val,oldval);
        //     if(val){
        //         this.shouldServiceHide();
        //     }else{
        //         this.hidestation = false;
        //     }
        // },
        // '$store.state.Called':function(val,oldval){
        //     console.log('called changed');
        //     this.shouldServiceHide();
        // }


    },
    updated(){
       
        this.layout();

        if(this.service.products.length == 0){
            this.showService = false;
        } 

    },
    beforeUpdate(){
        
    },
    computed:{
        srv(){
            return JSON.parse(JSON.stringify(this.service));
        },

        srvShowAll(){
            let showall = this.$store.state.visibiltiy.showall;
            if(!showall){
                if(this.service.service_status != 'Called'){
                    return false;
                }else if(this.isAllServed){
                    return false;
                }
            }
            return true;

        },

        hideStation(){
            let hidestation = this.$store.state.visibiltiy.hideStation;
            if(hidestation){
                if(this.isAllServedKitchen ){
                    return  false;
                }else if(this.service.service_status != 'Called'){
                    return false;
                }else{
                    return true;
                }
            }
            return true;
        },



        isServiceVisible(){
            
                let currentTab = this.$store.state.currentTab;
                
                if(currentTab != 'called'){
                    
                    return true;
                }
                let serviceVisible = this.srvShowAll && this.showService;
                this.$emit('visibiltyChanged');
                return serviceVisible;
        },

        isServiceVisibleKitchen(){
            let serviceVisible = this.hideStation && this.showService;
            this.$emit('visibiltyChanged');
            return serviceVisible;

        },
        
        
        isInnerSuper:function(){
            let roles = this.$store.state.user.roles;
            let s_super = roles.filter(role=>role.slug === 's-super');
            if(s_super.length){
                return true;
            }
            return false;

        },

        isAllServed(){
            let products = this.srv.products;
            let ifall = true;
            for(var i=0;i<products.length;i++){
                let product = products[i];
                if(product.isServed.length != product.dish_number.length){
                    ifall = false;
                    break;
                }
            }
           
            
            return ifall;
            
        },
        isAllReady(){
            let products = this.srv.products;
            let ifall = true;
            for(var i=0;i<products.length;i++){
                let product = products[i];
                if(product.isReady.length != product.dish_number.length){
                    ifall = false;
                    break;
                }
            }
           
            
            return ifall;
        },
        isAllServedKitchen(){
            
            let products = this.myProducts;
            let ifall = true;
            for(var i=0;i<products.length;i++){
                let product = products[i];
                if(product.isServed.length != product.dish_number.length && product.isReady.length != product.dish_number.length){
                    ifall = false;
                    break;
                }
            }
           
            
            return ifall;
        },
        
        myProducts(){

            let products = this.srv.products.filter(product=>{
                    
                    return this.$store.getters.myProduct(this.tasting,product);
            });
            return products;
        },
        status(){
            return this.service.service_status === 'Called';
        }




        
    },
    methods:{


        visibiltyChanged(){
            //console.log('visibilty changed');
            let isAllChildHidden = 0
            let children = this.$children;
            let page  = this.$store.state.page;
             
            for(var i=0;i<children.length;i++){
                let child = children[i];
                if(page === 'supervisor'){
                    if(!child.canSee || !child.hideOrNot){
                        isAllChildHidden ++;
                    }
                }else{
                    if(!child.canSee){
                        isAllChildHidden ++;
                    }
                }
                
                

            }

            if(isAllChildHidden === children.length){
                this.showService = false;
            }else{
                this.showService = true;
            }
                

        },

        confirm(intend,callback){
            this.$dialog
            .confirm(`Are you sure ${intend} #srv-${this.service.service_number} on Table: ${this.invoice.table_number} `)
            .then(function (dialog) {
               // console.log('Clicked on proceed');
                callback();
            })
            .catch(function () {
                //console.log('Clicked on cancel');
            });
        },
      

        
        reOrder:function(){
           
           
            this.$store.dispatch('getIndexes',this.invoice).then(indexs=>{
                let { calledIndex, tobecalledIndex, servedIndex } = indexs;
                // copy
                let Called = JSON.parse(JSON.stringify(this.$store.state.Called));
                if(calledIndex != -1){
                    Called.splice(calledIndex,1);
                    Called.push(this.invoice);
                }else{
                    //other stuff here
                Called.push(this.invoice)
                }

                

                this.$store.dispatch('prepareReOrderData',Called);




                



            }).catch(err=>{console.log(err)});
            


        },
        // serviceCalled_deprecated(reorder){
                
        
        //     //local update
        //     //copy
        //     let service_number = this.service.service_number;
        //     if(this.hold){
        //         return;
        //     }
        //     var oldInvoice = JSON.parse(JSON.stringify(this.invoice));
        //     var newInvoice = JSON.parse(JSON.stringify(this.invoice));
        //     newInvoice[this.type] = newInvoice[this.type].map(srv=>{
        //             if(srv.service_number === service_number){
        //                 srv.service_status = srv.service_status === "Called" ? "ToBeCall":"Called";
        //                 if(srv.service_status === "Called"){
        //                     srv.call_date = Date.now();
        //                 }

        //                 return srv;
        //             }
        //             return srv;

        //     });

        //     if(reorder){
        //        this.reOrder();

        //     }
           
            

        //     var requestInfo = {
        //         order_id:this.invoice.id,
        //         service_number,
        //         isTasting: this.tasting
        //     };

            

        //     let data = {
        //         oldInvoice,
        //         newInvoice,
        //         url:`${URL}api/order/switch`,
        //         requestType:'post',
        //         requestInfo,
        //         type:this.type,
        //         order_id:this.invoice.id,
        //         t:this
                

        //     }


        //    //request
        //     this.$store.dispatch('requestAPI',data);

        //     //    call service local
        //     this.$store.dispatch('IOupdateInvoice',{data:newInvoice,reorder:reorder,merge:false});
        //     //event

        //     //io.emit("updateinvoices",JSON.stringify({data:newInvoice,reorder:reorder,merge:false})); 
        //     this.$socket.emit('updateinvoices', JSON.stringify({data:newInvoice,reorder:reorder,merge:false}));
        // },


        // ServeItemsLocal_deprecated(uniqueIds){
               
        //         let service_number = this.service.service_number;
        //         if(this.hold){
        //             return;
        //         }
        //         //copy
        //         let oldInvoice = JSON.parse(JSON.stringify(this.invoice));
        //         let newInvoice = JSON.parse(JSON.stringify(this.invoice));
        //         newInvoice[this.type] = newInvoice[this.type].map(srv=>{
        //             if(srv.service_number === service_number){
        //                  srv.products = srv.products.map(prod=>{
        //                     if(uniqueIds.includes(prod.unique_id)){
                                
        //                         if(this.isInnerSuper){
        //                             if(prod.isServed === '0' ){
        //                                 prod.isServed = '1';
        //                             }else if(prod.isServed === '1'){
        //                                 prod.isServed = '0';
        //                             }
        //                         }else{
        //                             if(prod.isServed === '0' || prod.isServed === '1'){
        //                                 prod.isServed = '2';
        //                                 prod.served_date = {date:Date.now()}
        //                             }else{
        //                                 prod.isServed = '0';
        //                             }
        //                         }

        //                         return prod;
        //                     }
        //                     return prod;
        //                 });
                        
        //                 return srv;
        //             }
        //             return srv;
        //         });

               
        //         var requestInfo = {
        //             unique_ids:uniqueIds,
        //             user_id:this.$store.state.user.id
        //         };

                

        //         let data = {
        //             oldInvoice,
        //             newInvoice,
        //             url:`${URL}api/order/items/serve`,
        //             requestType:'post',
        //             requestInfo:requestInfo,
        //             type:this.type,
        //             order_id:this.invoice.id,
        //             t:this
    
        //         }
        //         //request
        //     //axios.post(`${URL}api/order/items/serve`,requestInfo).then(res=>{}).catch(err)
        //     this.$store.dispatch('requestAPI',data);

            
        // //    serve items local
        //     this.$store.dispatch('IOupdateInvoice',{data:newInvoice,reorder:false,merge:false})
        //      //event
        //    // io.emit("updateinvoices",JSON.stringify({data:newInvoice,reorder:false,merge:false})); 
        //    this.$socket.emit('updateinvoices', JSON.stringify({data:newInvoice,reorder:false,merge:false}));

        // },

        serviceCalled(reorder){
            if(this.hold){
                return;
            }
            let token = this.$store.state.token;

            let service_number = this.service.service_number;
            
                let data = {
                    service_number,
                    order_id:this.invoice.id,
                    type:this.type,
                    reorder,
                    token
                }

                if(reorder){
                    this.reOrder();
     
                 }

                var requestInfo = {
                    order_id:this.invoice.id,
                    service_number,
                    isTasting: this.tasting
                };

                let requestData = {
                    oldInvoice:null,
                    newInvoice:null,
                    url:`${URL}api/order/switch`,
                    requestType:'post',
                    requestInfo,
                    type:this.type,
                    order_id:this.invoice.id,
                    t:this
                    
    
                }



            //request
            this.$store.dispatch('requestAPI',requestData);

            // local
            //this.$store.dispatch('call_service',data);
            //event 
            this.$socket.emit('call_service',JSON.stringify(data));
        },

        ServeItemsLocal(uniqueIds){
            if(this.hold){
                return;
            }
            let service_number = this.service.service_number;
            let type = this.type;
            let order_id = this.invoice.id;
            let newInvoice = JSON.parse(JSON.stringify(this.invoice));
            let token = this.$store.state.token;
            let serv_info = {};
            // 
             newInvoice[this.type].map(srv=>{
                    if(srv.service_number === service_number){
                        let products = srv.products;
                         for(var i=0;i< products.length;i++){
                             let prod = products[i];
                             if(uniqueIds.includes(prod.unique_id)){

                                if(this.isInnerSuper){
                                    if(prod.isServed === '0' ){
                                        prod.isServed = '1';
                                    }else if(prod.isServed === '1'){
                                        prod.isServed = '0';
                                    }
                                }else{
                                    if(prod.isServed === '0' || prod.isServed === '1'){
                                        prod.isServed = '2';
                                        prod.served_date = {date:Date.now()}
                                    }else{
                                        prod.isServed = '0';
                                    }
                                } 

                                serv_info[prod.unique_id] = {num:prod.isServed,date:prod.served_date};



                             }//uniqueIds

                         }
                    }
                    
                });

            // 
           
            // let data = {
            //     uniqueIds,
            //     service_number,
            //     type,
            //     order_id,
            //     isInnerSuper:this.isInnerSuper,

            // }
                let data = {
                    order_id,
                    service_number,
                    type,
                    serv_info,
                    token
                }
                

            var requestInfo = {
                unique_ids:uniqueIds,
                user_id:this.$store.state.user.id
            };

            let requestData = {
                oldInvoice:null,
                newInvoice:null,
                url:`${URL}api/order/items/serve`,
                requestType:'post',
                requestInfo,
                type:this.type,
                order_id:this.invoice.id,
                t:this
            }
            // request
            this.$store.dispatch('requestAPI',requestData);
            //local
           // this.$store.dispatch('serve_item',data);
            // event
            this.$socket.emit('serve_item',JSON.stringify(data));

               
        }

    },
    template: '#serviceComponent'
}


module.exports = serviceComponent;