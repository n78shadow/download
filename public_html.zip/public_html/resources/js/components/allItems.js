

const allItems = {
    props:["renderOther"],
    data:function(){
        return {}
    },
    methods:{
        itemDetails:function(e){
            var target = e.currentTarget;
            console.log(target);
            var details = target.querySelector('.itemDetails');
            $(details).toggleClass('display-block');
            // $(e.target).find('.itemDetails').toggleClass("display-block");
            
        }
    },
    template:'#allItems'
}







module.exports = allItems;