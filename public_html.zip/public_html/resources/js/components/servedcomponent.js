

const servedcomponent = {
    props:['served'],

    data:function(){
        return{}
    },
    mounted:function(){
        
    },
    computed:{
        servedOrder :{
            get(){
                return this.$store.state.Served;
            }
        }
        
      
    },
    methods:{

        
    },
    template:"#servedcomponent"
}


module.exports = servedcomponent;