const data = {
    "id": 16,
    "table_number": "8",
    "type": "postpaid",
    "printer_id": null,
    "status": "active",
    "bar_status": "active",
    "note": null,
    "waiter": "Naji",
    "sequence": 8,
    "sequence_string": "3-13-8",
    "discount": null,
    "created_at": {
        "date": "2019-04-06 00:54:04.000000",
        "timezone_type": 3,
        "timezone": "America/Montreal"
    },
    "services": [
        {
            "service_number": 1,
            "service_status": "Called",
            "call_date": "2019-04-06 00:54:04",
            "products": [
                {
                    "id": 30,
                    "en_name": "G. Qredes",
                    "short_name": "G. Qredes",
                    "tasting_name": "GQR",
                    "cost": "12.00",
                    "price": "31.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.63999999999999968025576890795491635799407958984375,
                    "category_color": "#9E9E9E",
                    "unique_id": 958,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 1,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:11.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 30,
                    "en_name": "G. Qredes",
                    "short_name": "G. Qredes",
                    "tasting_name": "GQR",
                    "cost": "12.00",
                    "price": "31.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.63999999999999968025576890795491635799407958984375,
                    "category_color": "#9E9E9E",
                    "unique_id": 959,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 2,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:11.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 32,
                    "en_name": "Taouk",
                    "short_name": "Taouk",
                    "tasting_name": "TK",
                    "cost": "20.00",
                    "price": "34.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 5.089999999999999857891452847979962825775146484375,
                    "category_color": "#9E9E9E",
                    "unique_id": 960,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 3,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:12.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 32,
                    "en_name": "Taouk",
                    "short_name": "Taouk",
                    "tasting_name": "TK",
                    "cost": "20.00",
                    "price": "34.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 5.089999999999999857891452847979962825775146484375,
                    "category_color": "#9E9E9E",
                    "unique_id": 961,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 4,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:12.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 2,
            "service_status": "Called",
            "call_date": "2019-04-06 01:12:14",
            "products": [
                {
                    "id": 31,
                    "en_name": "Akhtabout",
                    "short_name": "Akhtabout",
                    "tasting_name": "AK",
                    "cost": "15.00",
                    "price": "32.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.79000000000000003552713678800500929355621337890625,
                    "category_color": "#9E9E9E",
                    "unique_id": 962,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 5,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:13.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 31,
                    "en_name": "Akhtabout",
                    "short_name": "Akhtabout",
                    "tasting_name": "AK",
                    "cost": "15.00",
                    "price": "32.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.79000000000000003552713678800500929355621337890625,
                    "category_color": "#9E9E9E",
                    "unique_id": 963,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 6,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:13.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 35,
                    "en_name": "Alep",
                    "short_name": "Alep",
                    "tasting_name": "AL",
                    "cost": "15.00",
                    "price": "38.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 5.69000000000000039079850466805510222911834716796875,
                    "category_color": "#9E9E9E",
                    "unique_id": 964,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 7,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:13.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 35,
                    "en_name": "Alep",
                    "short_name": "Alep",
                    "tasting_name": "AL",
                    "cost": "15.00",
                    "price": "38.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 5.69000000000000039079850466805510222911834716796875,
                    "category_color": "#9E9E9E",
                    "unique_id": 965,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 8,
                    "call_time": null,
                    "isServed": "2",
                    "served_date": {
                        "date": "2019-04-06 01:22:13.000000",
                        "timezone_type": 3,
                        "timezone": "America/Montreal"
                    },
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 3,
            "service_status": "Called",
            "call_date": "2019-04-06 01:20:57",
            "products": [
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#ffab91",
                    "unique_id": 966,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 9,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#ffab91",
                    "unique_id": 967,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 10,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 21,
                    "en_name": "Baba",
                    "short_name": "Baba",
                    "tasting_name": "BA",
                    "cost": "7.00",
                    "price": "20.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": "3.00",
                    "category_color": "#ffab91",
                    "unique_id": 968,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 11,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 21,
                    "en_name": "Baba",
                    "short_name": "Baba",
                    "tasting_name": "BA",
                    "cost": "7.00",
                    "price": "20.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": "3.00",
                    "category_color": "#ffab91",
                    "unique_id": 969,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 12,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 21,
                    "en_name": "Baba",
                    "short_name": "Baba",
                    "tasting_name": "BA",
                    "cost": "7.00",
                    "price": "20.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": "3.00",
                    "category_color": "#ffab91",
                    "unique_id": 970,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 13,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#ffab91",
                    "unique_id": 971,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 14,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#ffab91",
                    "unique_id": 972,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 15,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 22,
                    "en_name": "S-Baba",
                    "short_name": "S-Baba",
                    "tasting_name": "SBA",
                    "cost": "3.50",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#ffab91",
                    "unique_id": 973,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 16,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 22,
                    "en_name": "S-Baba",
                    "short_name": "S-Baba",
                    "tasting_name": "SBA",
                    "cost": "3.50",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#ffab91",
                    "unique_id": 974,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 17,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 4,
            "service_status": "Called",
            "call_date": "2019-04-06 01:38:06",
            "products": [
                {
                    "id": 28,
                    "en_name": "F. Kibbe",
                    "short_name": "F. Kibbe",
                    "tasting_name": "FK",
                    "cost": "8.00",
                    "price": "17.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.54999999999999982236431605997495353221893310546875,
                    "category_color": "#f4511e",
                    "unique_id": 975,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 18,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 29,
                    "en_name": "Jibne",
                    "short_name": "Jibne",
                    "tasting_name": "JE",
                    "cost": "8.00",
                    "price": "19.00",
                    "roles": [
                        "super_bar",
                        "super-suate"
                    ],
                    "tax": 2.850000000000000088817841970012523233890533447265625,
                    "category_color": "#6d4c41",
                    "unique_id": 976,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 19,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#f4511e",
                    "unique_id": 977,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 20,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#f4511e",
                    "unique_id": 978,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 21,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 30,
                    "en_name": "G. Qredes",
                    "short_name": "G. Qredes",
                    "tasting_name": "GQR",
                    "cost": "12.00",
                    "price": "31.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.63999999999999968025576890795491635799407958984375,
                    "category_color": "#9E9E9E",
                    "unique_id": 979,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 22,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 30,
                    "en_name": "G. Qredes",
                    "short_name": "G. Qredes",
                    "tasting_name": "GQR",
                    "cost": "12.00",
                    "price": "31.00",
                    "roles": [
                        "Super-grill"
                    ],
                    "tax": 4.63999999999999968025576890795491635799407958984375,
                    "category_color": "#9E9E9E",
                    "unique_id": 980,
                    "note": null,
                    "discount_value": "0.00",
                    "invoiced": "no",
                    "client_number": [
                        1
                    ],
                    "dish_number": 23,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        }
    ],
    "bar": [
        {
            "id": 207,
            "en_name": "Shot Fernet",
            "short_name": "Shot Fernet",
            "tasting_name": null,
            "cost": "1.41",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 981,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 24,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 207,
            "en_name": "Shot Fernet",
            "short_name": "Shot Fernet",
            "tasting_name": null,
            "cost": "1.41",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 982,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 25,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 209,
            "en_name": "Chartreuse Jaune",
            "short_name": "Chartreuse Jaune",
            "tasting_name": null,
            "cost": "1.92",
            "price": "8.00",
            "roles": [
                "super_bar"
            ],
            "tax": 1.1999999999999999555910790149937383830547332763671875,
            "category_color": "#6d4c41",
            "unique_id": 983,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 26,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 209,
            "en_name": "Chartreuse Jaune",
            "short_name": "Chartreuse Jaune",
            "tasting_name": null,
            "cost": "1.92",
            "price": "8.00",
            "roles": [
                "super_bar"
            ],
            "tax": 1.1999999999999999555910790149937383830547332763671875,
            "category_color": "#6d4c41",
            "unique_id": 984,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 27,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 209,
            "en_name": "Chartreuse Jaune",
            "short_name": "Chartreuse Jaune",
            "tasting_name": null,
            "cost": "1.92",
            "price": "8.00",
            "roles": [
                "super_bar"
            ],
            "tax": 1.1999999999999999555910790149937383830547332763671875,
            "category_color": "#6d4c41",
            "unique_id": 985,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 28,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 210,
            "en_name": "Shot Poli Grappa",
            "short_name": "Shot Poli Grappa",
            "tasting_name": null,
            "cost": "1.52",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 986,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 29,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 210,
            "en_name": "Shot Poli Grappa",
            "short_name": "Shot Poli Grappa",
            "tasting_name": null,
            "cost": "1.52",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 987,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 30,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 210,
            "en_name": "Shot Poli Grappa",
            "short_name": "Shot Poli Grappa",
            "tasting_name": null,
            "cost": "1.52",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 988,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 31,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 210,
            "en_name": "Shot Poli Grappa",
            "short_name": "Shot Poli Grappa",
            "tasting_name": null,
            "cost": "1.52",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 989,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 32,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 212,
            "en_name": "Shot Jager",
            "short_name": "Shot Jager",
            "tasting_name": null,
            "cost": "1.07",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 990,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 33,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        },
        {
            "id": 212,
            "en_name": "Shot Jager",
            "short_name": "Shot Jager",
            "tasting_name": null,
            "cost": "1.07",
            "price": "6.00",
            "roles": [
                "super_bar"
            ],
            "tax": 0.90000000000000002220446049250313080847263336181640625,
            "category_color": "#6d4c41",
            "unique_id": 991,
            "discount_value": "0.00",
            "client_number": [
                1
            ],
            "dish_number": 34,
            "call_time": null,
            "isServed": "0",
            "served_date": null,
            "product_customizes": [],
            "product_optionals": []
        }
    ],
    "tastings_header": [
        {
            "tasting_id": 2,
            "tasting_name": "Kosher",
            "tasting_count": 1
        },
        {
            "tasting_id": 3,
            "tasting_name": "Pescetarian",
            "tasting_count": 2
        },
        {
            "tasting_id": 4,
            "tasting_name": "Vegetarian",
            "tasting_count": 4
        }
    ],
    "tastings_services": [
        {
            "service_number": 1,
            "service_status": "Called",
            "call_date": "2019-04-06 00:54:05",
            "products": [
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#81c784",
                    "unique_id": 992,
                    "client_number": [
                        1
                    ],
                    "dish_number": 35,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 993,
                    "client_number": [
                        1
                    ],
                    "dish_number": 36,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 273,
                    "en_name": "Kunafa",
                    "short_name": "Kunafa",
                    "tasting_name": "KA",
                    "cost": "4.00",
                    "price": "14.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 2.100000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 994,
                    "client_number": [
                        1
                    ],
                    "dish_number": 37,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#E57373",
                    "unique_id": 1001,
                    "client_number": [
                        1
                    ],
                    "dish_number": 44,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1002,
                    "client_number": [
                        1
                    ],
                    "dish_number": 45,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1003,
                    "client_number": [
                        1
                    ],
                    "dish_number": 46,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#E57373",
                    "unique_id": 1008,
                    "client_number": [
                        1
                    ],
                    "dish_number": 51,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1009,
                    "client_number": [
                        1
                    ],
                    "dish_number": 52,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1010,
                    "client_number": [
                        1
                    ],
                    "dish_number": 53,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#E57373",
                    "unique_id": 1015,
                    "client_number": [
                        1
                    ],
                    "dish_number": 58,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1016,
                    "client_number": [
                        1
                    ],
                    "dish_number": 59,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1017,
                    "client_number": [
                        1
                    ],
                    "dish_number": 60,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 18,
                    "en_name": "Fattosh",
                    "short_name": "Fattosh",
                    "tasting_name": "FH",
                    "cost": "4.00",
                    "price": "22.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 3.29000000000000003552713678800500929355621337890625,
                    "category_color": "#E57373",
                    "unique_id": 1022,
                    "client_number": [
                        1
                    ],
                    "dish_number": 65,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1023,
                    "client_number": [
                        1
                    ],
                    "dish_number": 66,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1024,
                    "client_number": [
                        1
                    ],
                    "dish_number": 67,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#81c784",
                    "unique_id": 1029,
                    "client_number": [
                        1
                    ],
                    "dish_number": 72,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1030,
                    "client_number": [
                        1
                    ],
                    "dish_number": 73,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1031,
                    "client_number": [
                        1
                    ],
                    "dish_number": 74,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#81c784",
                    "unique_id": 1035,
                    "client_number": [
                        1
                    ],
                    "dish_number": 78,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 27,
                    "en_name": "Soupe",
                    "short_name": "Soupe",
                    "tasting_name": "SE",
                    "cost": "2.00",
                    "price": "9.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 1.350000000000000088817841970012523233890533447265625,
                    "category_color": "#81c784",
                    "unique_id": 1036,
                    "client_number": [
                        1
                    ],
                    "dish_number": 79,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 23,
                    "en_name": "Labneh",
                    "short_name": "Labneh",
                    "tasting_name": "LH",
                    "cost": "4.00",
                    "price": "12.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.8000000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1037,
                    "client_number": [
                        1
                    ],
                    "dish_number": 80,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 2,
            "service_status": "ToBeCall",
            "call_date": null,
            "products": [
                {
                    "id": 45,
                    "en_name": "S-Humus",
                    "short_name": "S-Humus",
                    "tasting_name": "SHS",
                    "cost": "1.00",
                    "price": "7.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.0500000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 995,
                    "client_number": [
                        1
                    ],
                    "dish_number": 38,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 996,
                    "client_number": [
                        1
                    ],
                    "dish_number": 39,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 20,
                    "en_name": "S-Fattouch",
                    "short_name": "S-Fattouch",
                    "tasting_name": "SFH",
                    "cost": "2.00",
                    "price": "13.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.9499999999999999555910790149937383830547332763671875,
                    "category_color": "#81c784",
                    "unique_id": 997,
                    "client_number": [
                        1
                    ],
                    "dish_number": 40,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1004,
                    "client_number": [
                        1
                    ],
                    "dish_number": 47,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 19,
                    "en_name": "Humus",
                    "short_name": "Humus",
                    "tasting_name": "HS",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#E57373",
                    "unique_id": 1005,
                    "client_number": [
                        1
                    ],
                    "dish_number": 48,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 47,
                    "en_name": "Muhamara",
                    "short_name": "Muhamara",
                    "tasting_name": "Ma",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1006,
                    "client_number": [
                        1
                    ],
                    "dish_number": 49,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1011,
                    "client_number": [
                        1
                    ],
                    "dish_number": 54,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 19,
                    "en_name": "Humus",
                    "short_name": "Humus",
                    "tasting_name": "HS",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#E57373",
                    "unique_id": 1012,
                    "client_number": [
                        1
                    ],
                    "dish_number": 55,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 47,
                    "en_name": "Muhamara",
                    "short_name": "Muhamara",
                    "tasting_name": "Ma",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1013,
                    "client_number": [
                        1
                    ],
                    "dish_number": 56,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1018,
                    "client_number": [
                        1
                    ],
                    "dish_number": 61,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 19,
                    "en_name": "Humus",
                    "short_name": "Humus",
                    "tasting_name": "HS",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#E57373",
                    "unique_id": 1019,
                    "client_number": [
                        1
                    ],
                    "dish_number": 62,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 47,
                    "en_name": "Muhamara",
                    "short_name": "Muhamara",
                    "tasting_name": "Ma",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1020,
                    "client_number": [
                        1
                    ],
                    "dish_number": 63,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1025,
                    "client_number": [
                        1
                    ],
                    "dish_number": 68,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 19,
                    "en_name": "Humus",
                    "short_name": "Humus",
                    "tasting_name": "HS",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#E57373",
                    "unique_id": 1026,
                    "client_number": [
                        1
                    ],
                    "dish_number": 69,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 47,
                    "en_name": "Muhamara",
                    "short_name": "Muhamara",
                    "tasting_name": "Ma",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1027,
                    "client_number": [
                        1
                    ],
                    "dish_number": 70,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 45,
                    "en_name": "S-Humus",
                    "short_name": "S-Humus",
                    "tasting_name": "SHS",
                    "cost": "1.00",
                    "price": "7.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.0500000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1032,
                    "client_number": [
                        1
                    ],
                    "dish_number": 75,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1033,
                    "client_number": [
                        1
                    ],
                    "dish_number": 76,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 25,
                    "en_name": "Beet.M",
                    "short_name": "Beet.M",
                    "tasting_name": "BT",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1034,
                    "client_number": [
                        1
                    ],
                    "dish_number": 77,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 45,
                    "en_name": "S-Humus",
                    "short_name": "S-Humus",
                    "tasting_name": "SHS",
                    "cost": "1.00",
                    "price": "7.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.0500000000000000444089209850062616169452667236328125,
                    "category_color": "#81c784",
                    "unique_id": 1038,
                    "client_number": [
                        1
                    ],
                    "dish_number": 81,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 44,
                    "en_name": "Falafel",
                    "short_name": "Fal",
                    "tasting_name": "Fl",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [
                        "super-suate"
                    ],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1039,
                    "client_number": [
                        1
                    ],
                    "dish_number": 82,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 25,
                    "en_name": "Beet.M",
                    "short_name": "Beet.M",
                    "tasting_name": "BT",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 1040,
                    "client_number": [
                        1
                    ],
                    "dish_number": 83,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 3,
            "service_status": "ToBeCall",
            "call_date": null,
            "products": [
                {
                    "id": 47,
                    "en_name": "Muhamara",
                    "short_name": "Muhamara",
                    "tasting_name": "Ma",
                    "cost": "2.00",
                    "price": "10.00",
                    "roles": [
                        "super-salad"
                    ],
                    "tax": 1.5,
                    "category_color": "#81c784",
                    "unique_id": 998,
                    "client_number": [
                        1
                    ],
                    "dish_number": 41,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 46,
                    "en_name": "Samke",
                    "short_name": "Samke",
                    "tasting_name": "SM",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 999,
                    "client_number": [
                        1
                    ],
                    "dish_number": 42,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 46,
                    "en_name": "Samke",
                    "short_name": "Samke",
                    "tasting_name": "SM",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1007,
                    "client_number": [
                        1
                    ],
                    "dish_number": 50,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 46,
                    "en_name": "Samke",
                    "short_name": "Samke",
                    "tasting_name": "SM",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1014,
                    "client_number": [
                        1
                    ],
                    "dish_number": 57,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 46,
                    "en_name": "Samke",
                    "short_name": "Samke",
                    "tasting_name": "SM",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1021,
                    "client_number": [
                        1
                    ],
                    "dish_number": 64,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                },
                {
                    "id": 46,
                    "en_name": "Samke",
                    "short_name": "Samke",
                    "tasting_name": "SM",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1028,
                    "client_number": [
                        1
                    ],
                    "dish_number": 71,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        },
        {
            "service_number": 4,
            "service_status": "Called",
            "call_date": "2019-04-06 01:42:14",
            "products": [
                {
                    "id": 48,
                    "en_name": "V. Bamia",
                    "short_name": "V. Bamia",
                    "tasting_name": "VB",
                    "cost": "12.00",
                    "price": "15.00",
                    "roles": [],
                    "tax": 2.25,
                    "category_color": "#81c784",
                    "unique_id": 1000,
                    "client_number": [
                        1
                    ],
                    "dish_number": 43,
                    "call_time": null,
                    "isServed": "0",
                    "served_date": null,
                    "product_customizes": [],
                    "product_optionals": []
                }
            ]
        }
    ],
    "tasting_replacements": [],
    "invoices": []
}



module.exports = data;