

const EditnewItem = {
    props:['renderOther'],
    data:function(){
        return {};
    },
    methods:{

    },
    template:'#editNewItems'
}


module.exports = EditnewItem;