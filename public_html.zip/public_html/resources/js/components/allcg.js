

const allcg = {
    props:["renderOther"],
    data:function(){
        return {}
    },
    methods:{

    },
    template:'#allcg'
}


module.exports = allcg;