

const modalcomponent = {
    props:["dish_number","settimer","removetimer","ready","servedDishes"],
    data:function(){
        return{
            readynum : this.servedDishes.length ? this.servedDishes[this.servedDishes.length -1] : 0
           
        }
    },
    computed:{
        
    },
    methods:{
        servedish:function(dish){
            this.readynum = dish.number;
            this.ready(dish);
        }
        
    },
    template: '#modal-template'
  };
  module.exports = modalcomponent;