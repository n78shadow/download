<template>
  <div class="custom-view-wrapper">
    <template v-if="messageHasTitle">
      <h2 v-if="options.html" class="dg-title" v-html="messageTitle"></h2>
      <h2 v-else class="dg-title"></h2>
    </template>
    <template v-else>
      <h2>Choose Operation</h2>
    </template>

    <div v-if="options.html" class="dg-content" v-html="messageBody"></div>
    <div v-else class="dg-content"></div>
    <br>
    <input type="radio" id="one" value="mute_supervisor" v-model="picked">
    <label for="one">{{sounds.supervisor ? 'Mute Supervisor':'Unmute Supervisor'}}</label>
    <br>
    <input type="radio" id="two" value="mute_kitchen" v-model="picked">
    <label for="two">{{sounds.preperation? 'Mute Kitchen':'Unmute Kitchen'}}</label>
    <br>
    <input type="radio" id="three" value="reload" v-model="picked">
    <label for="three">Reload</label>
    <br>

    <div class="dg-content-footer">
        <button class="dg-btn dg-btn--cancel" @click="handleDismiss()">
            <span>Close</span>
        </button> 
        <button class="dg-btn dg-btn--ok dg-pull-right" @click="handlePicked()">
            <span class="dg-btn-content">
                <span>Confirm</span>
            </span> 
        </button> 
    <div class="dg-clear"></div></div>
  </div>
</template>
 
<script>
import DialogMixin from "vuejs-dialog/dist/vuejs-dialog-mixin.min.js"; // Include mixin

export default {
  data() {
    return {
        picked:'',
        sounds:this.options.sounds
    };
  },
  mixins: [DialogMixin],
  mounted(){
   

  },
  methods: {
    handlePicked() {

      
      this.proceed(this.picked); // included in DialogMixin
    },
    handleDismiss() {
        
      this.cancel(); // included in DialogMixin
    }
  },
  components: {}
};
</script>
 
<style scoped="">

</style>