




const waiter = {
    props:[],
    data:function(){
        return {};
    },
    mounted:function(){
        console.log("waiter mounted");
        io.emit("newinvoce","this is new invoce from waiter");
    },
    computed:{
        
      
    },
    methods:{

    },
    template:"#waiterComponent"

}

module.exports = waiter;