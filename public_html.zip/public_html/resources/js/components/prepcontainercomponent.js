


const preperationcontainercomponent = {
    props:['invoices'],
    data:function(){
        return{}
    },
    mounted:function(){
        console.log('prep mounted')
        
    },
    methods:{

    },
    template:'#preperationcontainer'
}

module.exports = preperationcontainercomponent;