

//const URL = 'http://demopos.upos.ca/';
const URL = 'http://pos.upos.ca/';

module.exports = URL;
