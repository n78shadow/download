

const newcg = {
    props:[],
    data:function(){
        return {}
    },
    methods:{

    },
    template:"#newcgroup"
}


module.exports = newcg;