

const prepinvoicecomponent = {
    props:['invoice'],
    data:function(){
        return{};
    },
    computed:{
        invo:function(){
            //copy
            let invoice = JSON.parse(JSON.stringify(this.invoice));
            let time = invoice.created_at.date;
            let date = new Date(time);
            let h = date.getHours() < 10 ? '0'+date.getHours():date.getHours();
            let m = date.getMinutes() < 10 ? '0'+date.getMinutes() : date.getMinutes();


            let services = invoice.services;
            services = services.map((srv)=>{
                    let products = srv.products.reduce(function(acc,curr){
                        
                        var o ={
                            'id':curr.id,
                            'dish_number':[curr.dish_number],
                            'en_name':curr.en_name,
                            'short_name': curr.short_name,
                            'tasting_name': curr.tasting_name,
                            'cost': curr.cost,
                            'price': curr.price,
                            'timer':curr.timer,
                            'category_color': curr.category_color,
                            'call_time':curr.call_time != null ? [curr.call_time]:[],
                            'clients':[curr.client_number],
                            'isServed': curr.isServed ? [curr.isServed] : [],
                            'product_customizes':[
                                {'dish_number':curr.dish_number,'options':curr.product_customizes,'client_number':curr.client_number}
                            ]
                        };
                        let f = acc.findIndex(function(item){
                                return item.short_name === o.short_name;
                        });
                        if(f === -1){
                            acc.push(o);
                        }else{
                            acc[f].product_customizes = acc[f].product_customizes.concat(o.product_customizes);
                            acc[f].clients = _.union(acc[f].clients,o.clients);
                            acc[f].dish_number = acc[f].dish_number.concat(o.dish_number);
                            acc[f].call_time = acc[f].call_time.concat(o.call_time);
                            acc[f].isServed = acc[f].isServed.concat(o.isServed);
                            
                        }
                        
                        
                        
                        return acc;
                    },[]);


                    //customiz
                    products = this.customize(products);





                srv.products = products;
                let date = new Date(srv.call_date);
                let h = date.getHours() < 10 ? '0'+date.getHours() : date.getHours();
                let m = date.getMinutes() < 10 ? '0'+date.getMinutes() : date.getMinutes() ;
                srv.call_date = h+':'+m;
                return srv;
            
            });
            invoice.services = services;
            invoice.created_at = h+":"+m;
            return invoice;

        }
    },
    mounted:function(){

        

        console.log('preinv mounted')
        let $masonry = new Masonry('.invoices-container', {
            // masonry options go in here
           // see https://masonry.desandro.com/#initialize-with-vanilla-javascript
           itemSelector: '.card',
            columnWidth: 146,
            // use element for option
            //columnWidth: '.invoice-size',
            //percentPosition: true,
            horizontalOrder: true,
            //originTop: false,
            isFitWidth: true,
            gutter : 4
          });
    },
    methods:{
        customize : function(products){
            let result = products.map(pro=>{
                    
                    let clients = pro.clients
                    let product_customizes = pro.product_customizes;
                    let dish_number = pro.dish_number;
                    let checkEmpty = 0;
                    for(var i=0;i<product_customizes.length;i++){
                        if(product_customizes[i].options.length == 0){
                            checkEmpty++;
                            break;
                        }
                    }

                    let f = function(){
                        for(var i=0;i<product_customizes.length;i++){
                            
                            if(product_customizes[i].options.length){
                                let cliId = product_customizes[i].client_number;
                                let f = clients.findIndex(function(el){return el == cliId});
                              
                                if(f != -1){
                                    console.log('inside');
                                    clients.splice(f,1);
                                }
                            }
                            
    
                        }
                    }
                   
                    if(checkEmpty > 0){
                        f();
                        
                        pro.clients = clients;
                        return pro;
                    }else{
                        let i = 0;
                        let compare = true;
                        console.log('long',product_customizes.length );
                        while(i < product_customizes.length -1){
                            
                           compare =  this.compareTwoArray(product_customizes[i].options,product_customizes[++i].options);
                           console.log('compare',compare);
                           if(!compare){
                               break;
                           }
                        }
                        if(compare){
                            product_customizes = [{'dish_number':'','options':product_customizes[0].options,'client_number':''}];
                            pro.product_customizes = product_customizes;
                            console.log(pro);
                          
                            return pro;
                        }else{
                            f();
                        }


                    }
                    return pro;

                    
                    

            });
            return result;
        },
        compareTwoArray:function(arr,arr2){
            let s1 = arr.sort();
            let s2 = arr2.sort();
            return _.isEqual(s1,s2);
        }
    },
    template:'#prepinvoicecomponent'

}


module.exports = prepinvoicecomponent;