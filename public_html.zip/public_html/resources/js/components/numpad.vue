<template>
    <vueInputNumberKeyboard :show="showKeyboard" @Input="getValue"></vueInputNumberKeyboard>
    <button @click="toggle">ON/OFF</button>
    <h1>{{str}}</h1>
</template>

<script>
    export default {
        name: "app",
        data() {
            return {
                showKeyboard: false,
                arr: []
            };
        },
        computed:{
            str(){
                return this.arr.join("")
            }
        },
        methods: {
            toggle() {
                this.showKeyboard = !this.showKeyboard;
            },
            getValue(val) {
                if (val !== "del") {
                    this.arr.push(val);
                } else {
                    this.arr.pop();
                }
            }
        }
    };
</script>