

const itemGroup = {
    props:["renderOther"],
    data:function(){
        return {}
    },
    methods:{

    },
    template:"#ItemsGroupCom"
}



module.exports = itemGroup;