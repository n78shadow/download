
    const numpadComponent  =  {
        props:['invo'],
        data() {
            return {
                number:''
            };
        },
        computed:{
            
        },
        methods: {
            easynum: function(e,num){
                e.preventDefault();
                    this.number = this.number + num;
            },
            easy_numpad_del:function(e){
                e.preventDefault();
                this.number = this.number.slice(0, -1);
            },
            easy_numpad_clear:function(e){
                e.preventDefault();
                this.number = "";
            },
            easy_numpad_cancel:function(e){
                e.preventDefault();
                this.$emit('hidenumpad');

            },
            easy_numpad_done:function(e){
                e.preventDefault();
                if(+this.number <= 0){
                    alert('wrong number');
                    return;
                }

                let token = this.$store.state.token;

              

                
                this.$store.dispatch('getIndexes',this.invo).then(indexs=>{
                    this.$emit('hidenumpad');
                    let { calledIndex, tobecalledIndex, servedIndex } = indexs;
                    let newIndex = +this.number -1;
                    let length = this.$store.state.Called.length;
                    if(newIndex > length -1){
                        alert('wrong number !!');
                        return;
                    }
                    this.$store.dispatch('changeIndex',{invoice:this.invo,oldIndex:calledIndex,newIndex});
                    // Called.splice(calledIndex,1);
                    // Called.splice(newIndex,0,this.invo);
                    //this.$store.dispatch('prepareReOrderData',Called);

                    this.$store.dispatch('userType').then(type=>{
                        let data = {type,value:{invoice:this.invo,oldIndex:calledIndex,newIndex},token};

                        //io.emit('reOrder',JSON.stringify(data));

                        this.$socket.emit('reOrder',JSON.stringify(data));
                        //this.$store.dispatch('updateList', data);
                    }).catch(err=>{console.log(err)});



                }).catch(err=>{});
                //let index = Called.findIndex(invoice=>invoice.id === this.invo.id && )
                

            }
            
        },
        template:'#numbadComponent'
    };

    module.exports = numpadComponent;

