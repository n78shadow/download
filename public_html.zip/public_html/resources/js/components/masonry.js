
module.exports = function(){
    if(this.$store.state.page === 'preperation'){
        
        let $masonry = new Masonry('.invoices-container', {
            // masonry options go in here
           // see https://masonry.desandro.com/#initialize-with-vanilla-javascript
            itemSelector: '.card',
            columnWidth: 146,
            // use element for option
            //columnWidth: '.invoice-size',
            //percentPosition: true,
            horizontalOrder: true,
            //originTop: false,
            isFitWidth: true,
            gutter : 4
          });
    }
   
    

    if(this.$store.state.page === 'supervisor'){
        //console.log('massonry',this.$store.state.page);
        let $Supermasonry = new Masonry('.supervisor-container', {
            // masonry options go in here
           // see https://masonry.desandro.com/#initialize-with-vanilla-javascript
            itemSelector: '.card',
            columnWidth:1,
            // use element for option
            //columnWidth: '.invoice-size',
            //percentPosition: true,
            horizontalOrder: true,
            //originTop: false,
            isFitWidth: true,
            gutter : 4
          });
    }
}