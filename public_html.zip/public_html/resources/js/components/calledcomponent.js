
const masonry = require('./masonry');
const calledcomponent = {
    
    props:[],
    data:function(){
        return {

        };
    },
    mounted:function(){
        console.log('called mounted');
        
        
    },
    watch:{
        

    },
    
    updated:function(){

        console.log('called updated');
            let page = this.$store.state.page;

            this.$nextTick(()=>{
                if(page === 'preperation'){
                    let Called = this.$store.state.Called;
                
                    this.notifyKitchen();
    
                        
                    for(var i=0;i<Called.length;i++){
                            //console.log(Called[i].category)
                           // $('#'+Called[i].category+Called[i].id).find('.order').html('<span>'+(i+1)+'</span>');
                           let ele = document.querySelector(`#${Called[i].category+Called[i].id} .order` );
                           if(ele){
                            ele.innerHTML = `<span>${(i+1)}</span>`;
                           }
                           
                          
                        }
                }else if(page === 'supervisor'){
                    this.notifySupervisor();
                }
                
                   
        }); 
        
        

        
        let layout = masonry.bind(this);

        layout();

    
    },
    computed:{

      
        
        calledOrder :{
            get(){
                let Called = this.$store.state.Called;
                return Called;


               
            },
            set(value){
                
                

               
            }
        },

        

    },
    methods:{
        playSound(page){
            setTimeout(()=>{
                document.getElementById(page+'Sound').play();
            },2000);
           
        },
        notifyKitchen(){
            let sound = this.$store.state.sounds.preperation;
            
            let children = this.$children.filter(child=>!child.entireHide && !child.hold );
                var countBefore = this.count;

                this.count = children.length;
                console.log('countBefore',countBefore);
                console.log('count',this.count);
                if(this.count > countBefore){
                    if(sound){
                        this.playSound('preperation');
                    }
                   
                }
        },
        notifySupervisor(){
            let sound = this.$store.state.sounds.supervisor;
            
            let children = this.$children;
            var countBefore = this.count;
            this.count = children.length;
            if(this.count > countBefore){
                if(sound){
                    this.playSound('supervisor');
                }
                
            }
        }
        
       

    },
    destroyed(){
        console.log('called destroyed');
    },
    template:"#calledcomponent"

}

module.exports = calledcomponent;