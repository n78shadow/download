
const materialColors = require('./materialColors');



const newEditcat = {
    props:['renderOther','fromPrent'],
    data: function () {
      return {
        form:{
            id:0,
            title:'',
            color:'',
            customizeGrop:[],
            subcats:[]
        },
        colors:materialColors,
        subcat:'',
        variations:[{
            weight: 50,
            hex: "#FFEBEE"
        },
        {
            weight: 100,
            hex: "#FFCDD2"
        },
        {
            weight: 200,
            hex: "#EF9A9A"
        },
        {
            weight: 300,
            hex: "#E57373"
        },
        {
            weight: 400,
            hex: "#EF5350"
        },
        {
            weight: 500,
            hex: "#F44336"
        },
        {
            weight: 600,
            hex: "#E53935"
        },
        {
            weight: 700,
            hex: "#D32F2F"
        },
        {
            weight: 800,
            hex: "#C62828"
        },
        {
            weight: 900,
            hex: "#B71C1C"
        }]
        

      }
    },
    mounted:function(){
        // id is at index 1
        console.log(this.fromPrent);
        if(Number.isInteger(this.fromPrent[1])){
            //axios
        }
    },
    template: '#ctg-edit',
    methods:{
        addCustomGroup:function(e){
            console.log(e);
            let name = e.target.dataset.name;
            console.log(name);
            this.form.customizeGrop.push(name);

        },
        submit:function(){
            console.log(this.form);
        },
        chooseColor:function(e,index){
            console.log(index);
            this.variations = this.colors[index].variations;
            console.log(this.variations);

        },
        pickupColor:function(e,color){
            console.log(color);
            //close modal
            this.form.color = color;
        },
        addSub:function(e){
            this.form.subcats.push(this.subcat);
            this.subcat = "";
        }
    }
  }

  module.exports = newEditcat;