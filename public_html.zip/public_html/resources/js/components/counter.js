
const counter = {
    template:`<div class="counter">

    <div class="row">
        <div class="col-lg-1 text-center">
            <h3 style="margin:0"><clock></clock></h3>
            <small style="font-size: 11px;font-weight: 100;">{{username}}</small>
            
        </div>
      
        <div class="col-lg-11" v-if="counter">
            <a role="button" class="btn item itemWithoutOption " v-for="item in counter">
                    <span class="item-qnt"></span>
                    
                    {{item.called}} -{{item.tobeCalled}} {{item.name}}
            </a>
           
            
        

        </div>
        <div v-else style="margin: 0 auto;"><h3 >Working...</h3></div>
    </div>

</div>`,
    data(){
        return {
           
        }
    },

    computed:{
            username(){
                return this.$store.state.user.username;
            },
        
        
    },
    updated(){
        console.log('counter updated');
    },
    asyncComputed:{
        counter(){

            // proccessing in other thread
            
            let originalCalled = JSON.parse(JSON.stringify(this.$store.state.Called));
            let originaltobeCalled = JSON.parse(JSON.stringify(this.$store.state.tobeCalled));
            let called = this.$store.getters.filterProducts(originalCalled);
            let tobeCalled = this.$store.getters.filterProducts(originaltobeCalled);

            const actions = [{message:'func1',func:(called,tobeCalled)=>{

            let tastingCalled = called.filter(invo => invo.tastings_services.length > 0);
            let tastingToBeCalled = tobeCalled.filter(invo => invo.tastings_services.length > 0);
            let calledWithOutTasting = called.filter(invo => invo.tastings_services.length === 0);
            let tobeCalledWithOutTasting = tobeCalled.filter(invo => invo.tastings_services.length === 0);
            let invoices = calledWithOutTasting.concat(tobeCalledWithOutTasting);
            let _counter = [];
            let result = [];
            for (let i = 0; i < invoices.length; i++) {
                console.log('from inside counter prop');
                let invoice = invoices[i];
                let services = invoice.services.concat(invoice.tastings_services,invoice.bar);
                services.map((srv) => {
                    let status = srv.service_status === "Called" ? "Called" : "tobeCalled";
                    srv.products.map(product => {
                        if (+product.isServed) {

                        } else {

                            _counter.push({ id: product.id, name: product.short_name, status: status });
                        }





                    });
                });
            }

            if (_counter.length) {
                result = _counter.reduce(function (acc, curr) {
                    let o = {
                        id: curr.id,
                        name: curr.name,
                        called: curr.status === 'Called' ? 1 : 0,
                        tobeCalled: curr.status === 'Called' ? 0 : 1
                    };
                    let f = acc.findIndex(item => item.id === o.id);
                    if (f === -1) {
                        acc.push(o);
                    } else {
                        acc[f].called = +acc[f].called + (+o.called);
                        acc[f].tobeCalled = +acc[f].tobeCalled + (+o.tobeCalled);
                    }

                    return acc;
                }, []);
            }

            let tastingCounter = [];
            

            if (tastingCalled.length) {

                for (let i = 0; i < tastingCalled.length; i++) {
                    let tasting = tastingCalled[i];
                    let tastings_header = tasting.tastings_header;
                    for (var j = 0; j < tastings_header.length; j++) {
                        let header = tastings_header[j];
                        header.status = 'Called';
                        let f = tastingCounter.findIndex(obj => obj.tasting_name === header.tasting_name);
                        if (f > -1) {
                            tastingCounter[f].tasting_count = +tastingCounter[f].tasting_count + (+header.tasting_count);
                        } else {
                            tastingCounter.push(header);
                        }
                    }
                }



            }

            let tastingTobeCalledCounter = [];

            if (tastingToBeCalled.length) {

                for (let i = 0; i < tastingToBeCalled.length; i++) {
                    let tasting = tastingToBeCalled[i];
                    let tastings_header = tasting.tastings_header;
                    for (var j = 0; j < tastings_header.length; j++) {
                        let header = tastings_header[j];
                        header.status = 'tobeCalled';
                        let f = tastingTobeCalledCounter.findIndex(obj => obj.tasting_name === header.tasting_name);
                        if (f > -1) {
                            tastingTobeCalledCounter[f].tasting_count = +tastingTobeCalledCounter[f].tasting_count + (+header.tasting_count);
                        } else {
                            tastingTobeCalledCounter.push(header);
                        }
                    }
                }

            }
            let tasting = tastingCounter.concat(tastingTobeCalledCounter);
            if (tasting.length) {
                tasting = tasting.reduce(function (acc, curr) {
                    let o = {
                        id: curr.tasting_id,
                        name: curr.tasting_name,
                        called: curr.status === 'Called' ? curr.tasting_count : 0,
                        tobeCalled: curr.status === 'Called' ? 0 : curr.tasting_count,
                    }

                    let f = acc.findIndex(item => item.name === o.name);
                    if (f > -1) {
                        acc[f].called = +acc[f].called + (+o.called);
                        acc[f].tobeCalled = +acc[f].tobeCalled + (+o.tobeCalled);

                    } else {
                        acc.push(o);
                    }
                    return acc;
                }, []);
            }

            return result.concat(tasting);




            }}];

            let worker = this.$worker.create(actions);
            return worker.postMessage('func1',[called,tobeCalled]);
        },


        // counter: function () {

        //     let delay = this.$store.state.delay;

        //     if(delay != null){

        //         return this.value ;
        //     }
            
        //    return new Promise((res,rej)=>{

        //     let originalCalled = JSON.parse(JSON.stringify(this.$store.state.Called));
        //     let originaltobeCalled = JSON.parse(JSON.stringify(this.$store.state.tobeCalled));

            

        //     let called = this.$store.getters.filterProducts(originalCalled);
        //     let tobeCalled = this.$store.getters.filterProducts(originaltobeCalled);
        //     let tastingCalled = called.filter(invo => invo.tastings_services.length > 0);
        //     let tastingToBeCalled = tobeCalled.filter(invo => invo.tastings_services.length > 0);
        //     let calledWithOutTasting = called.filter(invo => invo.tastings_services.length === 0);
        //     let tobeCalledWithOutTasting = tobeCalled.filter(invo => invo.tastings_services.length === 0);
        //     let invoices = [...calledWithOutTasting, ...tobeCalledWithOutTasting];
        //     let _counter = [];
        //     let result = [];
        //     for (let i = 0; i < invoices.length; i++) {
        //         console.log('from inside counter prop');
        //         let invoice = invoices[i];
        //         let services = [...invoice.services, ...invoice.tastings_services, ...invoice.bar];
        //         services.map((srv) => {
        //             let status = srv.service_status === "Called" ? "Called" : "tobeCalled";
        //             srv.products.map(product => {
        //                 if (+product.isServed) {

        //                 } else {

        //                     _counter.push({ id: product.id, name: product.short_name, status: status });
        //                 }





        //             });
        //         });
        //     }

        //     if (_counter.length) {
        //         result = _counter.reduce(function (acc, curr) {
        //             let o = {
        //                 id: curr.id,
        //                 name: curr.name,
        //                 called: curr.status === 'Called' ? 1 : 0,
        //                 tobeCalled: curr.status === 'Called' ? 0 : 1
        //             };
        //             let f = acc.findIndex(item => item.id === o.id);
        //             if (f === -1) {
        //                 acc.push(o);
        //             } else {
        //                 acc[f].called = +acc[f].called + (+o.called);
        //                 acc[f].tobeCalled = +acc[f].tobeCalled + (+o.tobeCalled);
        //             }

        //             return acc;
        //         }, []);
        //     }

        //     let tastingCounter = [];


        //     if (tastingCalled.length) {

        //         for (let i = 0; i < tastingCalled.length; i++) {
        //             let tasting = tastingCalled[i];
        //             let tastings_header = tasting.tastings_header;
        //             for (var j = 0; j < tastings_header.length; j++) {
        //                 let header = tastings_header[j];
        //                 header.status = 'Called';
        //                 let f = tastingCounter.findIndex(obj => obj.tasting_name === header.tasting_name);
        //                 if (f > -1) {
        //                     tastingCounter[f].tasting_count = +tastingCounter[f].tasting_count + (+header.tasting_count);
        //                 } else {
        //                     tastingCounter.push(header);
        //                 }
        //             }
        //         }



        //     }

        //     let tastingTobeCalledCounter = [];

        //     if (tastingToBeCalled.length) {

        //         for (let i = 0; i < tastingToBeCalled.length; i++) {
        //             let tasting = tastingToBeCalled[i];
        //             let tastings_header = tasting.tastings_header;
        //             for (var j = 0; j < tastings_header.length; j++) {
        //                 let header = tastings_header[j];
        //                 header.status = 'tobeCalled';
        //                 let f = tastingTobeCalledCounter.findIndex(obj => obj.tasting_name === header.tasting_name);
        //                 if (f > -1) {
        //                     tastingTobeCalledCounter[f].tasting_count = +tastingTobeCalledCounter[f].tasting_count + (+header.tasting_count);
        //                 } else {
        //                     tastingTobeCalledCounter.push(header);
        //                 }
        //             }
        //         }

        //     }
        //     let tasting = [...tastingCounter, ...tastingTobeCalledCounter];
        //     if (tasting.length) {
        //         tasting = tasting.reduce(function (acc, curr) {
        //             let o = {
        //                 id: curr.tasting_id,
        //                 name: curr.tasting_name,
        //                 called: curr.status === 'Called' ? curr.tasting_count : 0,
        //                 tobeCalled: curr.status === 'Called' ? 0 : curr.tasting_count,
        //             }

        //             let f = acc.findIndex(item => item.name === o.name);
        //             if (f > -1) {
        //                 acc[f].called = +acc[f].called + (+o.called);
        //                 acc[f].tobeCalled = +acc[f].tobeCalled + (+o.tobeCalled);

        //             } else {
        //                 acc.push(o);
        //             }
        //             return acc;
        //         }, []);
        //     }

        //     this.value = [...result, ...tasting];
        //     //this.cotr = [...result, ...tasting];
        //     res([...result, ...tasting]) ;
        //    });
        // },

        

    },
    methods:{
        
    }
}

module.exports = counter;