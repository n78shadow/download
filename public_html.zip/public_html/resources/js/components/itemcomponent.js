



const URL = require('./config');

const itemComponent = {
  props: ["item", "tasting", "bar", "srvnumber", "service_status", "invoid", "updateThis", "type", "ServeItemsLocal"],

  data() {
    return {
      showmodal: false,
      seconds: "00",
      minutes: "00",
      x: undefined,
      

    };
  },
  computed: {
    mode:function(){

      return this.$store.state.table_mode != 'take-out';
    },
    timer: function () {
      return this.minutes + ":" + this.seconds;
    },
    isServed: function () {
      return this.item.isServed.length === this.item.dish_number.length;
    },
    isReady: function () {
      return this.item.isReady.length === this.item.dish_number.length;
    },
    color: function () {
      if (this.isReady) {
        return "#ffffff";
      } else if (this.tasting) {
        if(this.item.category_color === '#66c4ff'){
          return '#66c4ff';
        }
        return 'rgb(40, 167, 69)';
      }

      return this.item.category_color;

    },
    borderColor(){
        if(this.tasting){
          if(this.item.category_color === '#66c4ff'){
            return '#66c4ff';
          }
          
        }
        return false;
    },
    served_date: function () {
      let time = this.item.served_date.length ? this.item.served_date[this.item.served_date.length - 1].date : null;

      if (time) {
        return moment(time).format('hh:mm');
      } else {
        return null;
      }
    },
    Premission: function () {
      
      return this.$store.getters.myProduct(this.tasting,this.item);
    },
    showserved: function () {
      return this.$store.state.visibiltiy.showServed;
    },
    hideOrNot: function () {
      return !(this.isServed && !this.showserved);
    },
    servedDishes: function () {
      return this.item.isServed.sort(this.compare);
    },
    dishNumber: function () {
      return this.item.dish_number.sort(this.comparDishes);
    },

    isTimer: function () {
      let timer = this.$store.state.timers.find(t =>
        t.invoid === this.invoid
        && t.srvnumber === this.srvnumber
        && t.id === this.item.id
        && t.isTasting === this.tasting
        && t.isBar === this.bar
      );
      return timer;

    },

    isItemVisibile:function(){
        //let page = this.$store.state.page;
        let currentTab = this.$store.state.currentTab;
        if(currentTab != 'called'){
                    return true;
        }

        let itemVisible =  this.canSee && this.hideOrNot;
        
          this.$emit('itemVisible');
        
          
        
        
        return itemVisible;
    },


    isItemVisibleKitchen:function(){
      let page = this.$store.state.page;
      let itemVisible = this.canSee;
     
        
      this.$emit('itemVisible');
        
        
      
      
      return itemVisible;;
       
    },

    
    canSee: function () {
      if (!(this.$store.state.visibiltiy.hideDishes)) {
        return true;
      }
      return this.Premission;

    },
    canServe:function(){
      return this.Premission;
    }

  },
  watch: {
    isTimer: function (newtimer, oldtimer) {
      console.log('newtimer', newtimer);
      console.log('oldtimer', oldtimer);
      if (newtimer) {
        if (this.x != undefined) {
          return;
        }
        let duration = newtimer.duration;

        this.countdown(duration);
      } else {
        if (this.x != undefined) {
          clearInterval(this.x);
          this.x = undefined;
          this.minutes = "00";
          this.seconds = "00";
        }
      }
    }
  },
  mounted: function () {
    
    
    if (this.isTimer) {
      this.countdown(this.isTimer.duration);
    }
  },
  methods: {

    timerInfo: function (dur) {
      
      let token = this.$store.state.token;

      return {
        invoid: this.invoid,
        srvnumber: this.srvnumber,
        id: this.item.id,
        duration: dur,
        isTasting: this.tasting,
        isBar: this.bar,
        token
      };
    },

    

    countdown: function (d) {

      var duration = (d - Date.now()) / 1000;
      if (duration <= 0) {

        if (this.x != undefined) {
          clearInterval(this.x);
          this.minutes = "00";
          this.seconds = "00";

        }
        return;
      }
      var timer = duration, minutes, seconds;
      var t = this;
      this.x = setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        t.minutes = minutes < 10 ? "0" + minutes : minutes;
        t.seconds = seconds < 10 ? "0" + seconds : seconds;



        if (--timer < 0) {
          console.log('timer finish');

          t.$store.dispatch('setTimer', t.timerInfo(0));

        }
      }, 1000);
    },
    settimer: function (num) {
      if(this.isServed || this.isReady){
        return;
      }
      if(!this.Premission){
        return;
      }
      if (this.isTimer) {
        return;
      }

      var dur = Date.now() + num * 60 * 1000;
      // this.invoSetTimer(this.srvnumber,this.item.id,dur);

      //io.emit('timer', JSON.stringify(this.timerInfo(dur)));
      this.$socket.emit('timer',JSON.stringify(this.timerInfo(dur)));


    },
    serve: function (uniqueIds) {

      if(!this.canServe){
        return;
      }

      if (this.service_status) {

        if (this.isTimer) {
          alert('Wait unil timer is finish or remove timer');
          return;
        }

        // this.$store.commit('setStatus','working');

        this.ServeItemsLocal( uniqueIds);


        

      } else {
        alert('service not called');
      }

    },
    onLongPressStart: function () {

      if(!this.service_status || !this.Premission){
        return;
      }
      this.showmodal = true;

    },
    onLongPressStop: function () { },


    hidedishes: function () {
      this.showmodal = false;
    },


    ready: function (dish) {
      let nums = [];
      let dishes = this.item.dish_number.sort(this.comparDishes);
      let servedDishes = this.servedDishes;
      loop1:
      for (var i = 0; i < dishes.length; i++) {
        let _dish = dishes[i];
        loop2:
        for (var j = 0; j < servedDishes.length; j++) {
          if (servedDishes[j] === _dish.number) {
            continue loop1;
          }
        }


        if (_dish.number > dish.number) {
          break;
        }
        nums.push(_dish.unique_id);
      }


      if (nums.length) {
        this.serve(nums);
      }

    },
    serveall: function () {
      let uniqueIds = this.item.dish_number.map(dish => {
        return dish.unique_id;
      });
      this.serve(uniqueIds);
    },
    removetimer: function () {
      this.$socket.emit('timer', JSON.stringify(this.timerInfo(0)));

    },
    compare: function (a, b) {
      if (a < b) {
        return -1;
      }
      if (a > b) {
        return 1;
      }
      return 0;
    },
    comparDishes: function (a, b) {
      if (a.number < b.number) {
        return -1;
      }
      if (a.number > b.number) {
        return 1;
      }
      return 0;
    }

  },
  template: '#itemComponent'
};


module.exports = itemComponent;

