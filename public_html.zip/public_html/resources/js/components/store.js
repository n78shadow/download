

import Vuex from 'vuex';
import data from './test.js';





//Vue.use(Vuex);

const URL = require('./config');



const store = new Vuex.Store({
    state: {
        status: 'Ready',
        token: '',
        branch_id: '',
        table_mode :'',
        invoices: [],
        visibiltiy: {
            showall: true,
            hideStation: false,
            hideDishes: false,
            showServed: true
        },
        Called: [],
        tobeCalled: [],
        Served: [],
        Paid: [],
        currentTab: 'called',
        timers: [],
        flip: [],
        user: {},
        page: '',
        key: 1,
        ready: false,
        connected: false,
        delay: null,
        sounds: {
            supervisor: true,
            preperation: true
        }

        //hiddenInvoices: {},
        //hiddenServices:{}




    },
    mutations: {

        setStatus(state, status) {
            state.status = status;
        },
        setCurentTab(state, tab) {
            state.currentTab = tab;
        },

        setReady(state) {
            state.ready = false;
        },
        setKey(state) {
            state.key++;
        },
        disconnect(state) {

        },
        SOCKET_CONNECT(state) {
            console.log('connected');
            state.connected = true;
        },
        setSounds(state, name) {
            state.sounds[name] = !(state.sounds[name]);
        }




    },
    actions: {

        //sockets

        //socket order_updated
        //done

        socket_orderUpdated({ dispatch, commit, state }, payload) {


            payload = JSON.parse(payload);
            console.log('order updated', payload);

            if(payload.branch_token != state.token){
                return;
            }

            let { order_id } = payload;
            axios.get(`${URL}api/orders/${order_id}?key=app&client_token=${state.token}`).then(async res => {
                let invoice = res.data;
                console.log('order after update',invoice);
                let o = {
                    'order_id': payload.order_id,
                    'changes': payload.changes,
                    'added': Array.isArray(payload.added) ? payload.added : [],
                    'added_bar': Array.isArray(payload.added_bar) ? payload.added_bar : [],
                    'deleted': Array.isArray(payload.deleted) ? payload.deleted : []

                };
                invoice.orderUpdate = o;
                let { services, tastings_services, bar } = await dispatch('prepare', invoice);
                if (services) {
                    await dispatch('IOupdateInvoice', { data: services, reorder: false, merge: true });
                }
                if (tastings_services) {
                    await dispatch('IOupdateInvoice', { data: tastings_services, reorder: false, merge: true });
                }
                if (bar) {
                    await dispatch('IOupdateInvoice', { data: bar, reorder: false, merge: true });
                }





            }).catch(err => { console.log(err) });



        },


        //socket order_created
        //done

        async socket_orderCreated({ dispatch, commit, state }, invoice) {

            invoice = JSON.parse(invoice);


            console.log('invoice recived:',invoice);

            if(invoice.branch_token != state.token){
                return;
            }

            

            let { services, tastings_services, bar } = await dispatch('prepare', invoice);
            let status;
            if (services) {
                status = await dispatch('calculate', services);
                state[status].push(services);
            }
            if (tastings_services) {
                status = await dispatch('calculate', tastings_services);
                state[status].push(tastings_services);
            }
            if (bar) {
                status = await dispatch('calculate', bar);
                state[status].push(bar);
            }

        },

        //socket order_timer
        //done

        socket_orderTimer({ dispatch, commit, state }, data) {
            data = JSON.parse(data);
            console.log('timer event',data);
            if(data.token != state.token){
                return;
            }

            dispatch('setTimer', data);

        },


        //socket station_hidden
        //done
        socket_stationHidden({ dispatch, commit, state }, data) {
            data = JSON.parse(data);
            console.log('hidestation event',data);
            if(data.token != state.token){
                return;
            }
            dispatch('hideStation', data);
        },



        //done
        socket_muteKitchen({ dispatch, commit, state }, data) {
            
            let { roles, sound,token } = JSON.parse(data);
            console.log('kitchen sound event',token);
            if(token != state.token){
                return;
            }
            let userRoles = state.user.roles.map(role => role.slug);
            let c = userRoles.some(role => {
                var regex = /super-/;
                let match = regex.exec(role.toLowerCase());
                // console.log('match',match);
                if (!match) {
                    return false;
                }
                return roles.indexOf(role) !== -1
            });
            if (c) {
                state.sounds.preperation = sound;
            }


        },

        //socket orders_reordered
        //done
        socket_ordersReordered({ dispatch, commit, state }, data) {
            

            data = JSON.parse(data);

            console.log('orders reorderd',data);
            if(data.token != state.token){
                return;
            }

            let { type, value } = data;
            
            dispatch('userType').then(res => {
                if (res === type) {

                    let { invoice, oldIndex, newIndex } = value;
                    state.Called.splice(oldIndex, 1);
                    state.Called.splice(newIndex, 0, invoice);



                }
            }).catch(err => { console.log(err) });


        },

        //socket broadcast

        //done

        socket_broadcast({ dispatch, commit, state }, data) {

            data = JSON.parse(data);



            console.log('broadcast',data);

            if(data.token != state.token){
                return;
            }

            dispatch('IOupdateInvoice', data);
        },

        // socket callservice
        //done
        socket_callservice({ dispatch, commit, state }, data) {
            
            data = JSON.parse(data);


            console.log('call service event',data);

            if(data.token != state.token){
                return;
            }

            dispatch('call_service', data);
        },


        //socket serveitem
        //done
        socket_serveitem({ dispatch, commit, state }, data) {

            data = JSON.parse(data);


            console.log('serve item event', data);

            if(data.token != state.token){
                return;
            }

            if (state.delay) {
                clearInterval(state.delay);

                state.delay = setTimeout(() => {
                    state.delay = null;
                }, 2000);
            } else {
                state.delay = setTimeout(() => {

                    state.delay = null;

                }, 2000);
            }

            dispatch('serve_item', data);

        },


        //socket order_flipped
        //done
        socket_orderFlipped({ dispatch, commit, state }, payload) {

            let { status, invo_id, invo_type,token } = JSON.parse(payload);

            if(token != state.token){
                return;
            }

            let f = state.flip.findIndex(o => o.invo_id === invo_id && o.invo_type === invo_type);
            if (f > -1) {
                state.flip.splice(f, 1, { invo_id, invo_type, status });
            } else {
                state.flip.push({ invo_id, invo_type, status });
            }



        },


        //socket order_hold
        //done
        socket_orderHold({ dispatch, commit, state }, payload) {

            let { order_id, status, bar_status ,token} = JSON.parse(payload);

            console.log('hold event',token);

            if(token != state.token){
                return;
            }


            state.Called = state.Called.map(invoice => {
                if (invoice.id === order_id) {
                    invoice.status = status;
                    invoice.bar_status = bar_status;
                    return invoice;
                }
                return invoice;
            });
            state.tobeCalled = state.tobeCalled.map(invoice => {
                if (invoice.id === order_id) {
                    invoice.status = status;
                    invoice.bar_status = bar_status;
                    return invoice;
                }
                return invoice;

            })
        },



        ////


        init({ dispatch, commit, state }, { user, page }) {
            state.status = 'working'
            state.page = page;
            if (page === 'preperation') {
                state.visibiltiy.hideDishes = true;
            }
            dispatch('setUser', user).then(res => {

                dispatch('getInvoices');


                // console.log('setuser');

            }).catch(err => { console.log(err) })
        },
        refresh({ dispatch, commit, state }) {

            state.status = 'working';
            state.Called = [];
            state.tobeCalled = [];
            state.Served = [];
            state.Paid = [];
            state.timers = [];
            state.flip = [];
            dispatch('getInvoices')
        },
        setUser({ dispatch, commit, state }, user) {

            state.user = user;
            state.token = user.access_token;
            state.branch_id = user.branch_id;
            state.table_mode = user.table_mode;


        },



        visibiltiy({ dispatch, commit, state }, name) {

            state.visibiltiy[name] = !(state.visibiltiy[name]);



        },

        //tested and done
        prepareReOrderData({ dispatch, commit, state }, orders) {
            let result = orders.reduce(function (acc, order, index) {
                let sequence_string;
                let new_sequence = index + 1;
                let o = {
                    order_id: order.id
                }
                let f = acc.findIndex(item => item.order_id === o.order_id);
                if (f > -1) {
                    sequence_string = acc[f].sequence_string;
                } else {
                    sequence_string = order.sequence_string.split('-');

                }


                if (order.services.length) {
                    sequence_string[0] = new_sequence;
                } else if (order.tastings_services.length) {
                    sequence_string[1] = new_sequence
                } else if (order.bar.length) {
                    sequence_string[2] = new_sequence
                }
                o.sequence_string = sequence_string;
                if (f > -1) {
                    acc[f] = o;
                } else {
                    acc.push(o);
                }

                return acc;








            }, []);
            let sequences = result.map(obj => { return { order_id: obj.order_id, sequence_string: obj.sequence_string.join('-') } });
            let data = { sequences };
            //console.log(data);
            axios.post(`${URL}api/order/reSequence?key=app&client_token=${state.token}`, data).then(res => { console.log('reSequence', res) }).catch(err => { console.log(err) });
        },

        

        

        hideStation({ dispatch, commit, state }, { roles }) {
            let userRoles = state.user.roles.map(role => role.slug);
            // console.log('userroles', userRoles);
            let c = userRoles.some(role => {
                var regex = /super-/;
                let match = regex.exec(role.toLowerCase());
                // console.log('match',match);
                if (!match) {
                    return false;
                }
                return roles.indexOf(role) !== -1
            });

            if (c) {
                state.visibiltiy.hideStation = !(state.visibiltiy.hideStation);
            }

        },

        
        //socket order_transferred

        async socket_orderTransferred({ dispatch, commit, state }, data) {
            let userType = await dispatch('userType');

            data = JSON.parse(data);
            console.log(data);



            let { product_id, old_order, new_order, type, service_number, old_service_number } = data;


            if ((type === 'bar' && userType === "normal") || (type === 'normal' && userType === 'bar')) {
                //no need to proceed
                return;
            }



            let _type = type === 'normal' ? 'services' : 'bar';

            //if service is null suppose it as bar 
            old_service_number = old_service_number ? old_service_number : 'bar';
            service_number = service_number ? service_number : 'bar';

            //remove product from old invoice and get products removed

            let products = await dispatch('moveProductsFromInvoice', { product_id, old_order, old_service_number, _type });

            //try to find new invoice
            let calledIndex, tobecalledIndex, servedIndex, new_invoice;
            calledIndex = state.Called.findIndex(inv => inv.id === new_order && inv.category === _type);
            tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === new_order && inv.category === _type);
            servedIndex = state.Served.findIndex(inv => inv.id === new_order && inv.category === _type);
            if (calledIndex != -1) {
                new_invoice = state.Called[calledIndex];
            } else if (tobecalledIndex != -1) {
                new_invoice = state.tobeCalled[tobecalledIndex];
            } else if (servedIndex != -1) {
                new_invoice = state.Served[servedIndex];
            }

            // if invoice not found get it from server
            if (!new_invoice) {

                axios.get(`${URL}api/orders/${new_order}?key=app&client_token=${state.token}`).then(async res => {
                    let invoice = res.data;
                    let types = await dispatch('prepare', invoice);
                    new_invoice = types[_type];

                    //calculate section 
                    let section = await dispatch('calculate', new_invoice);
                    // insert invoice
                    dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice: new_invoice, section, reorder: false });


                }).catch(err => { console.log(err) });

            } else {
                //update service products if we find it
                if (new_invoice[_type].find(srv => srv.service_number === service_number)) {
                    new_invoice[_type] = new_invoice[_type].map(srv => {
                        if (srv.service_number === service_number) {
                            srv.products = srv.products.concat(products);
                            return srv;
                        }
                        return srv;
                    });

                } else {
                    //make new service
                    new_invoice[_type] = [...new_invoice[_type], { service_number, service_status: 'tobeCalled', call_date: null, products }]

                }

                //notify user
                let o = {
                    'order_id': old_order,
                    'changes': {},
                    'added': [],
                    'added_bar': [],
                    'deleted': []

                };

                new_invoice.orderUpdate = o;

                //calculate section 
                let section = await dispatch('calculate', new_invoice);

                // replace invoice
                dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice: new_invoice, section, reorder: false });





            }





        },

        async moveProductsFromInvoice({ dispatch, commit, state }, { product_id, old_order, old_service_number, _type }) {


            let calledIndex, tobecalledIndex, servedIndex, old_invoice;
            calledIndex = state.Called.findIndex(inv => inv.id === old_order && inv.category === _type);
            tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === old_order && inv.category === _type);
            servedIndex = state.Served.findIndex(inv => inv.id === old_order && inv.category === _type);
            if (calledIndex != -1) {
                old_invoice = state.Called[calledIndex];
            } else if (tobecalledIndex != -1) {
                old_invoice = state.tobeCalled[tobecalledIndex];
            } else if (servedIndex != -1) {
                old_invoice = state.Served[servedIndex];
            }

            let copy = [];


            old_invoice[_type] = old_invoice[_type].map(srv => {
                if (srv.service_number === old_service_number) {
                    let products = srv.products;
                    copy = products.filter(prod => prod.id === product_id);
                    srv.products = products.filter(prod => prod.id != product_id);

                    return srv;
                }
                return srv;
            });
            //check for empty services
            old_invoice[_type] = old_invoice[_type].filter(srv => srv.products.length > 0);

            //remove invoice if we have no services left
            if (old_invoice[_type].length === 0) {
                if (calledIndex != -1) {
                    state.Called.splice(calledIndex, 1);
                } else if (tobecalledIndex != -1) {
                    state.tobeCalled.splice(tobecalledIndex, 1);
                } else if (servedIndex != -1) {
                    state.Served.splice(servedIndex, 1);
                }

                return copy;
            }

            //notify user
            let o = {
                'order_id': old_order,
                'changes': {},
                'added': [],
                'added_bar': [],
                'deleted': []

            };
            old_invoice.orderUpdate = o;

            //recalculate invoice 
            let section = await dispatch('calculate', old_invoice);
            // replace invoice
            dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice: old_invoice, section, reorder: false });
            // return moved products 
            return copy;

        },
        changeIndex({ dispatch, commit, state }, { invoice, oldIndex, newIndex }) {

            state.Called.splice(oldIndex, 1);
            state.Called.splice(newIndex, 0, invoice);
            dispatch('prepareReOrderData', state.Called);
        },





        orderDeleted({ dispatch, commit, state }, data) {
            let { order_id } = data;
            //let order_id = 7;
            dispatch('deleteOrderById', order_id);


        },

        deleteOrderById({ dispatch, commit, state }, order_id) {
            let calledindexes = state.Called.map((inv, i) => inv.id === +order_id ? i : -1).filter(index => index != -1);
            if (calledindexes.length) {

                while (calledindexes.length) {
                    state.Called.splice(calledindexes.pop(), 1);
                }
            }


            let tobecalledindexes = state.tobeCalled.map((inv, i) => inv.id === +order_id ? i : -1).filter(index => index != -1);
            if (tobecalledindexes.length) {

                while (tobecalledindexes.length) {
                    state.tobeCalled.splice(tobecalledindexes.pop(), 1);
                }
            }
            let servedindexes = state.Served.map((inv, i) => inv.id === +order_id ? i : -1).filter(index => index != -1);
            if (servedindexes.length) {

                while (servedindexes.length) {
                    state.Served.splice(servedindexes.pop(), 1);
                }
            }
        },


        

        async call_service({ dispatch, commit, state }, data) {
            let { service_number, order_id, type, reorder } = data;
            let usertype = await dispatch('userType');
            if (usertype === 'bar') {
                if (type === 'services' || type === 'tastings_services') {
                    return;
                }
            } else if (usertype === 'normal') {
                if (type === 'bar') {
                    return;
                }
            }

            let invoice;
            let calledIndex = state.Called.findIndex(inv => inv.id === order_id && inv.category === type);
            let tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === order_id && inv.category === type);
            let servedIndex = state.Served.findIndex(inv => inv.id === order_id && inv.category === type);
            if (calledIndex != -1) {
                invoice = state.Called[calledIndex];
            } else if (tobecalledIndex != -1) {
                invoice = state.tobeCalled[tobecalledIndex];
            } else if (servedIndex != -1) {
                invoice = state.Served[servedIndex];
            } else {
                return;
            }


            invoice[type] = invoice[type].map(srv => {
                if (srv.service_number === service_number) {
                    srv.service_status = srv.service_status === "Called" ? "ToBeCall" : "Called";
                    if (srv.service_status === "Called") {
                        srv.call_date = Date.now();
                    }

                    return srv;
                }
                return srv;
            });

            let section = await dispatch('calculate', invoice);

            dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice, section, reorder: reorder });





        },



        

        async serve_item({ dispatch, commit, state }, data) {
            let usertype = await dispatch('userType');
            let { type, order_id, serv_info, service_number } = data;
            if (usertype === 'bar') {
                if (type === 'services' || type === 'tastings_services') {
                    return;
                }
            } else if (usertype === 'normal') {
                if (type === 'bar') {
                    return;
                }
            }

            let invoice;
            let calledIndex = state.Called.findIndex(inv => inv.id === order_id && inv.category === type);
            let tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === order_id && inv.category === type);
            let servedIndex = state.Served.findIndex(inv => inv.id === order_id && inv.category === type);
            console.log('indexes', calledIndex, tobecalledIndex, servedIndex)
            if (calledIndex != -1) {
                invoice = JSON.parse(JSON.stringify(state.Called[calledIndex]));
            } else if (tobecalledIndex != -1) {
                invoice = JSON.parse(JSON.stringify(state.tobeCalled[tobecalledIndex]));
            } else if (servedIndex != -1) {
                invoice = JSON.parse(JSON.stringify(state.Served[servedIndex]));
            } else {
                return;
            }



            invoice[type] = invoice[type].map(srv => {
                if (srv.service_number === service_number) {
                    srv.products = srv.products.map(prod => {
                        if (serv_info[prod.unique_id]) {
                            prod.isServed = serv_info[prod.unique_id].num;
                            prod.served_date = serv_info[prod.unique_id].date;
                            return prod;
                        }
                        return prod;
                    });
                }

                return srv;
            });


            //calculate invoice
            let section = await dispatch('calculate', invoice);
            dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice, section, reorder: false });


        },


        replace({ dispatch, commit, state }, data) {
            let { calledIndex, tobecalledIndex, servedIndex, invoice, section, reorder } = data;
            switch (section) {
                case 'Called':
                    if (tobecalledIndex != -1) {
                        state.tobeCalled.splice(tobecalledIndex, 1);
                    }
                    if (servedIndex != -1) {
                        state.Served.splice(servedIndex, 1);
                    }
                    if (calledIndex != -1) {
                        if (reorder) {
                            state.Called.splice(calledIndex, 1);
                            state.Called.push(invoice);
                        } else {
                            state.Called.splice(calledIndex, 1, invoice);
                        }

                    } else {
                        state.Called.push(invoice);
                    }
                    break;
                case 'tobeCalled':
                    if (calledIndex != -1) {
                        state.Called.splice(calledIndex, 1);
                    }
                    if (servedIndex != -1) {
                        state.Served.splice(servedIndex, 1);
                    }
                    if (tobecalledIndex != -1) {
                        state.tobeCalled.splice(tobecalledIndex, 1, invoice);
                    } else {
                        state.tobeCalled.push(invoice);
                    }

                    break;
                case 'Served':
                    if (calledIndex != -1) {
                        state.Called.splice(calledIndex, 1);
                    }
                    if (tobecalledIndex != -1) {
                        state.tobeCalled.splice(tobecalledIndex, 1);
                    }
                    if (servedIndex != -1) {
                        state.Served.splice(servedIndex, 1, invoice);
                    } else {
                        state.Served.push(invoice);
                    }

                    break;
            }

        },

        async  IOupdateInvoice({ dispatch, commit, state }, { data, reorder, merge }) {

            let validType = dispatch('validType', data);

            let section = dispatch('calculate', data);
            //let { calledIndex, tobecalledIndex, servedIndex } = await dispatch('getIndexes', data);
            let indexes = dispatch('getIndexes', data);

            //console.log('indexes',await indexes);return

            if (!(await validType)) {
                return;
            }
            let oldinvoice;
            let newInvoice = data;

            let { calledIndex, tobecalledIndex, servedIndex } = await indexes;

            if (calledIndex != -1) {
                oldinvoice = state.Called[calledIndex];
            }
            if (tobecalledIndex != -1) {
                oldinvoice = state.tobeCalled[tobecalledIndex];

            }
            if (servedIndex != -1) {
                oldinvoice = state.Served[servedIndex];
            }
            if (merge) {
                newInvoice = megreWithold(oldinvoice, newInvoice);
            }

            section = await section;

            dispatch('replace', { calledIndex, tobecalledIndex, servedIndex, invoice: newInvoice, section, reorder });


            function megreWithold(oldInvoice, newInvoice) {
                if (oldInvoice) {
                    if (oldInvoice.orderUpdate != undefined) {
                        if (newInvoice.orderUpdate != undefined) {

                            newInvoice.orderUpdate = {
                                'order_id': newInvoice.id,
                                'changes': newInvoice.orderUpdate.changes,
                                'added': newInvoice.orderUpdate.added.concat(oldInvoice.orderUpdate.added),
                                'added_bar': newInvoice.orderUpdate.added_bar.concat(oldInvoice.orderUpdate.added_bar),
                                'deleted': newInvoice.orderUpdate.deleted.concat(oldInvoice.orderUpdate.deleted)
                            }

                        } else {
                            newInvoice.orderUpdate = oldInvoice.orderUpdate;
                        }
                    }
                }


                return newInvoice



            }

            state.status = 'Ready';
            //state.key++;



        },



        setPaidInvoice({ dispatch, commit, state }, invoice) {

            let order_id = invoice.id;
            dispatch('deleteOrderById', order_id);

            state.Paid.push(invoice);
        },


        




        

        getInvoices({ dispatch, commit, state }) {

            function compare(a, b) {

                if (+a.order < +b.order) {
                    return -1;
                }
                if (+a.order > +b.order) {
                    return 1;
                }
                return 0;
            }
            let o = {
                Called: [],
                tobeCalled: [],
                Served: [],
                Paid: []
            };



            //     for(var i=0;i<200;i++){
            //         let invoice = data;

            //         invoice.id = i+1;
            //         invoice.table_number = i+1
            //         let { services, tastings_services, bar } = await dispatch('prepare', invoice);
            //         o.Called.push(services);
            //     }





            // state.Called = o.Called;
            // state.status = 'Ready';



            let orders = axios.get(`${URL}api/orders?key=app&client_token=${state.token}`);
            let paidInvoices = axios.get(`${URL}api/orders?key=paid&client_token=${state.token}`);


            Promise.all([orders, paidInvoices]).then(res => {
                // console.log(res);
                let invoices = res[0].data;
                //let invoices =data;
                let paidInvoices = res[1].data;
                (async function () {
                    for (var i = 0; i < invoices.length; i++) {
                        let { services, tastings_services, bar } = await dispatch('prepare', invoices[i]);
                        let status;
                        if (services) {
                            status = await dispatch('calculate', services);
                            o[status].push(services);
                        }
                        if (tastings_services) {
                            status = await dispatch('calculate', tastings_services);
                            o[status].push(tastings_services);
                        }
                        if (bar) {
                            status = await dispatch('calculate', bar);
                            o[status].push(bar);
                        }

                    }

                    o.Called = o.Called.sort(compare);


                    //state.key++;

                    state.Called = o.Called;
                    state.tobeCalled = o.tobeCalled;
                    state.Served = o.Served;
                    //state.Paid = o.Paid;
                    // console.log('getinovices');

                })();



                state.Paid = paidInvoices;
                state.status = 'Ready';

            }).catch(err => { console.log(err) });

        },




        rollBack({ dispatch, commit, state }, { oldInvoice, t }) {
            //oldInvoice.error = true;
            //t.$socket.emit('updateinvoices', JSON.stringify({ data: oldInvoice, reorder: false, merge: false }));

        },
        requestAPI({ dispatch, commit, state }, payload) {
            let { oldInvoice, newInvoice, url, requestType, requestInfo, type, order_id, t } = payload;

            //console.log('befor request');
            axios[requestType](`${url}?key=app&client_token=${state.token}`, requestInfo).then(res => {
                let response = res.data;
                //console.log('after request',response);
                // emit undo
                let lastAction = {
                    url: `${url}?key=app&client_token=${state.token}`,
                    payload: requestInfo,
                    order_id: order_id,
                    type: type

                };
                //set undo
                localStorage.setItem('invo_' + lastAction.type + lastAction.order_id, JSON.stringify(lastAction));
                // event
                //io.emit('undo', JSON.stringify(lastAction));
                t.$socket.emit('undo', JSON.stringify(lastAction));




            }).catch(err => {
                console.log(err);

                //alert('request error');
                //rollback
                // dispatch('rollBack', {oldInvoice,t});
            });
        },

        

        setTimer({ dispatch, commit, state }, payload) {

            //console.log('timer');
            if (payload.duration == 0) {
                let index = state.timers.findIndex(t =>
                    t.invoid === payload.invoid
                    && t.srvnumber === payload.srvnumber
                    && t.id === payload.id
                    && t.isTasting === payload.isTasting
                    && t.isBar === payload.isBar
                );
                if (index != -1) {

                    state.timers.splice(index, 1);
                }
            } else {
                state.timers.push(payload);
            }




        },

        
        getIndexes({ dispatch, commit, state }, invoice) {
            let calledIndex, tobecalledIndex, servedIndex;
            if (invoice.services.length) {
                calledIndex = state.Called.findIndex(inv => inv.id === invoice.id && inv.services.length > 0);
                tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === invoice.id && inv.services.length > 0);
                servedIndex = state.Served.findIndex(inv => inv.id === invoice.id && inv.services.length > 0);
            } else if (invoice.tastings_services.length) {
                calledIndex = state.Called.findIndex(inv => inv.id === invoice.id && inv.tastings_services.length > 0);
                tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === invoice.id && inv.tastings_services.length > 0);
                servedIndex = state.Served.findIndex(inv => inv.id === invoice.id && inv.tastings_services.length > 0);
            } else if (invoice.bar.length) {
                calledIndex = state.Called.findIndex(inv => inv.id === invoice.id && inv.bar.length > 0);
                tobecalledIndex = state.tobeCalled.findIndex(inv => inv.id === invoice.id && inv.bar.length > 0);
                servedIndex = state.Served.findIndex(inv => inv.id === invoice.id && inv.bar.length > 0);
            }
            return { calledIndex, tobecalledIndex, servedIndex };

        },

        userType({ dispatch, commit, state }) {
            let user = state.user;
            let roles = user.roles;
            let super_bar = roles.find(role => role.slug === 'super_bar');
            if (super_bar) {
                return 'bar';
            } else {
                return 'normal';
            }

        },
        async  validType({ dispatch, commit, state }, invoice) {
            let userType = await dispatch('userType');
            if (userType === 'bar') {
                if (invoice.bar.length) {
                    return true;
                } else {
                    return false;
                }
            } else if (userType === 'normal') {
                if (invoice.services.length || invoice.tastings_services.length) {
                    return true;
                } else {
                    return false;
                }
            }
        },
        async  prepare({ dispatch, commit, state }, invoice) {
            let services, tastings_services, bar;
            let userType = await dispatch('userType');
            // let roles = state.user.roles.map(role => role.slug);
            // let page = state.page;
            let sequence_string = invoice.sequence_string.split('-');

            switch (userType) {
                case 'normal':

                    if (invoice.services.length) {
                        //copy
                        services = { ...invoice };
                        services.order = sequence_string[0];
                        services.category = 'services';
                        services.key = services.id + 'services';

                        services.tastings_services = [];
                        services.tastings_header = [];
                        services.bar = [];


                    }
                    if (invoice.tastings_services.length) {
                        tastings_services = { ...invoice };
                        tastings_services.category = 'tastings_services';
                        tastings_services.key = tastings_services.id + 'tastings_services';
                        tastings_services.order = sequence_string[1];
                        tastings_services.services = [];
                        tastings_services.bar = [];

                    }
                    break;
                case 'bar':
                    if (invoice.bar.length) {
                        bar = { ...invoice };
                        bar.category = 'bar';
                        bar.key = bar.id + 'bar';
                        bar.order = sequence_string[2];
                        bar.services = [];
                        bar.tastings_services = [];
                        bar.tastings_header = [];
                        bar.bar = [
                            {
                                'service_number': 'bar',
                                'service_status': 'Called',
                                'call_date': null,
                                'products': bar.bar

                            }
                        ];


                    }
                    break;

            }



            return { services, tastings_services, bar };





        },

        
        async calculate({ dispatch, commit, state }, inv) {
            let Paid = dispatch('calualtePaid', inv);
            let Called = dispatch('calculateCalled', inv);
            let tobeCalled = dispatch('calculatetobeCalled', inv);
            let Served = dispatch('calculateServed', inv);
            if (await Paid) {
                return 'Paid';
            }

            if (await Called) {
                return 'Called';
            }

            if (await tobeCalled) {
                return 'tobeCalled';
            }

            if (await Served) {
                return 'Served';
            }
        },
        calculateCalled({ dispatch, commit, state }, inv) {
            //we can check if invoice is regular or tasting
            // let services = inv.services.concat(inv.tastings_services);
            let services = [...inv.services, ...inv.tastings_services, ...inv.bar];
            let result = false;
            for (var i = 0; i < services.length; i++) {
                let products = services[i].products;

                if (!(services[i].service_status === "Called")) {
                    continue;
                }
                let notServedItems = products.filter((product) => {
                    return product.isServed != 2;
                });
                if (notServedItems.length) {
                    result = true;
                    break;

                }



            }


            return result;

        },
        calculatetobeCalled({ dispatch, commit, state }, inv) {
            //we can check if invoice is regular or tasting
            // let services = inv.services.concat(inv.tastings_services);
            let services = [...inv.services, ...inv.tastings_services, ...inv.bar];
            let result = true;
            let atleast = false;

            for (var i = 0; i < services.length; i++) {
                let products = services[i].products;
                if (!(services[i].service_status === 'Called')) {
                    atleast = true;
                    continue;
                }
                let notServedItems = products.filter((product) => {
                    return product.isServed != 2;
                });
                if (notServedItems.length) {
                    result = false;
                    break;

                }



            }

            return result && atleast;
        },
        calculateServed({ dispatch, commit, state }, inv) {
            //we can check if invoice is regular or tasting
            // let services = inv.services.concat(inv.tastings_services);
            let services = [...inv.services, ...inv.tastings_services, ...inv.bar];
            let result = true;
            for (var i = 0; i < services.length; i++) {
                let products = services[i].products;
                if (!(services[i].service_status === 'Called')) {
                    result = false;
                    break;
                }
                let notServedItems = products.filter((product) => {
                    return product.isServed != 2;
                });
                if (notServedItems.length) {
                    result = false;
                    break;

                }



            }

            return result;
        },
        calualtePaid({ dispatch, commit, state }, inv) {
            if (inv.status === 'closed') {
                return true;
            } else {
                return false;
            }
        }

    },
    getters: {
        filterProducts: (state) => (orders) => {

            let page = state.page;
            let roles = state.user.roles.map(role => role.slug);

            let result = orders.map(order => {
                if (page === 'preperation') {
                    if (order.services.length) {

                        order.services = order.services.map(service => {
                            service.products = service.products.filter(product => {

                                let check = product.roles.some(role => roles.indexOf(role.toLowerCase()) !== -1);

                                return check;

                            })
                            return service;
                        });
                    } else if (order.tastings_services.length) {
                        order.tastings_services = order.tastings_services.map(service => {
                            service.products = service.products.filter(product => {
                                let canSeeTasting = roles.indexOf('tasting-admin') !== -1;
                                if (canSeeTasting) {
                                    return true;
                                }
                                return product.roles.some(role => roles.indexOf(role.toLowerCase()) !== -1);
                            });

                            return service
                        });

                    } else if (order.bar.length) {
                        order.bar = order.bar.map(service => {
                            service.products = service.products.filter(product => {
                                let check = product.roles.some(role => roles.indexOf(role.toLowerCase()) !== -1);
                                return check;

                            })
                            return service;
                        });
                    }
                }

                return order;
            });

            return result;

        },
        myProduct: (state) => (isTasting, product) => {
            let roles = state.user.roles.map(role => role.slug);
            if (isTasting) {
                let canSeeTasting = roles.indexOf('tasting-admin') !== -1;
                if (canSeeTasting) {
                    return true;
                }
                return product.roles.some(role => roles.indexOf(role.toLowerCase()) !== -1);

            } else {
                return product.roles.some(role => roles.indexOf(role.toLowerCase()) !== -1) || roles.indexOf("branch_admin") != -1;
            }
        }


    }
});

export default store;