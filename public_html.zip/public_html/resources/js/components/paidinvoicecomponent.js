const URL = require('./config');
const paidinvoicecomponent = {


    props:['invoice'],
    data(){
        return {
            
        }
    },
    mounted(){
        if(this.$store.state.page === 'supervisor'){
            let $Supermasonry = new Masonry('.supervisor-container', {
                // masonry options go in here
               // see https://masonry.desandro.com/#initialize-with-vanilla-javascript
                itemSelector: '.card',
                columnWidth:1,
                // use element for option
                //columnWidth: '.invoice-size',
                //percentPosition: true,
                horizontalOrder: true,
                //originTop: false,
                isFitWidth: true,
                gutter : 4
              });
        }
    },
    computed:{
            invo(){
                let invoice = this.invoice;
                invoice.created_at = moment(invoice.created_at.date).format('hh:mm');
                return invoice;
            }
    },

    template:'#paidInvoice'
}

module.exports = paidinvoicecomponent;