
const masonry = require('./masonry');

const tobecalledcomponent = {
    props:[],
    data:function(){
        return {
           
            
        };
    },
    mounted:function(){

    },
    updated(){
        console.log('tobeCalled component updated');

       let layout = masonry.bind(this);
       layout();
    },
    computed:{
        
        tobecalledOrder :{
            get(){
                return this.$store.state.tobeCalled;
            }
        },
        
      
    },
    methods:{

        

         
         

    },
    template:"#tobecalledcomponent"
}

module.exports = tobecalledcomponent;