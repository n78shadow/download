<template>
    <div  id="dishes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Item Name</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row readyDishes" >
                        <div class="col" v-for="num in dishnumber" v-bind:key="num">
                            <button type="button" class="btn btn-block btn-lg btn-light">{{num}}</button>
                        </div>
                        
                    </div>
                    <hr>
                    <div class="row timer">
                        <div class="col text-left" style="margin-top: 1rem">
                            <h4 class="text-secondary"><i class="fas fa-stopwatch"></i> Timer:{{sec}}</h4>
                        </div>
                        <div class="col text-right" style="margin-top: 1rem">
                            <button type="button" class="btn btn-block btn-lg btn-danger">Remove Timer</button>
                        </div>
                        <div class="w-100"></div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" v-bind:click="countdown(5)">5</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">10</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">15</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">20</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">25</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">30</button>
                        </div>
                        <div class="w-100"></div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">35</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">40</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">45</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">50</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">55</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary">60</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props:['dishnumber'],
        data() {
            return {
                sec:""
            };
        },
        computed:{
            
        },
        methods: {
            countdown:function(num){
                console.log('count down');
                let second = 60;
                let minut = num;
                this.sec= second;

                

                setInterval(function(){
                    second --;



                },1000);
                
            }
            
            
        }
    };
</script>

