
const URL = require('./config');
const masonry = require('./masonry');



const invoicecomponent = {
    props:['invoice','index','section'],
    data:function(){
        return {
            
            numpad:false,
            entireHide:false,
            changes:null,
            layout: masonry.bind(this)
            
          
            

        }
    },
    mounted:function(){
        
        //console.log('invoice mounted');
      
        this.layout();
  
          
    },
    created:function(){

       // console.log('invoice created');
        //none reactive prop
      // this.order = this.index + 1;
    },
    updated:function(){
      

        console.log('invoice updated',this.invoice.table_number + this.type);

        this.layout();

    },
    computed: {
        // inVisibleServices : function(){
        //     return this.hideServices;
        // },

        title : function(){
            let mode = this.$store.state.table_mode;
            if(mode === 'take-out'){
                    return this.invoice.id;
                // let invoice = this.invoice.invoices[0];
                // if(invoice){

                // }
            }else{
                let p1 = this.invoice.table_number.toString().match(/^\d+$/) ? 'T':'O';
                let p2 = this.invoice.table_number;
                return p1 + ':' + p2;
            }
        },

        buttons:function(){
            let mode = this.$store.state.table_mode;
            return mode != 'take-out';
        },


        invo:{
            catch:true,
            get:function(){
                //copy
    
               // console.log('recalcualte invo');
                let invoice = JSON.parse(JSON.stringify(this.invoice));
                console.log('invoice',invoice);
                let time = moment(invoice.created_at.date).format('hh:mm');
                let deleted_bar = null;
                let deleted_normal = null;
                let permDeleted_normal = [];
                let permDeleted_bar = [];
                let deleted = invoice.orderUpdate ? invoice.orderUpdate.deleted:null;
               
                if(Array.isArray(deleted)){
                    deleted_bar = deleted.filter(o=>o.service_number === null);
                    deleted_normal = deleted.filter(o=>o.service_number != null);
                }
               
                let added = invoice.orderUpdate ? invoice.orderUpdate.added : null;
                let added_bar = invoice.orderUpdate ? invoice.orderUpdate.added_bar:null;
               // let changes = invoice.orderUpdate ? invoice.orderUpdate.changes : null;
    
                let t = this;
        
                let services = [...invoice.services,...invoice.tastings_services,...invoice.bar];
                services = services.map((srv)=>{
                        
                        let products = srv.products.reduce(function(acc,curr){
                            
    
                                let{indexs,deletedNum} = ( curr.isServed === "2" || curr.isServed === "1")  ? {indexs:[],deletedNum:0}: t.deleted(deleted_normal,srv.service_number,curr.id); 
                                let{match,addNum} = (curr.isServed === "2" || curr.isServed === "1" ) ? {match:[],addNum:0} : t.added(added,srv.service_number,curr.id);
                                let{bar,addedBar} = (curr.isServed === "2" || curr.isServed === "1") ? {bar:[],addedBar:0} : t.addedBar(added_bar,curr.id);
                                let{barIndexs,BarDeletedNum} = (curr.isServed === "2" || curr.isServed === "1") ? {barIndexs:[],BarDeletedNum:0}: t.deletedBar(deleted_bar,curr.id);
                           
                            
    
    
    
    
                            
                            //delete indexes from deleted
                            if(indexs.length){
                                for(var i=0;i<indexs.length;i++){
                                    deleted_normal.splice(indexs[i],1);
                                }
                            }
                            if(barIndexs.length){
                                for(var i=0;i<barIndexs.length;i++){
                                    deleted_bar.splice(barIndexs[i],1);
                                }
                            }

                            if(curr.note){
                                curr.product_customizes = [...curr.product_customizes,{id:null,custom_name:curr.note}];
                            }
                            
                            var o ={
                                'id':curr.id,
                                'dish_number':[{number:curr.dish_number,unique_id:curr.unique_id}],
                                'deletedNum':deletedNum,
                                'addedNum': addNum,
                                'addedBar':addedBar,
                                'deletedBar':BarDeletedNum,
                                'en_name':curr.en_name,
                                'short_name': curr.short_name,
                                'tasting_name': curr.tasting_name,
                                'cost': curr.cost,
                                'price': curr.price,
                                'roles':curr.roles,
                                'timer':curr.timer,
                                'category_color': curr.category_color,
                                //'note': curr.note,
                                'call_time':curr.call_time != null ? [curr.call_time]:[],
                                'served_date':curr.served_date ? [curr.served_date]: [],
                                'clients':curr.client_number,
                                'isServed': curr.isServed === "2" ? [curr.dish_number] : [],
                                'isReady': curr.isServed === "1" ? [curr.dish_number] : [],
                                'product_customizes':[
                                    {'dish_number':curr.dish_number,'options':curr.product_customizes.concat(curr.product_optionals),'client_number':curr.client_number}
                                ]
                            };
                            let f = acc.findIndex(function(item){
                                    let dishState;
                                    if(o.isServed.length){
                                        dishState = item.isServed.length > 0;
                                    }else if(o.isReady.length){
                                        dishState = item.isReady.length > 0;
                                    }else{
                                        dishState = item.isServed.length === 0 && item.isReady.length === 0;
                                    }
                                    
                                    return item.id === o.id && dishState;
                            });
                            if(f === -1){
                                acc.push(o);
                            }else{
    
                                    acc[f].product_customizes = acc[f].product_customizes.concat(o.product_customizes);
                                    acc[f].clients = _.union(acc[f].clients,o.clients);
                                    acc[f].dish_number = acc[f].dish_number.concat(o.dish_number);
                                    acc[f].call_time = acc[f].call_time.concat(o.call_time);
                                    acc[f].served_date = acc[f].served_date.concat(o.served_date);
                                    acc[f].isServed = acc[f].isServed.concat(o.isServed);
                                    acc[f].isReady = acc[f].isReady.concat(o.isReady);
                                
                                
                                
                            }
    
                          
                            
                            
                            
                            return acc;
                        },[]);
    
    
                        //customiz
                        products = this.customize(products);
    
    
    
    
    
                    srv.products = products;
                   
                    let date = srv.call_date ? moment(srv.call_date).format('hh:mm'): null;
                    
                    srv.call_date = date;
                    return srv;
                
                });
                invoice.services = services;
    
             
    
                if(Array.isArray(deleted_normal) && this.type === 'services'){
                    
                    permDeleted_normal = deleted_normal.reduce(function(acc,curr){
                        
                        let f = acc.findIndex(o=>o.product_id === curr.product_id);
                        if(f == -1){
                            acc.push(curr);
                        }else{
                            acc[f].deleted_count = acc[f].deleted_count + curr.deleted_count;
                        }
                        return acc;
                },[]);
                
            }
            if(Array.isArray(deleted_bar) && this.type === 'bar'){
                    
                permDeleted_bar = deleted_bar.reduce(function(acc,curr){
                    
                    let f = acc.findIndex(o=>o.product_id === curr.product_id);
                    if(f == -1){
                        acc.push(curr);
                    }else{
                        acc[f].deleted_count = acc[f].deleted_count + curr.deleted_count;
                    }
                    return acc;
            },[]);
            
            
        }
    
                
                invoice.created_at = time;
                this.orderUpdate();
                invoice.permDeleted_normal = permDeleted_normal;
                invoice.permDeleted_bar = permDeleted_bar;
                invoice.category = this.type;
                return invoice;
    
            }

        },
        

        showall : function(){
            return this.$store.state.visibiltiy.showall;
        },
        
        hold : function(){
            let type = this.type;
            if(type === 'bar'){
                return this.holdBar === 'hold';
            }else{
                return this.holdNormal === 'hold';
            }
        },
        holdNormal: function(){
            
            return this.invoice.status;
            
          
        },
        otherKitchen:function(){

            
            const kitchens = {
                'super-salad':'rgb(255, 171, 145)',
                'super-grill':'rgb(158, 158, 158)',
                'super-suate':'rgb(244, 81, 30)',
                'superbar':''
            
            }

            let otherKitchen = [];
            //let roles = this.$store.state.user.roles.map(role=>role.slug);
            //let myKitchen = roles.find(role=>kitchens[role.toLowerCase()] !== undefined);
            let invoice = this.invoice;
            if(this.type === 'services'){
                let services = invoice[this.type];
                   // console.log('inside services otherkitchen')
                loop1:
                for(var i=0;i<services.length;i++){
                        let products = services[i].products;
                        loop2:
                        for(var j=0;j<products.length;j++){
                            let product = products[j];
                            //let sameKit = product.roles.some(role=>roles.indexOf(role.toLowerCase()) !== -1);
                            let sameKit = this.$store.getters.myProduct(false,product);
                            
                            if(!sameKit){
                                let kitchen = product.roles.find(role=>kitchens[role.toLowerCase()] !== undefined);
                               // console.log('kitchen',kitchen)
                                if(kitchen){
                                    if(otherKitchen.indexOf(kitchen) === -1){
                                        otherKitchen.push(kitchen);
                                    }
                                }
                                
                            }
                        }
                }
            }
            if(otherKitchen.length){
                otherKitchen = otherKitchen.map(kitchen=>{  
                    return {name:kitchen,color:kitchens[kitchen]}
                });
            }
           
            return otherKitchen;
            
        },
       
        holdBar : function(){
            return this.invoice.bar_status;
        },
        tasting : function(){
            return this.invoice.tastings_services.length ? true:false;
        },
        bar : function(){
            return this.invoice.bar.length ? true:false;
        },
        normal:function(){
            return this.invoice.services.length ? true:false;
        },
        type:function(){
            return this.invoice.category;
            // if(this.invoice.tastings_services.length){
            //     return 'tastings_services';
            // }else if(this.invoice.bar.length){
            //     return 'bar';
            // }else if(this.invoice.services.length){
            //     return 'services';
            // }
        },
        
        error:function(){
            return this.invoice.error ? true : false;
        },
        isInnerSuper:function(){
            let roles = this.$store.state.user.roles;
            let s_super = roles.filter(role=>role.slug === 's-super');
            if(s_super.length){
                return true;
            }
            return false;

        },
        flip:function(){
            let f = this.$store.state.flip.find(o=>o.invo_id === this.invoice.id && o.invo_type === this.type);
            if(f){
                return f.status;
            }
            return false;
        }
        
        
        
      },
      watch:{
            
              
          
        
      },
    methods:{

        orderUpdate:function(){
            
            let t=this;
            let changes = this.invoice.orderUpdate ? this.invoice.orderUpdate.changes : false;
            if(typeof changes === 'object' && !(Array.isArray(changes))){
                this.changes = changes ;
                setTimeout(()=>{
                    t.changes = null;
                    this.invoice.orderUpdate.changes = null;
                },20000);
            }else{
                this.changes = null;
            }


        },
        invoiceVisibiltyChanged:function(){

                // apply only for  supervisor 
                if(this.section != 'called'){
                    return;
                }
                let children = this.$children;
                let isAllserviceHidden = 0;
                let page = this.$store.state.page;
                for(var i=0;i<children.length;i++){
                    let child = children[i];
                    if(page === 'supervisor'){
                        
                        if(!child.showService || !child.srvShowAll){
                            isAllserviceHidden++;
                        }
                    }else{
                        if(!child.showService || !child.hideStation){
                            isAllserviceHidden++;
                        }else if(child.isAllServedKitchen){
                            isAllserviceHidden++;
                        }
                    }
                    
                }
                if(isAllserviceHidden === children.length){
                    this.entireHide = true;
                }else{
                    this.entireHide = false;
                }


              


        },

        updateThis:function(invoice,reorder){
                    let token = this.$store.state.token;

                    this.$store.dispatch('prepare',invoice).then(res=>{
                        

                        // update local
                        this.$store.dispatch('IOupdateInvoice',{data:res[this.type],reorder:reorder,merge:false});
                        
                        // event
                        this.$socket.emit("updateinvoices",JSON.stringify({data:res[this.type],reorder:reorder,merge:false,token})); 
                        
                    }).catch(err=>{
                        
                        
                    });
                    


               
        },

        confirm(intend,callback){
            let str;
            if(intend === 'holding'){
                    str = this.hold ? 'UnHolding':'Holding';
            }else if(intend === 'undo'){
                    str = 'Undo'
            }
           
            
            this.$dialog
            .confirm(`Are you sure ${str} order: ${this.invoice.table_number} `,{animation: 'fade',backdropClose: true})
            .then(function (dialog) {
               // console.log('Clicked on proceed');
                callback();
            })
            .catch(function () {
                console.log('Clicked on cancel');
            });
        },


        undo : function(){

            let lastAction = JSON.parse(localStorage.getItem('invo_'+this.type+this.invo.id)); 
            if(lastAction === null){
                return;
            }
            this.$store.commit('setStatus','working');
            let { url, payload, order_id,type }  = lastAction;

            axios.post(url,payload).then(res=>{
                let data = res.data;
                this.$store.commit('setStatus','Ready');

                this.updateThis(data.data,false);
            }).catch(err=>{console.log(err)});
            
            
        },
        hidenumpad : function(){
            this.numpad =false;
        },
        shownumpad : function(){
            if(this.$store.state.currentTab === 'called'){
                this.numpad =true;
            }
            
        },
        sethold:function(){
            //this.$store.commit('setStatus','working');
            let token = this.$store.state.token;
            let status = this.hold ? 'active':'hold';
            let holdNormal = this.holdNormal;
            let holdBar = this.holdBar;
            let data;
            let type = this.type;
            if(type === 'bar'){
               data = {order_id:this.invo.id,status:holdNormal,bar_status:status,token};
            }else{
                data = {order_id:this.invo.id,status:status,bar_status:holdBar,token}; 
            }
           // io.emit('hold',JSON.stringify(data));
           this.$socket.emit('hold', JSON.stringify(data));
        axios.post(`${URL}api/order/changeStatus?key=app&client_token=${token}`,data).then(res=>{
                
                
                //this.$store.commit('updateinvoices',{id:this.invo.id,reorder:false});

            }).catch(err=>{console.log(err)});
            
        },
        setflip : function(){
            let status = !this.flip
            let token = this.$store.state.token;
            //io.emit('flip',JSON.stringify({status,invo_id:this.invo.id,invo_type:this.type}));
            this.$socket.emit('flip',JSON.stringify({status,invo_id:this.invo.id,invo_type:this.type,token}));
        },
        customize : function(products){
            let result = products.map(pro=>{
                    
                    let clients = pro.clients
                    let product_customizes = pro.product_customizes;
                   // let dish_number = pro.dish_number;
                    let checkEmpty = 0;
                    for(var i=0;i<product_customizes.length;i++){
                        if(product_customizes[i].options.length == 0){
                            checkEmpty++;
                            break;
                        }
                    }

                    let f = function(){
                        let ClientsWithOptions = product_customizes.reduce(function(acc,curr){
                            if(curr.options.length){
                                acc = _.union(acc,curr.client_number);
                                

                            }
                            return acc;

                        },[]);
                        let remain = _.difference(clients,ClientsWithOptions);
                        return remain;
                    }
                   
                    if(checkEmpty > 0){
                        
                        
                        pro.clients = f();
                        return pro;
                    }else{
                        let i = 0;
                        let compare = true;
                        
                        while(i < product_customizes.length -1){
                            
                           compare =  this.compareTwoArray(product_customizes[i].options,product_customizes[++i].options);
                           
                           if(!compare){
                               break;
                           }
                        }
                        if(compare){
                            product_customizes = [{'dish_number':'','options':product_customizes[0].options,'client_number':[]}];
                            pro.product_customizes = product_customizes;
                         
                          
                            return pro;
                        }else{
                            pro.clients = f();
                            return pro;
                        }


                    }
                    //return pro;

                    
                    

            });
            return result;
        },
        compareTwoArray:function(arr,arr2){
            let s1 = arr.sort(this.compare);
            let s2 = arr2.sort(this.compare);
            return _.isEqual(s1,s2);
        },
        compare : function(a,b){
            if(a.id < b.id){
                return -1;
            }
            if(a.id > b.id){
                return 1;
            }
            return 0;
        },
        deleted:function(deletedArry,service_number,product_id){
            let isTasting = this.tasting;
            let deletedNum = 0;
            let indexs = [];
            if(Array.isArray(deletedArry) && !isTasting){
             
                /*
                    if we found object match prodcut id and servece number
                */
                 indexs =  deletedArry.reduce(function(acc,curr,index){
                    if(curr.service_number === service_number && curr.product_id === product_id){
                        deletedNum += curr.deleted_count;
                        acc.push(index);
                    }
                    return acc;
                },[]);

            }

            return {indexs:indexs,deletedNum:deletedNum};


        },
        added:function(addArry,service_number,product_id){
            let isTasting = this.tasting;
            let addNum = 0;
            let match = [];
            if(Array.isArray(addArry) && !isTasting){
                /*
                    if we found object match prodcut id and servece number
                */
                 match =  addArry.reduce(function(acc,curr,index){
                    if(curr.service_number === service_number && curr.product_id === product_id){
                        addNum += curr.added_count;
                        acc.push(index);
                    }
                    return acc;
                },[]);

            }

            return {match:match,addNum:addNum};


        },
        deletedBar : function(deletedArry,product_id){
            let isBar = this.bar;
            let deletedNum = 0;
            let indexs = [];
            if(Array.isArray(deletedArry) && isBar){
               
               // console.log('from inside detetedbar bardeleted',deletedArry);
                /*
                    if we found object match prodcut id and servece number
                */
                 indexs =  deletedArry.reduce(function(acc,curr,index){
                    if(curr.service_number === null && curr.product_id === product_id){
                        deletedNum += curr.deleted_count;
                        acc.push(index);
                    }
                    return acc;
                },[]);

            }

            return {barIndexs:indexs,BarDeletedNum:deletedNum};
        },
        addedBar : function(added,product_id){
            let addNum = 0;
            let match = [];
            if(Array.isArray(added)){
                match = added.reduce(function(acc,curr,index){
                    if(curr.product_id === product_id){
                        addNum += curr.added_count;
                        acc.push(index);
                    }
                    return acc;
                },[]);
            }

            return {bar:match,addedBar:addNum};
        },
       
        
        
        
        
       
    },
    template:"#invoicecomponent"

    

        
}


module.exports = invoicecomponent;