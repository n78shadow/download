

const paidcomponent = {
    props:[],
    data:function(){
        return {};
    },
    mounted:function(){

    },
    computed:{
        paidInvoices : function(){
            return this.$store.state.Paid;
        }
    },
    methods:{

    },
    template:"#paidcomponent"
}

module.exports = paidcomponent;