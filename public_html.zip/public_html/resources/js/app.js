
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');
window.axios = require('axios');
window._  = require('underscore');
window.moment = require('moment');

import Vuex from 'vuex';
Vue.use(Vuex);




//window.masonry = require('masonry-layout');
//window.$ = window.jQuery = require('jquery');

//socket
// window.io = require('socket.io-client')("http://147.135.23.120:2053");


/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

//Vue.component('example-component', require('./components/ExampleComponent.vue'));

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key)))

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */
    
 //new category


//Vue.component('newEditCat', require('./components/newEditcat'))


  // all categories

//Vue.component('allCats', require('./components/allcats'))


  //////////////////////////////////////


// const app = new Vue({
//     el: '#app',
//     data:{
        
//         num:[1,2,3,4],
//         title:"title",
//         all:true,
//         editcat:false,
//         pr:[],
//         currentRoute : "allCats"
     
//     },
//     mounted:function(){
//         console.log(this.currentRoute);
//     },
//     computed:{
//         ViewComponent:function(){

//         },
      
//     },
//     render:function(h){
        
//         var t= h(this.currentRoute,{props:Object.assign({renderOther:this.parentmethod},{fromPrent:this.pr})});
//         console.log(t);
//         return t;
//     },
//     methods:{
        
//         parentmethod:function(){
//             console.log(arguments);
//             var routeName = arguments[0];
//             this.currentRoute = routeName;
//             this.pr = arguments;
//             //this.ViewComponent()
//         }
//     }
// });
