

const URL = require('./../components/config');
//const masonry = require('./../components/masonry.js');
Vue.component("called", require('./../components/calledcomponent'));
Vue.component("tobecalled", require('./../components/tobecalledcomponent'));
Vue.component("served", require('./../components/servedcomponent'));
Vue.component("paid", require('./../components/paidcomponent'));
Vue.component("invoice", require('./../components/invoicecomonent'));
Vue.component("itemcomponent", require('./../components/itemcomponent.js'));
Vue.component("servicecomponent", require('./../components/servicecomponent.js'));
Vue.component("paidinvoicecomponent", require('./../components/paidinvoicecomponent.js'));
Vue.component("easynumpad", require('./../components/easy-numpad.js'));
Vue.component('modal', require('./../components/modalcomponent'));
Vue.component('counter',require('./../components/counter.js'));

import VueWorker from 'vue-worker'
Vue.use(VueWorker)

Vue.component('clock',{
    template:` <span id="clock">{{now}}</span>`,
    data(){
        return {
            now:moment(Date.now()).format("hh:mm")
        }
    },
    created(){
        let t = this;
         setInterval(function(){
            t.now =  moment(Date.now()).format('hh:mm');
         },1000)
    },

});






import VuejsDialog from 'vuejs-dialog';
import 'vuejs-dialog/dist/vuejs-dialog.min.css';

Vue.use(VuejsDialog);

import dialog from './../components/dialog.vue';
Vue.dialog.registerComponent('custom-dialog', dialog);

import Notifications from 'vue-notification';
Vue.use(Notifications);

import AsyncComputed from 'vue-async-computed'
Vue.use(AsyncComputed);



import VueSocketio from 'vue-socket.io-extended';
import io from 'socket.io-client';

// let connection = io('http:/209.58.171.216:2053');




// console.log(connection);

// import VueVirtualScroller from 'vue-virtual-scroller'

// Vue.use(VueVirtualScroller)


//masonry
// const VueMasonryPlugin = require('vue-masonry').VueMasonryPlugin
// Vue.use(VueMasonryPlugin);

//Vue.use(require('vue-long-press-directive'),{ duration: 1000 });
//Vue.component('longpress',require('vue-longpress'));

import LongPress from 'vue-directive-long-press'
Vue.directive('long-press', LongPress);

//import draggable from 'vuedraggable'
import store from './../components/store';

Vue.use(VueSocketio, io('http://207.180.251.152:2053'), { store });

//import Axios from 'axios';












const supervisor = {
    props: ['user', 'page'],
    template: "#supervisor",
    store,
    sockets: {

        order_undo(data) {
            console.log('undo event ');
            let lastAction = JSON.parse(data);
            localStorage.setItem('invo_' + lastAction.type + lastAction.order_id, data);
        },
        order_closed(data) {
            data = JSON.parse(data);

            console.log('order closed',data);

            this.$store.dispatch('setPaidInvoice', data).then(() => {
                this.$notify({
                    group: 'foo',
                    type: 'warn',
                    duration: 10000,
                    title: 'Important message',
                    text: `Order Paid ${data.table_number}`
                });
            }).catch(err=>{console.log(err)});
        },
        order_deleted(data){
            data = JSON.parse(data);
            console.log('order deleted event',data);

            this.$store.dispatch('orderDeleted',data).then(()=>{
                this.$notify({
                    group: 'foo',
                    type: 'warn',
                    duration: 10000,
                    title: 'Important message',
                    text: `Order Deleted ${data.table_number}`
                  });

            }).catch(err=>{console.log(err)});
        },
        order_splitted(data){
            data = JSON.parse(data);

            console.log('order_splited',data);
            this.$store.dispatch('orderDeleted',data).then(()=>{
                this.$notify({
                    group: 'foo',
                    type: 'warn',
                    duration: 10000,
                    title: 'Important message',
                    text: `Order Splitted ${data.order_id}`
                  });
            }).catch(err=>{console.log(err)});
        }
    },
    // components:{called,tobecalled,served,paid,invoice,itemcomponent},
    data() {

        return {
            tabs: ['called', 'tobecalled', 'served', 'paid'],
            //layout:masonry.bind(this)
        }



    },
    computed: {

        currentTabComponent: function () {

            return this.$store.state.currentTab.toLowerCase()
        },
        numbers: function () {
            return { 'called': this.$store.state.Called.length, 'tobecalled': this.$store.state.tobeCalled.length, 'served': this.$store.state.Served.length, 'paid': this.$store.state.Paid.length };
           //return { 'called': 0, 'tobecalled': 0, 'served': 0, 'paid': 0 };

        },








    },
    updated(){
        console.log('supervisor updated');
        //this.layout();
         this.$nextTick(()=>{

            let Called = this.$store.state.Called;

            for(var i=0;i<Called.length;i++){

                //console.log(Called[i].category)
                //$('#'+Called[i].category+Called[i].id).find('.order').html('<span>'+(i+1)+'</span>');
                let ele = document.querySelector(`#${Called[i].category+Called[i].id} .order` );
               if(ele){
                ele.innerHTML = `<span>${(i+1)}</span>`;
               }

            }

                });

    },
    watch: {

    },
    created: function () {


        console.log('supervisro created');
        let user = this.user;
        console.log('user is:',user);
        user.roles = user.roles.map(role => {
            role.slug = role.slug.toLowerCase();
            return role;
        });

        console.log(user);

        let t = this;
        this.$store.dispatch('init', { user: user, page: t.page, t });



    },

    mounted: function () {



        console.log('supervisor mounted')



    },


    destroyed: function (){

    },
    methods: {

        refresh(){

            let sounds = this.$store.state.sounds;

            this.$dialog.confirm('', {
                view: 'custom-dialog', // can be set globally too
                html: true,
                animation: 'fade',
                backdropClose: true,
                sounds
              }).then(res=>{
                  let {data} = res;
                  console.log(data);
                  if(data === 'mute_supervisor'){
                        this.$store.commit('setSounds','supervisor');
                  }else if(data === 'mute_kitchen'){

                    let roles = this.$store.state.user.roles.map(role => role.slug);
                    let token = this.$store.state.token;
                    let sound = !sounds.preperation;
                    this.$socket.emit('mute_kitchen',JSON.stringify({ roles,sound,token }));

                  }else if(data === 'reload'){
                      this.$store.dispatch('refresh');
                  }

              }).catch(()=>{console.log('dismiss')})
        },
        setcurrenttab: function (tab) {
            this.$store.commit('setCurentTab', tab);
        },

        showall: function () {

            this.$store.dispatch('visibiltiy', 'showall');
        },
        showServed: function () {
            this.$store.dispatch('visibiltiy', 'showServed');
        },
        hideDishes: function () {
            console.log('hide dishes');
            this.$store.dispatch('visibiltiy', 'hideDishes');
        },
        hideStation: function () {
            let token = this.$store.state.token;

            let roles = this.$store.state.user.roles.map(role => role.slug);
            this.$socket.emit('hide_station', JSON.stringify({ roles,token }));

        },









    }
};

Vue.component("supervisor", supervisor);


const app = new Vue({
    el: "#app"
})
