<?php
return [
    "new_customize_groups"   => "تخصيصات جديدة",
    "want_add_item"          => "لا يوجد مادة ... يرجى إضافة مادة ?",
    "item_name"              => "اسم المادة",
    "add"                    => "اضافة",
    "add_item"               => "إضافة",
    "are_you_sure"           => "هل انت متاكد",
    "delete_customize_group" => "هل تريد حقا حذف التخصيص",
    "no"                     => "لا",
    "yes"                    => "نعم",
    "cant_add_empty_item"    => "لا يمكن اضافة مادة فارغة",
    "empty_name_or_items"    => "لا يمكن اضافة تخصيص للمادة من دون اسم او مادة",
    "sure_delete_group"      => "هل حقا تريدحذف المجموعة",
    "sure_delete_item"       => "هل حقا تريد حذف المادة"
];