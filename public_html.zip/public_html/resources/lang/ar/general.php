<?php

return [
    'supervisor' => 'الادارة العامة',
    'preparation' => 'المطبخ',
    'items' => 'المواد',
    'item' => 'مادة',
    'categories' => 'الأصناف',
    'category' => 'صنف',
    'reports' => 'التقارير',
    'report' => 'تقرير',
    'punch' => 'نظام الدوام',
    'in' => 'دخول',
    'out' => 'خروج',
    'employees' => 'الموظفين',
    'employee' => 'موظف',
    'roles' => 'الأدوار',
    'role' => 'دور',
    'customize_group' => 'ملحقات مخصصة',
    'tastings' => 'أصناف التذوق',
    'printers' => 'الطابعات',
    'printer' => 'طابعة',
];
