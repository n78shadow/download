<?php
return [
    "new_customize_groups"   => "New Customize Groups",
    "want_add_item"          => "no items found .. add new items ?",
    "item_name"              => "Item Name",
    "add"                    => "Add",
    "add_item"               => "Add Item",
    "are_you_sure"           => "Are You Sure",
    "delete_customize_group" => "You Want To Delete This Customize Group ?",
    "no"                     => "No",
    "yes"                    => "Yes",
    "cant_add_empty_item"    => "You Can't Add Empty Item",
    "empty_name_or_items"    => "You Can't Add Customize Group Without Name Or Items ",
    "sure_delete_group"      => "Are you sure to delete this Group ?",
    "sure_delete_item"       => "Are you sure to delete this Item ?"
];