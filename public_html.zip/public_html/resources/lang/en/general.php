<?php


return [
    'supervisor' => 'Supervisor',
    'preparation' => 'Preparation',
    'items' => 'Items',
    'item' => 'Item',
    'categories' => 'Categories',
    'category' => 'Category',
    'reports' => 'Reports',
    'report' => 'Report',
    'punch' => 'Punch',
    'in' => 'In',
    'out' => 'Out',
    'employees' => 'Employees',
    'employee' => 'Employee',
    'roles' => 'Roles',
    'role' => 'Role',
    'customize_group' => 'Customize Group',
    'tastings' => 'Tastings',
    'printers' => 'Printers',
    'printer' => 'Printer',
    'create' => 'Create',
];
