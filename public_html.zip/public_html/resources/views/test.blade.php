<html>
<head>
    <script src="{{ asset('assets/js/printnode-api-client-0.1.0.js') }}"></script>
    <script src="{{ asset('assets/js/main.js') }}"></script>
</head>
<body>
<input type="button" onclick="print()" value="Print">
<br>

<div id="test"></div>
<div id="test1" style="display:none;"><tt>{{ "". ($html) . "" }}</tt></div>

<script>
    function print() {
        printFile(524023, "{{ $str }}");
    }

    function nl2br (str, isXhtml) {
        if (typeof str === 'undefined' || str === null) {
            return ''
        }

        // Adjust comment to avoid issue on locutus.io display
        var breakTag = (isXhtml || typeof isXhtml === 'undefined') ? '<br ' + '/>' : '<br>';
        str = (str + '').replace(/#table/g, '<table style="width: 100vw">');
        str = (str + '').replace(/#endtable/g, '</table>');

        str = (str + '').replace(/#tr/g, '<tr>');
        str = (str + '').replace(/#endtr/g, '</tr>');

        str = (str + '').replace(/#td/g, '<td>');
        str = (str + '').replace(/#endtd/g, '</td>');
        str = (str + '').replace(/ /g, '&nbsp');

        //console.log(str);
        return (str + '').replace(/(\r\n|\n\r|\r|\n|\\n|\n\n)/g, breakTag);

    }

    printElem = function () {
        var elem = document.getElementById('test1').innerHTML;
        document.getElementById('test').innerHTML = '<tt>' + nl2br(elem) + '</tt>'; return;
        document.getElementById('test1').innerHTML = '';
        var mywindow = window.open('', 'PRINT', 'toolbar=no,status=no,menubar=no,scrollbars=no,resizable=no,left=0, top=0, width=10, height=10, visible=none');

        mywindow.document.write('<html><head><title>' + document.title + '</title><style>@page { size:auto; margin: 10px; }</style>');
        mywindow.document.write('</head><body onload="//window.print(); window.close();" ><tt>');
        //mywindow.document.write('<h1>' + document.title  + '</h1>');
        mywindow.document.write(nl2br(elem));
        mywindow.document.write('</tt></body></html>');

        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10*/
        //alert(1);
        //mywindow.print();
        //mywindow.close();

        return true;
    }
    printElem();

</script>
</body>
</html>