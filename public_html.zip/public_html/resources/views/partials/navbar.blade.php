<nav class="navbar topNav sticky-top navbar-dark navbar-expand-lg">
        <!-- PageName -->
        <!--a class="navbar-brand navbar-nav mr-auto" id="showBreadCrumbs" href="#" style="padding-right: 2rem;">@yield('page-name')</a-->
        <!-- BreadCrumps -->
        <ol class="breadcrumb col-lg-3" style="">
            <li class="breadcrumb-item"><a href="{{ route('clients.sitemap') }}">Home</a></li>
            @yield('page-links')
        </ol>
        <!-- links -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#links" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="nav navbar-nav nav-fill w-100" id="links" role="tablist">
            @yield('extra-links')
            <!-- <li class="nav-item">
                <a class="nav-link active" id="new-order-tab" data-toggle="tab" href="#new-order" role="tab" aria-controls="new-order" aria-selected="true" onclick="location.reload();">New Order</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="bills-tab" data-toggle="tab" href="#bills" role="tab" aria-controls="bills" aria-selected="false">Bills</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" id="online-tab" data-toggle="tab" href="#online" role="tab" aria-controls="online" aria-selected="false">Online</a>
            </li> -->
            <!-- Control Center
            <div class="btn-group">
                <button type="button" class="btn btn-link dropdown-toggle whiteText no-text-decoration" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-cogs"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <button class="dropdown-item" type="button">info</button>
                    <button class="dropdown-item" type="button">Setting</button>
                    <button class="dropdown-item btn-danger" type="button">Logout</button>
                </div>
            </div>
             -->

            <!-- User -->
            <div class="btn-group right">
                <button type="button" class="btn btn-link dropdown-toggle text-white no-text-decoration" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right noBorderRadius" style="top : 46px ;">
                    <button class="dropdown-item" type="button">info</button>
                    <button class="dropdown-item" type="button">Setting</button>
                    <form action="{{ route('logout') }}" id="forms_logout" method="POST">
                        @csrf
                    <button class="dropdown-item btn-danger" type="button" onclick="SubmitForm('forms_logout')">Logout</button>
                    </form>
                </div>
            </div>
        </ul>
    </nav>