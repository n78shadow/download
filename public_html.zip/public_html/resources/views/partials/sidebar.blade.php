<div class="sideNav">
        <a href="{{ route('clients.sitemap') }}" data-toggle="tooltip" data-placement="right" title="Dashboard"><i class="fas fa-tachometer-alt" ></i></a>
        <a href="#" data-toggle="tooltip" data-placement="right" title="FeedBack"><i class="fas fa-comment-alt" aria-hidden="true"></i></a>
        <a href="#" data-toggle="tooltip" data-placement="right" title="Lock"><i class="fa fa-lock" aria-hidden="true"></i></a>
        <ul>
            <li  onclick="location.reload();"><a href="#" data-toggle="tooltip" data-placement="right" title="Refresh"><i class="fas fa-sync-alt"></i></a></li>
        </ul>
</div>