<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <title> @yield('title') </title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/pos.css')}}">
    <link rel="stylesheet" href="{{ asset('assets/css/custom.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-switches.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-radio.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/materialColor.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/toastify.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/pickDateTime/default.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/pickDateTime/default.time.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/pickDateTime/default.date.css') }}">
    @yield('extra-head-js')
    @yield('extra-css-links')
    @yield('extra-styles')


</head>
<body>

