@extends('layouts.master')

@section('title','UPOS | POS')


<!---more list links go to nav bar---->
@section('extra-links')
            <li class="nav-item">
                <a class="nav-link active" id="new-order-tab" data-toggle="tab" href="#new-order" role="tab" aria-controls="new-order" aria-selected="true" onclick="location.reload();">New Order</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="bills-tab" data-toggle="tab" href="#bills" role="tab" aria-controls="bills" aria-selected="false">Bills</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" id="online-tab" data-toggle="tab" href="#online" role="tab" aria-controls="online" aria-selected="false">Online</a>
            </li>
@endsection


@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')


    <div class="contents" id="newOrder-Bill-online">
        <div class="tab-content" id="sections">
            <!-- Tap One [New Invoice] -->
            <div class="tab-pane fade show active " id="new-order" role="tabpanel" aria-labelledby="new-order-tab" style="height: 100% ; margin: 0">

                <form id="chooseOrderType" action="">

                    <!-- One "tab" for each step in the form: -->
                    <div class="tab">
                        <div class="row ">
                            <div class="col-lg-4">
                                <div class="card choose-bill-type" id="direct" onclick="nextPrev(1 , this.id)">
                                    <div class="card-body">
                                        <h1 class="card-title">Direct</h1>
                                        <p class="text-muted">Current Invoice : <span class="font-weight-bold">12</span> </p>
                                        <p class="text-muted">Next Invoice Time :<span class="font-weight-bold"> 30 </span> min</p>

                                        <i class="fas fa-hand-holding-usd "></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card choose-bill-type" id="delivery" onclick="nextPrev(1 , this.id)">
                                    <div class="card-body">
                                        <h1 class="card-title">Delivery</h1>
                                        <p class="text-muted">Current Invoice : <span class="font-weight-bold">7</span> </p>
                                        <p class="text-muted">Available Delivery Man :<span class="font-weight-bold"> 3 </span> min</p>

                                        <i class="fas fa-taxi"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card choose-bill-type" id="table" onclick="nextPrev(1 , this.id)">
                                    <div class="card-body">
                                        <h1  class="card-title">Table</h1>
                                        <p class="text-muted">Current Invoice : <span class="font-weight-bold">33</span> </p>
                                        <p class="text-muted">Empty Tables :<span class="font-weight-bold"> 25 </span></p>

                                        <i class="fas fa-utensils"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab" id="selectDishes_Services">
                        <div class="row">
                            <!-- Categories & Services & Clients -->
                            <div class="col-lg-9">
                                <!-- Services & Clients -->
                                <div class="card" id="services_clients_panels" style="margin-bottom: 2rem">

                                    <nav class="nav nav-fill servicesPanel">
                                        <a class="nav-link nav-item" href="#">Service #1</a>
                                        <a class="nav-link nav-item" href="#">Service #2</a>
                                        <a class="nav-link nav-item" href="#">Service #3</a>
                                        <a class="nav-link nav-item" href="#">Service #4</a>
                                        <a class="nav-link nav-item" href="#">Service #5</a>
                                    </nav>
                                    <nav class="nav nav-fill clientsPanel">
                                        <a class="nav-link nav-item" data-client-number="1">CL #1</a>
                                        <a class="nav-link nav-item" data-client-number="2">CL #2</a>
                                        <a class="nav-link nav-item" data-client-number="3">CL #3</a>
                                        <a class="nav-link nav-item" data-client-number="4">CL #4</a>
                                        <a class="nav-link nav-item" data-client-number="5">CL #5</a>
                                        <a class="nav-link nav-item" data-client-number="6">CL #6</a>
                                        <a class="nav-link nav-item" data-client-number="7">CL #7</a>
                                        <a class="nav-link nav-item" data-client-number="8">CL #8</a>
                                    </nav>
                                    <a class="moreClient" id="plus8Client"><i class="fas fa-plus"></i></a>

                                </div>
                                <!-- Categories -->
                                <div class="accordion" id="categories">
                                    
                                <div class="card category" style="border: 2px solid #6d4c41;">
                                        <i class="fab fa-hotjar item-trend-icon"></i>
                                        <p class="item-notListed">Not Listed ?</p>

                                        <div class="card-header cursor text-white" style="background-color: #6d4c41" id="heading1" data-toggle="collapse" data-target="#cat1" aria-expanded="true" aria-controls="cat1">
                                            <h5 class="mb-0">
                                                Sandwich
                                            </h5>
                                        </div>

                                        <div id="cat1" class="collapse" aria-labelledby="headingFive" data-parent="#categories">
                                            <div class="filters owl-carousel" style="background-color: #6d4c41;">
                                                <a class="filter">filter #1</a>
                                                <a class="filter">filter #2</a>
                                                <a class="filter">filter #3</a>
                                                <a class="filter">filter #4</a>
                                                <a class="filter">filter #5</a>
                                                <a class="filter">filter #6</a>
                                                <a class="filter">filter #7</a>
                                                <a class="filter">filter #8</a>
                                                <a class="filter">filter #9</a>
                                                <a class="filter">filter #10</a>
                                                <a class="filter">filter #11</a>
                                                <a class="filter">filter #12</a>
                                                <a class="filter">filter #13</a>
                                                <a class="filter">filter #14</a>
                                                <a class="filter">filter #15</a>
                                                <a class="filter">filter #16</a>
                                            </div>
                                            <div class="addNonListedItem" hidden>
                                                <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                                    <div class="col">
                                                        <input class="form-control" type="text" placeholder="Name">
                                                    </div>
                                                    <div class="col">
                                                        <input class="form-control" type="text" placeholder="Price">
                                                    </div>
                                                    <div class="col">
                                                        <button type="button" class="btn btn-light btn-block">Order</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body"></div>
                                            <div class="emptyCategory" style="margin-top: -10px">
                                                <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                                <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                            </div>
                                        </div>
                                    </div>

                                    
								
                                   
									
									
									
									
                                </div>
								
								
								<!----------end of categories -------->
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
                            </div>
                            <!-- invoices -->
                            <div class="col-lg-3">
                                <div id="invoice-orders">
                                    <div class="card" >
                                        <i class="fas fa-sticky-note note-invoice"></i>
                                        <div class="card-body" id="itemsInInvoice" style="height: 32rem; overflow: auto;">
                                            <div class="emptyInvoice" style="margin-top: -10px">
                                                <img src="imgs/empty/emptyService.svg" style="max-width: 100%">
                                                <p class="text-muted">This Order Is Empty , Choose Some Items From Category</p>
                                            </div>
                                            <div class="itemsInInvoice display-block" hidden>
                                                <h5 class="card-title">Order Num : #12</h5>
                                                <hr>
                                            </div>
                                            <div class="invoiceNote" hidden>
                                                <h5 class="card-title">Order Num : #12 - <span class="text-muted">Notes</span></h5>
                                                <hr>
                                                <div class="list-group quickNotes">
                                                    <button type="button" class="list-group-item list-group-item-action">Quickly !</button>
                                                    <button type="button" class="list-group-item list-group-item-action">Well cooked</button>
                                                    <button type="button" class="list-group-item list-group-item-action">Half cooked</button>
                                                    <button type="button" class="list-group-item list-group-item-action">Extral For All</button>
                                                    <button type="button" class="list-group-item list-group-item-action">Extra Fried Potatoes</button>
                                                    <button type="button" class="list-group-item list-group-item-action">Without Mayonnaise For All</button>
                                                </div>

                                                <textarea class="form-control" id="otherNotes" rows="5" placeholder="Other Notes" style="margin-top: 1rem"></textarea>

                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6">
                                                    <h6>Taxes : 50$</h6>
                                                </div>
                                            </div>
                                            <h4 class="noMargin">Total : 350$</h4>
                                        </div>
                                    </div>
                                </div>
                                <div id="invoice-services">
                                    <div class="card">
                                        <div class="card-body" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Table Number <input class="btn btn-light" type="button" id="table-number" data-modal-id="choose-table" modal-type="bottom" value="--"></h5>
                                            <ul class="nav nav-pills nav-fill nav-tabs invoice-action-center" id="invoice-action-center" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link clients active" id="items-tab" data-toggle="tab" href="#viewByClient" role="tab" aria-controls="viewByClient" aria-selected="true"><i class="fas fa-street-view"></i></a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link items" id="items-tab" data-toggle="tab" href="#items" role="tab" aria-controls="items" aria-selected="true"><i class="fas fa-bars"></i></a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="notes-tab" data-toggle="tab" href="#notes" role="tab" aria-controls="notes" aria-selected="false"><i class="fas fa-sticky-note"></i></a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="schedule-tab" data-toggle="tab" href="#schedule" role="tab" aria-controls="schedule" aria-selected="false"><i class="fas fa-clock"></i></a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link arrangeItems" data-toggle="tab" href=""><i class="fas fa-hand-rock"></i></a>
                                                </li>
                                            </ul>
                                            <hr>
                                            <div class="tab-content" id="myTabContent">
                                                <!-- View By Client -->
                                                <div class="tab-pane fade show active" id="viewByClient" role="tabpanel" aria-labelledby="viewByClient-tab">
                                                    <div id="clients">
                                                        <div class="client" id="1" data-drop-target="true">
                                                            <h4>Client <span class="text-muted">#1</span></h4>
                                                            <a role="button" id="item4" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item6" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #4">3</span>item 6<span class="item-plus"><i class="fas fa-plus"></i></span></a>

                                                        </div>
                                                        <div class="client" id="2" data-drop-target="true">
                                                            <h4>Client <span class="text-muted">#2</span></h4>
                                                            <a role="button" id="item4"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item5"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item6"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #4">3</span>item 6<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item5"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                        </div>
                                                        <div class="client" id="3" data-drop-target="true">
                                                            <h4>Client <span class="text-muted">#3</span></h4>
                                                            <a role="button" id="item4" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5<span class="item-plus"><i class="fas fa-plus"></i></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="emptyInvoice" style="margin-top: -10px" hidden>
                                                        <img src="imgs/empty/emptyService.svg" style="max-width: 100%">
                                                        <p class="text-muted">This Client Is Empty , Choose Client & Items Now</p>
                                                    </div>
                                                </div>

                                                <!-- Services -->
                                                <div class="tab-pane fade" id="items" role="tabpanel" aria-labelledby="items-tab">
                                                    <div id="services">
                                                        <div class="service" id="1" data-drop-target="true">
                                                            <!--
                                                            <div class="chooseClientDish client">
                                                                <h4>Client <span class="text-muted">#1</span></h4>
                                                                <h4>Client <span class="text-muted">#2</span></h4>
                                                                <h4>Client <span class="text-muted">#3</span></h4>
                                                                <h4>Client <span class="text-muted">#4</span></h4>
                                                            </div>
                                                            -->
                                                            <h4>Service <span class="text-muted">#1</span></h4>
                                                            <a role="button" id="item1"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #546e7a"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">2</span>item 1</a>
                                                            <a role="button" id="item2"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">10</span>item 2</a>
                                                            <a role="button" id="item3"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #7cb342"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">8</span>item 3</a>
                                                            <a role="button" id="item4"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">1</span>item 4</a>
                                                            <a role="button" id="item5"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">14</span>item 5</a>
                                                            <a role="button" id="item6"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">3</span>item 6</a>

                                                        </div>
                                                        <div class="service" id="2" data-drop-target="true">
                                                            <h4>Service <span class="text-muted">#2</span></h4>
                                                            <a role="button" id="item7"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #546e7a"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">2</span>item 1</a>
                                                            <a role="button" id="item8"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">10</span>item 2</a>
                                                            <a role="button" id="item9"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">1</span>item 4</a>
                                                            <a role="button" id="item10"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">3</span>item 6</a>
                                                        </div>
                                                    </div>
                                                    <div class="emptyInvoice" style="margin-top: -10px" hidden>
                                                        <img src="imgs/empty/emptyService.svg" style="max-width: 100%">
                                                        <p class="text-muted">This Service Is Empty , Choose Some Items From Category</p>
                                                    </div>
                                                </div>

                                                <!-- invoice Notes -->
                                                <div class="tab-pane fade" id="notes" role="tabpanel" aria-labelledby="profile-tab">
                                                    <div class="list-group quickNotes">
                                                        <button type="button" class="list-group-item list-group-item-action">Quickly !</button>
                                                        <button type="button" class="list-group-item list-group-item-action">Well cooked</button>
                                                        <button type="button" class="list-group-item list-group-item-action">Half cooked</button>
                                                        <button type="button" class="list-group-item list-group-item-action">Extral For All</button>
                                                        <button type="button" class="list-group-item list-group-item-action">Extra Fried Potatoes</button>
                                                        <button type="button" class="list-group-item list-group-item-action">Without Mayonnaise For All</button>
                                                    </div>
                                                    <textarea class="form-control" id="otherNotes" rows="5" placeholder="Other Notes" style="margin-top: 1rem"></textarea>

                                                </div>

                                                <!-- schedule -->
                                                <div class="tab-pane fade" id="schedule" role="tabpanel" aria-labelledby="schedule-tab">
                                                    <div class="row">
                                                        <div class="col">
                                                            <!-- Small switch -->
                                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #1</label>
                                          </span>
                                                            </div>
                                                        </div>

                                                        <div class="col">
                                                            <!-- Small switch -->
                                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #2</label>
                                          </span>
                                                            </div>
                                                        </div>

                                                        <div class="col">
                                                            <!-- Small switch -->
                                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #3</label>
                                          </span>
                                                            </div>
                                                        </div>

                                                        <div class="col">
                                                            <!-- Small switch -->
                                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #4</label>
                                          </span>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="radio">
                                                            <input id="radio-1" name="holdOption" value="1" type="radio">
                                                            <label  for="radio-1" class="radio-label label-small">Hold All Invoice For Limited Time </label>
                                                        </div>
                                                        <div class="radio">
                                                            <input id="radio-2" name="holdOption" value="2" type="radio">
                                                            <label  for="radio-2" class="radio-label label-small">Hold to Un Hold </label>
                                                        </div>
                                                    </div>

                                                    <div class="row">

                                                        <div id="holdOption1" class="option" style="display: none">
                                                            <div class="row" style="margin: 1rem 0 0 0">
                                                                <div class="col-lg-6">
                                                                    <h6> Hold For : </h6>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <input class="form-control form-control-sm" type="number" placeholder="30 min">
                                                                </div>
                                                            </div>

                                                            <div class="row" style="margin: 1rem 0 0 0" >

                                                                <div class="col-lg-6">
                                                                    <h6> Notify Me During : </h6>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <input class="form-control form-control-sm" type="number" placeholder="5 min">
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6">
                                                    <h6>Taxes : 50$</h6>
                                                </div>
                                            </div>
                                            <h4 class="noMargin">Total : 350$</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab" id="collect_Information">
                        <h2>Order Number<span class="text-muted"> #156 </span></h2>
                        <div class="card">
                            <div class="card-body">
                                <div class="row" style="width: max-content; margin: 10px auto;">
                                    <div class="radio" style="margin: 0.5rem 3rem;">
                                        <input id="radio-1" name="deliveryOption" value="1" type="radio" checked>
                                        <label  for="radio-1" class="radio-label label-medium"> Delivery <i class="fas fa-taxi"></i> </label>
                                    </div>
                                    <div class="radio" style="margin: 0.5rem 3rem;">
                                        <input id="radio-2" name="deliveryOption" value="2" type="radio">
                                        <label  for="radio-2" class="radio-label label-medium"> Pickup <i class="fas fa-hand-rock"></i> </label>
                                    </div>
                                </div>

                                <div id="deliveryOption1" class="option">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <input class="form-control form-control-lg" type="number" placeholder="Phone Number">
                                        </div>
                                        <div class="col-lg-4">
                                            <input class="form-control form-control-lg" type="text" placeholder="Full Client Name" disabled>
                                        </div>
                                        <div class="col-lg-4">
                                            <input class="form-control form-control-lg" type="number" placeholder="Postal Code">
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: 3rem">
                                        <div class="col-lg-3">
                                            <input class="form-control form-control-lg" type="number" placeholder="Street Number">
                                        </div>
                                        <div class="col-lg-3">
                                            <input class="form-control form-control-lg" type="text" placeholder="Street Name" disabled>
                                        </div>
                                        <div class="col-lg-3" style="border-left: 1px solid #ddd;">
                                            <input class="form-control form-control-lg" type="text" placeholder="City" disabled>
                                        </div>
                                        <div class="col-lg-3">
                                            <input class="form-control form-control-lg" type="text" placeholder="province" disabled>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: 3rem">
                                        <div class="col-lg-4">
                                            <input class="form-control form-control-lg" type="text" placeholder="Notes For Driver">
                                        </div>
                                        <div class="col-lg-4" style="border-left: 1px solid #ddd;">
                                            <input class="form-control form-control-lg" type="number" placeholder="Apt , Unite , Suite">
                                        </div>
                                        <div class="col-lg-2">
                                            <input class="form-control form-control-lg" type="number" placeholder="Buzz Code">
                                        </div>
                                        <div class="col-lg-2">
                                            <input class="form-control form-control-lg schedual-delivery" type="number" placeholder="Specific Time ?">
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: 3rem">
                                        <div class="drivers owl-carousel">
                                            <a class="driver">Driver #1</a>
                                            <a class="driver">Driver #2</a>
                                            <a class="driver">Driver #3</a>
                                            <a class="driver">Driver #4</a>
                                            <a class="driver">Driver #5</a>
                                            <a class="driver">Driver #6</a>
                                            <a class="driver">Driver #7</a>
                                            <a class="driver">Driver #8</a>
                                            <a class="driver">Driver #9</a>
                                            <a class="driver">Driver #10</a>
                                            <a class="driver">Driver #11</a>
                                            <a class="driver">Driver #12</a>
                                        </div>
                                    </div>
                                </div>

                                <div id="deliveryOption2" class="option" style="display: none">
                                    <div class="row" style="width: 450px; margin: 0 auto">
                                        <div class="col-lg-12" style="margin-top: 1rem">
                                            <input class="form-control form-control-lg" type="number" placeholder="Phone Number">
                                        </div>
                                        <div class="col-lg-12" style="margin-top: 1rem">
                                            <input class="form-control form-control-lg" type="text" placeholder="Full Client Name" disabled>
                                        </div>
                                        <div class="col-lg-12" style="margin-top: 1rem">
                                            <input class="form-control schedual-delivery form-control-lg" placeholder="Add Time To Pickup">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="tab" id="pay_Direct">
                        <div class="row">
                            <div class="col-lg-6">
                                <h3>Pay Order Invoice Num <span class="text-muted"> #57 </span> - Table Num <span class="text-muted"> 26     </span></h3>
                            </div>
                            <div class="col-lg-6 text-right">
                                <button type="button" class="btn btn-success noBorderRadius">Pay</button>
                                <button type="button" class="btn btn-danger noBorderRadius cancel-pay-this-bill" >Cancel</button>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-body">
                                <div class="row" style="margin: 2rem 0">
                                    <div class="col-lg-4">
                                        <h5 class="text-muted">Subtotal : <span class="font-weight-bold">350$</span></h5>
                                        <h5 class="text-muted">TPS Taxes : <span class="font-weight-bold">67.40$</span></h5>
                                        <h5 class="text-muted">TVQ Taxes : <span class="font-weight-bold">25.20$</span></h5>
                                    </div>
                                    <div class="col-lg-4 text-center">

                                        <div class="input-group">
                                            <div class="input-group-prepend display-block" id="dollarDiscount" hidden>
                                                <div class="input-group-text noBorderRadius display-block">
                                                    <i class="fas fa-dollar-sign"></i>
                                                </div>
                                            </div>
                                            <div class="input-group-prepend" id="percentDiscount" hidden>
                                                <div class="input-group-text noBorderRadius display-block">
                                                    <i class="fas fa-percentage"></i>
                                                </div>
                                            </div>
                                            <input class="form-control noBorderRadius" type="number" placeholder="Discount">
                                        </div>

                                        <input class="form-control" type="number" style="margin-top: 1rem" placeholder="Balance" disabled>
                                    </div>
                                    <div class="col-lg-4 text-center">
                                        <h2 style="margin: 1rem 0 ; font-size: 50px">Total : <span class="font-weight-bold">465.60$</span></h2>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text noBorderRadius">Cash</div>
                                            </div>
                                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                                        </div>

                                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text noBorderRadius">Debit</div>
                                            </div>
                                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                                        </div>

                                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text noBorderRadius">Coupon</div>
                                            </div>
                                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text noBorderRadius">77$</div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-lg-8" style="border-left : 1px solid #eee">
                                        <div class="row">
                                            <div class="col-lg-3">
                                                <div class="creditChoose">
                                                    <i class="fab fa-cc-visa"></i>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="creditChoose">
                                                    <i class="fab fa-cc-mastercard"></i>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="creditChoose">
                                                    <i class="fab fa-cc-amex"></i>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="creditChoose">
                                                    <i class="fas fa-credit-card"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group input-group-lg">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text noBorderRadius">Credit</div>
                                            </div>
                                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Username">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card text-white bg-danger" style="margin-top: 2rem">
                            <div class="card-header">ERROR ! </div>
                            <div class="card-body">
                                <h5 class="card-title">Check Your Money , and Try Again</h5>
                            </div>
                        </div>
                    </div>

                    <div class="btn-group btn-group-lg fixed-bottom" id="steps-action" role="group" aria-label="First group" style="visibility: hidden ; z-index: 1 !important;">
                        <button type="button" class="btn btn-secondary noBorderRadius w-50" id="prevBtn" onclick="nextPrev(-1)">Previous Step</button>
                        <button type="button" class="btn btn-secondary noBorderRadius w-50" id="nextBtn" onclick="nextPrev(1)">Next Step</button>
                    </div>

                </form>

            </div>
            <!-- Tap Two [Bills] -->
            <div class="tab-pane fade" id="bills" role="tabpanel" aria-labelledby="bills-tab">
                <div class="row">
                    <div class="col-3" style="position: sticky;top: 75px;height: 100%;">
                        <div class="card">
                            <div class="card-body">
                                <!-- Bills Tabs [Links Sections] -->
                                <div class="nav flex-column nav-pills billsFilterNav" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                    <a class="nav-link noBorderRadius active" id="v-pills-tables-tab" data-toggle="pill" href="#v-pills-tables" role="tab" aria-controls="v-pills-tables" aria-selected="true">Tables <span class="badge badge-light">24</span></a>
                                    <a class="nav-link noBorderRadius" id="v-pills-delivery-tab" data-toggle="pill" href="#v-pills-delivery" role="tab" aria-controls="v-pills-delivery" aria-selected="false">Delivery <span class="badge badge-light">16</span></a>
                                    <a class="nav-link noBorderRadius" id="v-pills-takeAway-tab" data-toggle="pill" href="#v-pills-takeAway" role="tab" aria-controls="v-pills-takeAway" aria-selected="false">TakeAway <span class="badge badge-light">7</span></a>
                                    <a class="nav-link noBorderRadius btn-light" id="v-pills-paid-tab" data-toggle="pill" href="#v-pills-paid" role="tab" aria-controls="v-pills-paid" aria-selected="false">Paid <span class="badge badge-light">83</span></a>
                                </div>
                                <hr>
                                <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="Search By Invoice Num">
                                <button type="button" class="btn btn-secondary noBorderRadius btn-block" id="combine" style="margin-top: 1rem">Combine</button>
                                <div class="btn-group w-100 display-hidden" id="actionsCombine" role="group" style="margin-top: 1rem">
                                    <button type="button" id="doCombine" class="btn btn-success w-50 noBorderRadius">Do Combine</button>
                                    <button type="button" id="cancelCombine" class="btn btn-danger w-50 noBorderRadius">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="card">
                            <div class="card-body">
                                <!-- Bills Tabs [Sections] -->
                                <div class="tab-content" id="v-pills-tabContent">
                                    <!-- Bill [Tables] -->
                                    <div class="tab-pane fade show active" id="v-pills-tables" role="tabpanel" aria-labelledby="v-pills-tables-tab">
                                        <div class="card-columns" id="activeInvoiced">
                                            <!-------dynamic ------>
                                        </div>
                                    </div>
                                    <!-- Bill [Delivery] -->
                                    <div class="tab-pane fade" id="v-pills-delivery" role="tabpanel" aria-labelledby="v-pills-deliver-tab">
                                        <div class="card-columns">
                                            <div class="card bg-light border-success text-success mb-3 text-center bill show-bill-details" data-bill-type="delivery">
                                                <div class="card-body">
                                                    <h1 class="card-title noMargin"><i class="fas fa-hashtag"></i> 15</h1>

                                                    <div class="details">
                                                        <p><i class="fas fa-clock"></i> 3:09</p>
                                                        <p><i class="fas fa-taxi"></i> 7 </p>
                                                        <p><i class="fas fa-stopwatch"></i> 4:15</p>
                                                    </div>

                                                </div>
                                                <div class="btn-group w-100" id="actionsCombine" role="group" style="margin-top: 1rem">
                                                    <button type="button" class="btn btn-secondary w-25 noBorderRadius show-bill-details" ><i class="fas fa-file-invoice-dollar"></i></button>
                                                    <button type="button" class="btn btn-success w-75 noBorderRadius pay-this-bill">Pay <span class="font-weight-bold">1120$</span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bill [TakeAway] -->
                                    <div class="tab-pane fade" id="v-pills-takeAway" role="tabpanel" aria-labelledby="v-pills-takeAway-tab">
                                        <div class="card-columns">
                                            <div class="card bg-light border-success text-success mb-3 text-center bill show-bill-details" data-bill-type="takeAway">
                                                <div class="card-body">
                                                    <h1 class="card-title noMargin"><i class="fas fa-hashtag"></i> 15</h1>

                                                    <div class="details">
                                                        <p><i class="fas fa-clock"></i> 3:09</p>
                                                        <p><i class="fas fa-stopwatch"></i> 4:15</p>
                                                    </div>

                                                </div>

                                                <div class="btn-group w-100" id="actionsCombine" role="group" style="margin-top: 1rem">
                                                    <button type="button" class="btn btn-secondary w-25 noBorderRadius show-bill-details" ><i class="fas fa-file-invoice-dollar"></i></button>
                                                    <button type="button" class="btn btn-success w-75 noBorderRadius pay-this-bill">Pay <span class="font-weight-bold">1120$</span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bill [paid] -->
                                    <div class="tab-pane fade" id="v-pills-paid" role="tabpanel" aria-labelledby="v-pills-paid-tab">
                                        <div class="card-columns">
                                            <div class="card bg-light border-success text-success mb-3 text-center bill show-bill-details" data-bill-type="takeAway">
                                                <div class="card-body">
                                                    <h1 class="card-title noMargin"><i class="fas fa-hashtag"></i> 15</h1>

                                                    <div class="details">
                                                        <p><i class="fas fa-clock"></i> 3:09</p>
                                                        <p><i class="fas fa-stopwatch"></i> 4:15</p>
                                                    </div>

                                                </div>

                                                <div class="btn-group w-100" id="actionsCombine" role="group" style="margin-top: 1rem">
                                                    <button type="button" class="btn btn-success w-100 noBorderRadius pay-this-bill">RePay</button>
                                                </div>
                                            </div>
                                            <div class="card bg-light border-success text-success mb-3 text-center bill show-bill-details" data-bill-type="delivery">
                                                <div class="card-body">
                                                    <h1 class="card-title noMargin"><i class="fas fa-hashtag"></i> 15</h1>

                                                    <div class="details">
                                                        <p><i class="fas fa-clock"></i> 3:09</p>
                                                        <p><i class="fas fa-taxi"></i> 7 </p>
                                                        <p><i class="fas fa-stopwatch"></i> 4:15</p>
                                                    </div>

                                                </div>
                                                <div class="btn-group w-100" id="actionsCombine" role="group" style="margin-top: 1rem">
                                                    <button type="button" class="btn btn-success w-100 noBorderRadius pay-this-bill">RePay</button>
                                                </div>
                                            </div>
                                            <div class="card bg-light mb-3 text-center bill show-bill-details" data-bill-type="table">
                                                <div class="card-body">
                                                    <h1 class="card-title noMargin"><i class="fas fa-utensils"></i> 6</h1>

                                                    <div class="details">
                                                        <p><i class="fas fa-clock"></i> 3:09</p>
                                                        <p><i class="fas fa-hashtag"></i> 15 [8] </p>
                                                        <p><i class="fas fa-male"></i> Adnan</p>
                                                    </div>

                                                </div>
                                                <div class="btn-group w-100" id="actionsCombine" role="group" style="margin-top: 1rem">
                                                    <button type="button" class="btn btn-success w-100 noBorderRadius pay-this-bill">RePay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Tap Three [Online] -->
            <div class="tab-pane fade" id="online" role="tabpanel" aria-labelledby="online-tab">Online

            </div>
        </div>
    </div>


    <div class="contents" id="bill-details" hidden>
        <div class="row" id="services-ctgs-edit">
            <!-- Categories & Services & Clients -->
            <div class="col-lg-9">
                <div class="row">
                    <div class="col">
                        <h3>Invoice Num : <span class="text-muted">#795</span> - <span class="delete-this-invocie" data-toggle="modal" data-target="#confirmModal"><i class="fas fa-trash-alt"></i></span></h3>
                    </div>

                    <div class="col text-right">
                        <button type="button" class="btn btn-success noBorderRadius saveEditBtnInDetails" style=""  hidden>Send</button>
                        <button type="button" class="btn btn-danger noBorderRadius cancelEditBtnInDetails" style=""  hidden>Cancel</button>

                        <button type="button" class="btn btn-secondary noBorderRadius splitBtnsInDetails ">Equal Split</button>
                        <button type="button" class="btn btn-secondary noBorderRadius splitBtnsInDetails unEqualsplitBtnInDetails ">UnEqual Split</button>
                        <button type="button" class="btn btn-secondary noBorderRadius splitBtnsInDetails">Split By Client</button>

                        <button type="button" class="btn btn-light noBorderRadius editBtnInDetails">Edit</button>
                        <button type="button" class="btn btn-light noBorderRadius combineBtnInDetails">Combine</button>
                    </div>
                </div>
                <div class="card" id="orders-bills-details">
                    <div class="card-body">
                        <div id="table-bill-details">
                            <div class="row">
                                <div class="col">
                                    <h4>Waiter Creator : <input class="btn btn-light" type="button" data-modal-id="choose-waiter" modal-type="bottom" value="Adnan"></h4>
                                </div>

                                <div class="w-100">
                                    <hr>
                                </div>

                                <!-- Services -->
                                <div class="col-lg-2">
                                    <h4>Service 1</h4>
                                    <button type="button" class="btn btn-light btn-block noBorderRadius disabled">Serviced - 19:39</button>
                                    <button type="button" class="btn btn-light btn-block noBorderRadius ">Recall</button>
                                </div>
                                <div class="col">
                                    <h4>Service 2</h4>
                                    <button type="button" class="btn btn-success btn-block noBorderRadius disabled">Called - 19:47</button>
                                </div>
                                <div class="col">
                                    <h4>Service 3</h4>
                                    <button type="button" class="btn btn-light btn-block noBorderRadius">Call</button>
                                    <button type="button" class="btn btn-warning btn-block noBorderRadius">Merg</button>
                                </div>
                                <div class="col">
                                    <h4>Service 4</h4>
                                    <button type="button" class="btn btn-light btn-block noBorderRadius">Call</button>
                                    <button type="button" class="btn btn-warning btn-block noBorderRadius">Merg</button>
                                </div>
                                <div class="col">
                                    <h4>Service 5</h4>
                                    <button type="button" class="btn btn-light btn-block noBorderRadius">Call</button>
                                    <button type="button" class="btn btn-warning btn-block noBorderRadius">Merg</button>
                                </div>

                            </div>
                        </div>
                        <div id="delivery-bill-details">
                            <div class="row">
                                <div class="col-lg-4">
                                    <input class="form-control form-control-lg" type="number" placeholder="Phone Number">
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control form-control-lg" type="text" placeholder="Full Client Name" disabled>
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control form-control-lg" type="number" placeholder="Postal Code">
                                </div>
                            </div>
                            <div class="row" style="margin-top: 3rem">
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg" type="number" placeholder="Street Number">
                                </div>
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg" type="text" placeholder="Street Name" disabled>
                                </div>
                                <div class="col-lg-3" style="border-left: 1px solid #ddd;">
                                    <input class="form-control form-control-lg" type="text" placeholder="City" disabled>
                                </div>
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg" type="text" placeholder="province" disabled>
                                </div>
                            </div>
                            <div class="row" style="margin-top: 3rem">
                                <div class="col-lg-4">
                                    <input class="form-control form-control-lg" type="text" placeholder="Notes For Driver">
                                </div>
                                <div class="col-lg-4" style="border-left: 1px solid #ddd;">
                                    <input class="form-control form-control-lg" type="number" placeholder="Apt , Unite , Suite">
                                </div>
                                <div class="col-lg-2">
                                    <input class="form-control form-control-lg" type="number" placeholder="Buzz Code">
                                </div>
                                <div class="col-lg-2">
                                    <input class="form-control form-control-lg schedual-delivery" type="number" placeholder="Specific Time ?">
                                </div>
                            </div>
                            <div class="row" style="margin-top: 3rem">
                                <div class="drivers owl-carousel">
                                    <a class="driver">Driver #1</a>
                                    <a class="driver">Driver #2</a>
                                    <a class="driver">Driver #3</a>
                                    <a class="driver">Driver #4</a>
                                    <a class="driver">Driver #5</a>
                                    <a class="driver">Driver #6</a>
                                    <a class="driver">Driver #7</a>
                                    <a class="driver">Driver #8</a>
                                    <a class="driver">Driver #9</a>
                                    <a class="driver">Driver #10</a>
                                    <a class="driver">Driver #11</a>
                                    <a class="driver">Driver #12</a>
                                </div>
                            </div>
                        </div>
                        <div id="takeAway-bill-details">
                            <div class="row" style="width: 450px; margin: 0 auto">
                                <div class="col-lg-12" style="margin-top: 1rem">
                                    <input class="form-control form-control-lg" type="number" placeholder="Phone Number">
                                </div>
                                <div class="col-lg-12" style="margin-top: 1rem">
                                    <input class="form-control form-control-lg" type="text" placeholder="Full Client Name" disabled>
                                </div>
                                <div class="col-lg-12" style="margin-top: 1rem">
                                    <input class="form-control schedual-delivery form-control-lg" placeholder="Add Time To Pickup">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card" id="payment-stuff" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4">
                                <button type="button" class="btn btn-success btn-block noBorderRadius pay-this-bill">Pay</button>
                            </div>
                            <div class="col-lg-8 text-right">
                                <button type="button" class="btn btn-secondary noBorderRadius">RePrint</button>
                                <button type="button" class="btn btn-secondary noBorderRadius">Addition Print</button>
                                <button type="button" class="btn btn-secondary noBorderRadius">Dublicate Print</button>
                                <button type="button" class="btn btn-warning noBorderRadius">Refund</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Services & Clients -->
                <div id="edit-section" hidden>
                    <div class="card" id="services_clients_panels-edit" style="margin-bottom: 2rem">

                        <nav class="nav nav-fill servicesPanel">
                            <a class="nav-link nav-item" href="#">Service #1</a>
                            <a class="nav-link nav-item" href="#">Service #2</a>
                            <a class="nav-link nav-item" href="#">Service #3</a>
                            <a class="nav-link nav-item" href="#">Service #4</a>
                            <a class="nav-link nav-item" href="#">Service #5</a>
                        </nav>
                        <nav class="nav nav-fill clientsPanel">
                            <a class="nav-link nav-item" data-client-number="1">CL #1</a>
                            <a class="nav-link nav-item" data-client-number="2">CL #2</a>
                            <a class="nav-link nav-item" data-client-number="3">CL #3</a>
                            <a class="nav-link nav-item" data-client-number="4">CL #4</a>
                            <a class="nav-link nav-item" data-client-number="5">CL #5</a>
                            <a class="nav-link nav-item" data-client-number="6">CL #6</a>
                            <a class="nav-link nav-item" data-client-number="7">CL #7</a>
                            <a class="nav-link nav-item" data-client-number="8">CL #8</a>
                        </nav>
                        <a class="moreClient" id="openClientCenter"><i class="fas fa-plus"></i></a>

                    </div>
                    <!-- Categories -->
                    <div class="accordion" id="categories-edit">
                        <div class="card category" style="border: 2px solid #546e7a; border-radius: .25rem;">
                            <i class="fab fa-hotjar item-trend-icon"></i>
                            <p class="item-notListed">Not Listed ?</p>

                            <div class="card-header cursor text-white" style="background-color: #546e7a" id="headingOne-edit" data-toggle="collapse" data-target="#categoryOne-edit" aria-expanded="true" aria-controls="categoryOne-edit">
                                <h5 class="mb-0">
                                    Main Dish
                                </h5>
                            </div>

                            <div id="categoryOne-edit" class="collapse show" aria-labelledby="headingOne-edit" data-parent="#categories-edit">
                                <div class="filters owl-carousel" style="background-color: #546e7a;">
                                    <a class="filter">filter #1</a>
                                    <a class="filter">filter #2</a>
                                    <a class="filter">filter #3</a>
                                    <a class="filter">filter #4</a>
                                    <a class="filter">filter #5</a>
                                    <a class="filter">filter #6</a>
                                    <a class="filter">filter #7</a>
                                    <a class="filter">filter #8</a>
                                    <a class="filter">filter #9</a>
                                    <a class="filter">filter #10</a>
                                    <a class="filter">filter #11</a>
                                    <a class="filter">filter #12</a>
                                    <a class="filter">filter #13</a>
                                    <a class="filter">filter #14</a>
                                    <a class="filter">filter #15</a>
                                    <a class="filter">filter #16</a>
                                </div>
                                <div class="addNonListedItem" hidden>
                                    <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Price">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block">Order</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">200</span>item 1<span class="item-price">22$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">33</span>item 22<span class="item-price">285$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">87</span>long name item 3<span class="item-price">7$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">66</span>item 1<span class="item-price">22$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">1020</span>item 22<span class="item-price">285$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus " style="background-color: #546e7a"><span class="item-qnt">785</span>long name item 3<span class="item-price">7$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">77</span>item 1<span class="item-price">22$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">85</span>item 22<span class="item-price">285$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a"><span class="item-qnt">10</span>long name item 3<span class="item-price">7$</span></a>
                                </div>
                                <div class="emptyCategory" style="margin-top: -10px">
                                    <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                    <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                </div>
                            </div>
                        </div>
                        <div class="card category" style="border: 2px solid #6d4c41;">
                            <i class="fab fa-hotjar item-trend-icon"></i>
                            <p class="item-notListed">Not Listed ?</p>

                            <div class="card-header cursor text-white" style="background-color: #6d4c41" id="headingFive-edit" data-toggle="collapse" data-target="#categoryFive-edit" aria-expanded="true" aria-controls="categoryFive-edit">
                                <h5 class="mb-0">
                                    Sandwich
                                </h5>
                            </div>

                            <div id="categoryFive-edit" class="collapse" aria-labelledby="headingFive-edit" data-parent="#categories-edit">
                                <div class="filters owl-carousel" style="background-color: #6d4c41;">
                                    <a class="filter">filter #1</a>
                                    <a class="filter">filter #2</a>
                                    <a class="filter">filter #3</a>
                                    <a class="filter">filter #4</a>
                                    <a class="filter">filter #5</a>
                                    <a class="filter">filter #6</a>
                                    <a class="filter">filter #7</a>
                                    <a class="filter">filter #8</a>
                                    <a class="filter">filter #9</a>
                                    <a class="filter">filter #10</a>
                                    <a class="filter">filter #11</a>
                                    <a class="filter">filter #12</a>
                                    <a class="filter">filter #13</a>
                                    <a class="filter">filter #14</a>
                                    <a class="filter">filter #15</a>
                                    <a class="filter">filter #16</a>
                                </div>
                                <div class="addNonListedItem" hidden>
                                    <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Price">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block">Order</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body"></div>
                                <div class="emptyCategory" style="margin-top: -10px">
                                    <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                    <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                </div>
                            </div>
                        </div>
                        <div class="card category" style="border: 2px solid #7cb342;">
                            <i class="fab fa-hotjar item-trend-icon"></i>
                            <p class="item-notListed">Not Listed ?</p>

                            <div class="card-header cursor text-white" style="background-color: #7cb342" id="headingTwo-edit" data-toggle="collapse" data-target="#categoryTwo-edit" aria-expanded="true" aria-controls="categoryTwo-edit">
                                <h5 class="mb-0">
                                    Salad
                                </h5>
                            </div>

                            <div id="categoryTwo-edit" class="collapse" aria-labelledby="headingTwo-edit" data-parent="#categories-edit">
                                <div class="filters owl-carousel" style="background-color: #7cb342;">
                                    <a class="filter">filter #1</a>
                                    <a class="filter">filter #2</a>
                                    <a class="filter">filter #3</a>
                                    <a class="filter">filter #4</a>
                                    <a class="filter">filter #5</a>
                                    <a class="filter">filter #6</a>
                                    <a class="filter">filter #7</a>
                                    <a class="filter">filter #8</a>
                                    <a class="filter">filter #9</a>
                                    <a class="filter">filter #10</a>
                                    <a class="filter">filter #11</a>
                                    <a class="filter">filter #12</a>
                                    <a class="filter">filter #13</a>
                                    <a class="filter">filter #14</a>
                                    <a class="filter">filter #15</a>
                                    <a class="filter">filter #16</a>
                                </div>
                                <div class="addNonListedItem" hidden>
                                    <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Price">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block">Order</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body"></div>
                                <div class="emptyCategory" style="margin-top: -10px">
                                    <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                    <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                </div>
                            </div>
                        </div>
                        <div class="card category" style="border: 2px solid #fdd835;">
                            <i class="fab fa-hotjar item-trend-icon"></i>
                            <p class="item-notListed">Not Listed ?</p>

                            <div class="card-header cursor text-white" style="background-color: #fdd835" id="headingThree-edit" data-toggle="collapse" data-target="#categoryThree-edit" aria-expanded="true" aria-controls="categoryThree-edit">
                                <h5 class="mb-0">
                                    Drinks
                                </h5>
                            </div>

                            <div id="categoryThree-edit" class="collapse" aria-labelledby="headingThree-edit" data-parent="#categories-edit">
                                <div class="filters owl-carousel" style="background-color: #fdd835;">
                                    <a class="filter">filter #1</a>
                                    <a class="filter">filter #2</a>
                                    <a class="filter">filter #3</a>
                                    <a class="filter">filter #4</a>
                                    <a class="filter">filter #5</a>
                                    <a class="filter">filter #6</a>
                                    <a class="filter">filter #7</a>
                                    <a class="filter">filter #8</a>
                                    <a class="filter">filter #9</a>
                                    <a class="filter">filter #10</a>
                                    <a class="filter">filter #11</a>
                                    <a class="filter">filter #12</a>
                                    <a class="filter">filter #13</a>
                                    <a class="filter">filter #14</a>
                                    <a class="filter">filter #15</a>
                                    <a class="filter">filter #16</a>
                                </div>
                                <div class="addNonListedItem" hidden>
                                    <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Price">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block">Order</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835">item 1<span class="item-price">22$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835">item 22<span class="item-price">285$</span></a>
                                    <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835">long name item 3<span class="item-price">7$</span></a>
                                </div>
                                <div class="emptyCategory" style="margin-top: -10px">
                                    <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                    <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                </div>
                            </div>
                        </div>
                        <div class="card category" style="border: 2px solid #e53935;">
                            <i class="fab fa-hotjar item-trend-icon"></i>
                            <p class="item-notListed">Not Listed ?</p>

                            <div class="card-header cursor text-white" style="background-color: #e53935" id="headingFour-edit" data-toggle="collapse" data-target="#categoryFour-edit" aria-expanded="true" aria-controls="categoryFour-edit">
                                <h5 class="mb-0">
                                    Sweet
                                </h5>
                            </div>

                            <div id="categoryFour-edit" class="collapse" aria-labelledby="headingFour-edit" data-parent="#categories-edit">
                                <div class="filters owl-carousel" style="background-color: #e53935;">
                                    <a class="filter">filter #1</a>
                                    <a class="filter">filter #2</a>
                                    <a class="filter">filter #3</a>
                                    <a class="filter">filter #4</a>
                                    <a class="filter">filter #5</a>
                                    <a class="filter">filter #6</a>
                                    <a class="filter">filter #7</a>
                                    <a class="filter">filter #8</a>
                                    <a class="filter">filter #9</a>
                                    <a class="filter">filter #10</a>
                                    <a class="filter">filter #11</a>
                                    <a class="filter">filter #12</a>
                                    <a class="filter">filter #13</a>
                                    <a class="filter">filter #14</a>
                                    <a class="filter">filter #15</a>
                                    <a class="filter">filter #16</a>
                                </div>
                                <div class="addNonListedItem" hidden>
                                    <div class="row " style="padding: 1.25rem 1.25rem 0 1.25rem;">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="Price">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block">Order</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body"></div>
                                <div class="emptyCategory" style="margin-top: -10px">
                                    <img src="imgs/empty/emptyCategory.svg" style="max-width: 100%">
                                    <p class="text-muted">This Category Is Empty , Go to <button type="button" class="btn btn-link">Categories </button> Page And Add Some Items ! .</p>
                                </div>
                            </div>
                        </div>
                        <!-- Custom Dish -->
                        <div class="card category" style="border: 2px solid #ccc; margin-top: 2rem">

                            <div class="card-header cursor text-white" style="background-color: #fff ; color : #3e3e3e" id="customDishHeading-edit" data-toggle="collapse" data-target="#customDish-edit" aria-expanded="true" aria-controls="customDish-edit">
                                <h5 class="mb-0" style="color : #3e3e3e">
                                    Custom Dish
                                </h5>
                            </div>

                            <div id="customDish-edit" class="collapse" aria-labelledby="customDishHeading-edit" data-parent="#categories-edit">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="Name">
                                        </div>
                                        <div class="col">
                                            <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="Budget">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-light btn-block btn-lg">Add</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>

            </div>
            <!-- invoices -->
            <div class="col-lg-3">
                <div id="invoice-orders-edit">
                    <div class="card" >
                        <i class="fas fa-sticky-note note-invoice"></i>
                        <div class="card-body" id="itemsInInvoice" style="height: 32rem; overflow: auto;">
                            <div class="itemsInInvoice display-block" hidden>
                                <h5 class="card-title">Order Num : #12</h5>
                                <hr>
                            </div>
                            <div class="invoiceNote" hidden>
                                <h5 class="card-title">Order Num : #12 - <span class="text-muted">Notes</span></h5>
                                <hr>
                                <div class="list-group quickNotes">
                                    <button type="button" class="list-group-item list-group-item-action">Quickly !</button>
                                    <button type="button" class="list-group-item list-group-item-action">Well cooked</button>
                                    <button type="button" class="list-group-item list-group-item-action">Half cooked</button>
                                    <button type="button" class="list-group-item list-group-item-action">Extral For All</button>
                                    <button type="button" class="list-group-item list-group-item-action">Extra Fried Potatoes</button>
                                    <button type="button" class="list-group-item list-group-item-action">Without Mayonnaise For All</button>
                                </div>

                                <textarea class="form-control" id="otherNotes" rows="5" placeholder="Other Notes" style="margin-top: 1rem"></textarea>

                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="row text-muted">
                                <div class="col-lg-6">
                                    <h6>Subtotal : 400$</h6>
                                </div>
                                <div class="col-lg-6">
                                    <h6>Taxes : 50$</h6>
                                </div>
                            </div>
                            <h4 class="noMargin">Total : 350$</h4>
                        </div>
                    </div>
                </div>
                <div id="invoice-services-edit">
                    <div class="card">
                        <div class="card-body" style="height: 32rem; overflow: auto;">
                            <h5 class="card-title">Table Number <input class="btn btn-light" type="button" id="table-number" data-modal-id="choose-table" modal-type="bottom" value="--"></h5>
                            <ul class="nav nav-pills nav-fill nav-tabs invoice-action-center" id="invoice-action-center" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link items active" id="items-edit-tab" data-toggle="tab" href="#items-edit" role="tab" aria-controls="items-edit" aria-selected="true"><i class="fas fa-bars"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link clients" id="items-edit-tab" data-toggle="tab" href="#viewByClient-edit" role="tab" aria-controls="viewByClient-edit" aria-selected="true"><i class="fas fa-street-view"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="notes-edit-tab" data-toggle="tab" href="#notes-edit" role="tab" aria-controls="notes-edit" aria-selected="false"><i class="fas fa-sticky-note"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="schedule-edit-tab" data-toggle="tab" href="#schedule-edit" role="tab" aria-controls="schedule-edit" aria-selected="false"><i class="fas fa-clock"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link arrangeItems" data-toggle="tab" href=""><i class="fas fa-hand-rock"></i></a>
                                </li>
                            </ul>
                            <hr>
                            <div class="tab-content" id="myTabContent">
                                <!-- Services -->
                                <div class="tab-pane fade show active" id="items-edit" role="tabpanel" aria-labelledby="items-edit-tab">
                                    <div id="services">
                                        <div class="service" id="1" data-drop-target="true">
                                            <!--
                                            <div class="chooseClientDish client">
                                                <h4>Client <span class="text-muted">#1</span></h4>
                                                <h4>Client <span class="text-muted">#2</span></h4>
                                                <h4>Client <span class="text-muted">#3</span></h4>
                                                <h4>Client <span class="text-muted">#4</span></h4>
                                            </div>
                                            -->
                                            <h4>Service <span class="text-muted">#1</span></h4>
                                            <a role="button" id="item1"  draggable="false" class="btn item item-serviced" style="background-color: #546e7a"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">2</span>item 1 - 12:30<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item2"  draggable="false" class="btn item item-serviced" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">10</span>item 2 - 12:34<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item3"  draggable="false" class="btn item item-serviced" style="background-color: #7cb342"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">8</span>item 3 - 12:39<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item4"  draggable="false" class="btn item item-serviced" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">1</span>item 4 - 12:42<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item5"  draggable="false" class="btn item item-serviced" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">14</span>item 5 - 12:50<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item6"  draggable="false" class="btn item item-serviced" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">3</span>item 6 - 12:53<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>

                                        </div>
                                        <div class="service" id="2" data-drop-target="true">
                                            <h4>Service <span class="text-muted">#2</span></h4>
                                            <a role="button" id="item7"  draggable="false" class="btn item item-serviced" style="background-color: #546e7a"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">2</span>item 1 - 1:00 <span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item8"  draggable="false" class="btn item" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">10</span>item 2<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item9"  draggable="false" class="btn item" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">1</span>item 4<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                            <a role="button" id="item10"  draggable="false" class="btn item" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="#1 , #2 , #3 , #4 ">3</span>item 6<span class="item-plus"><i class="fas fa-redo-alt"></i></span></a>
                                        </div>
                                    </div>
                                </div>

                                <!-- View By Client -->
                                <div class="tab-pane fade" id="viewByClient-edit" role="tabpanel" aria-labelledby="viewByClient-edit-tab">
                                    <div id="clients">
                                        <div class="client" id="1" data-drop-target="true">
                                            <h4>Client <span class="text-muted">#1</span></h4>
                                            <a role="button" id="item4" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4</a>
                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5</a>
                                            <a role="button" id="item6" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #4">3</span>item 6</a>

                                        </div>
                                        <div class="client" id="2" data-drop-target="true">
                                            <h4>Client <span class="text-muted">#2</span></h4>
                                            <a role="button" id="item4"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item itemWithoutPlus" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4</a>
                                            <a role="button" id="item5"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5</a>
                                            <a role="button" id="item6"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item itemWithoutPlus" style="background-color: #e53935"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #4">3</span>item 6</a>
                                            <a role="button" id="item5"  data-toggle="modal" data-target="#customizeItem" draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5</a>
                                        </div>
                                        <div class="client" id="3" data-drop-target="true">
                                            <h4>Client <span class="text-muted">#3</span></h4>
                                            <a role="button" id="item4" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #fdd835"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #1">1</span>item 4</a>
                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5</a>
                                            <a role="button" id="item5" data-toggle="modal" data-target="#customizeItem"  draggable="false" class="btn item itemWithoutPlus" style="background-color: #6d4c41"><span class="item-minus"><i class="fas fa-minus"></i></span><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="SRV : #3">14</span>item 5</a>
                                        </div>
                                    </div>
                                </div>

                                <!-- invoice Notes -->
                                <div class="tab-pane fade" id="notes-edit" role="tabpanel" aria-labelledby="profile-edit-tab">
                                    <div class="list-group quickNotes">
                                        <button type="button" class="list-group-item list-group-item-action">Quickly !</button>
                                        <button type="button" class="list-group-item list-group-item-action">Well cooked</button>
                                        <button type="button" class="list-group-item list-group-item-action">Half cooked</button>
                                        <button type="button" class="list-group-item list-group-item-action">Extral For All</button>
                                        <button type="button" class="list-group-item list-group-item-action">Extra Fried Potatoes</button>
                                        <button type="button" class="list-group-item list-group-item-action">Without Mayonnaise For All</button>
                                    </div>
                                    <textarea class="form-control" id="otherNotes" rows="5" placeholder="Other Notes" style="margin-top: 1rem"></textarea>

                                </div>

                                <!-- schedule -->
                                <div class="tab-pane fade" id="schedule-edit" role="tabpanel" aria-labelledby="schedule-edit-tab">
                                    <div class="row">
                                        <div class="col">
                                            <!-- Small switch -->
                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #1</label>
                                          </span>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <!-- Small switch -->
                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #2</label>
                                          </span>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <!-- Small switch -->
                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #3</label>
                                          </span>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <!-- Small switch -->
                                            <div class="form-group">
                                          <span class="switch switch-sm">
                                            <input type="checkbox" class="switch" id="switch-sm">
                                            <label for="switch-sm">Service #4</label>
                                          </span>
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="radio">
                                            <input id="radio-1" name="holdOption" value="1" type="radio">
                                            <label  for="radio-1" class="radio-label label-small">Hold All Invoice For Limited Time </label>
                                        </div>
                                        <div class="radio">
                                            <input id="radio-2" name="holdOption" value="2" type="radio">
                                            <label  for="radio-2" class="radio-label label-small">Hold to Un Hold </label>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div id="holdOption1" class="option" style="display: none">
                                            <div class="row" style="margin: 1rem 0 0 0">
                                                <div class="col-lg-6">
                                                    <h6> Hold For : </h6>
                                                </div>
                                                <div class="col-lg-6">
                                                    <input class="form-control form-control-sm" type="number" placeholder="30 min">
                                                </div>
                                            </div>

                                            <div class="row" style="margin: 1rem 0 0 0" >

                                                <div class="col-lg-6">
                                                    <h6> Notify Me During : </h6>
                                                </div>
                                                <div class="col-lg-6">
                                                    <input class="form-control form-control-sm" type="number" placeholder="5 min">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="row text-muted">
                                <div class="col-lg-6">
                                    <h6>Subtotal : 400$</h6>
                                </div>
                                <div class="col-lg-6">
                                    <h6>Taxes : 50$</h6>
                                </div>
                            </div>
                            <h4 class="noMargin">Total : 350$</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Client Control -->
        <div id="client-control" hidden>
            <div class="row">
                <div class="col-lg-6">
                    <button type="button" class="btn btn-primary noBorderRadius saveNewClients" style="margin-bottom: 1rem">Save</button>
                    <button type="button" class="btn btn-danger noBorderRadius closeClientCenter" style="margin-bottom: 1rem">Cancel</button>
                </div>
                <div class="col-lg-6 text-right">
                    <button type="button" class="btn btn-dark noBorderRadius doUnEqalSplit right" style="margin-bottom: 1rem">More Clients <i class="fas fa-user-plus"></i></button>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <h3> Client Control - table 43</h3>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>1</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>2</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>3</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>4</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>5</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>6</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>7</h1>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="client-card">
                                <i class="fas fa-times-circle delete-this-client"></i>
                                <h1><span class="text-muted">#</span>8</h1>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
	

    <div class="contents" id="bill-split" hidden>
        <div class="row">
            <div class="col-lg-6">
                <button type="button" class="btn btn-danger noBorderRadius canceldoUnEqalSplit right" style="margin-bottom: 1rem">Cancel Split</button>
                <button type="button" class="btn btn-primary noBorderRadius doUnEqalSplit right" style="margin-bottom: 1rem">Split</button>
            </div>
            <div class="col-lg-6 text-right">
                <button type="button" class="btn btn-dark noBorderRadius doUnEqalSplit right" style="margin-bottom: 1rem">More Clients <i class="fas fa-user-plus"></i></button>
            </div>
        </div>

        <div id="unEqual">
            <div class="row">
                <div class="col-lg-3" style="margin-top: 1rem">
                    <div class="card" >
                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                            <h5 class="card-title">Invoice Num : #1 - <span class="text-muted">Client 1</span></h5>
                            <hr>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                        </div>
                        <div class="card-footer">
                            <div class="row text-muted">
                                <div class="col-lg-6">
                                    <h6>Subtotal : 400$</h6>
                                </div>
                                <div class="col-lg-6 text-right">
                                    <h6>TPS Taxes : 50$</h6>
                                    <h6>TVQ Taxes : 30$</h6>
                                </div>
                            </div>

                            <div class="row text-muted">
                                <div class="col-lg-8">
                                    <h4 class="noMargin">Total : 380$</h4>
                                </div>
                                <div class="col-lg-4">
                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-body">
                            <div class="UnEqualInvoices owl-carousel">

                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #2 - <span class="text-muted">Client 2</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #3 - <span class="text-muted">Client 3</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #4 - <span class="text-muted">Client 4</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #5 - <span class="text-muted">Client 5</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #6 - <span class="text-muted">Client 6</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #7 - <span class="text-muted">Client 7</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="invoice">
                                    <div class="card" >
                                        <div class="card-body itemsInSplit" style="height: 32rem; overflow: auto;">
                                            <h5 class="card-title">Invoice Num : #8 - <span class="text-muted">Client 8</span></h5>
                                            <hr>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #546e7a" <span class="item-qnt">2</span>item 1 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">10</span>item 2 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #7cb342" <span class="item-qnt">8</span>item 3 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #fdd835" <span class="item-qnt">1</span>item 4 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #6d4c41" <span class="item-qnt">14</span>item 5 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>
                                            <a role="button" class="btn item itemWithoutMinus" style="background-color: #e53935" <span class="item-qnt">3</span>item 6 <span class="item-share-split"><i class="fas fa-share-alt"></i></span></a>

                                        </div>
                                        <div class="card-footer">
                                            <div class="row text-muted">
                                                <div class="col-lg-6">
                                                    <h6>Subtotal : 400$</h6>
                                                </div>
                                                <div class="col-lg-6 text-right">
                                                    <h6>TPS Taxes : 50$</h6>
                                                    <h6>TVQ Taxes : 30$</h6>
                                                </div>
                                            </div>

                                            <div class="row text-muted">
                                                <div class="col-lg-8">
                                                    <h4 class="noMargin">Total : 380$</h4>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="button" class="btn btn-success btn-block pay-this-bill">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <div class="contents" id="bill-pay" hidden>
        <div class="row">
            <div class="col-lg-6">
                <h3>Pay Order Invoice Num <span class="text-muted"> #57 </span> - Table Num <span class="text-muted"> 26     </span></h3>
            </div>
            <div class="col-lg-6 text-right">
                <button type="button" class="btn btn-success noBorderRadius">Pay</button>
                <button type="button" class="btn btn-success noBorderRadius">Pay Without Receipt</button>
                <button type="button" class="btn btn-danger noBorderRadius cancel-pay-this-bill" >Cancel</button>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="row" style="margin: 2rem 0">
                    <div class="col-lg-4">
                        <h5 class="text-muted">Subtotal : <span class="font-weight-bold">350$</span></h5>
                        <h5 class="text-muted">TPS Taxes : <span class="font-weight-bold">67.40$</span></h5>
                        <h5 class="text-muted">TVQ Taxes : <span class="font-weight-bold">25.20$</span></h5>
                    </div>
                    <div class="col-lg-4 text-center">
                        <div class="input-group">
                            <div class="input-group-prepend display-block" id="dollarDiscount" hidden>
                                <div class="input-group-text noBorderRadius display-block">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                            <div class="input-group-prepend" id="percentDiscount" hidden>
                                <div class="input-group-text noBorderRadius display-block">
                                    <i class="fas fa-percentage"></i>
                                </div>
                            </div>
                            <input class="form-control noBorderRadius" type="number" placeholder="Discount">
                        </div>

                        <input class="form-control noBorderRadius" type="number" style="margin-top: 1rem" placeholder="Balance" disabled>
                    </div>
                    <div class="col-lg-4 text-center">
                        <h2 style="margin: 1rem 0 ; font-size: 50px">Total : <span class="font-weight-bold">465.60$</span></h2>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                            <div class="input-group-prepend">
                                <div class="input-group-text noBorderRadius">Cash</div>
                            </div>
                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                        </div>

                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                            <div class="input-group-prepend">
                                <div class="input-group-text noBorderRadius">Debit</div>
                            </div>
                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                        </div>

                        <div class="input-group input-group-lg" style="margin-top: 1rem">
                            <div class="input-group-prepend">
                                <div class="input-group-text noBorderRadius">Coupon</div>
                            </div>
                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Amount">
                            <div class="input-group-prepend">
                                <div class="input-group-text noBorderRadius">77$</div>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-8" style="border-left : 1px solid #eee">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="creditChoose">
                                    <i class="fab fa-cc-visa"></i>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="creditChoose">
                                    <i class="fab fa-cc-mastercard"></i>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="creditChoose">
                                    <i class="fab fa-cc-amex"></i>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="creditChoose">
                                    <i class="fas fa-credit-card"></i>
                                </div>
                            </div>
                        </div>
                        <div class="input-group input-group-lg">
                            <div class="input-group-prepend">
                                <div class="input-group-text noBorderRadius">Credit</div>
                            </div>
                            <input type="text" class="form-control noBorderRadius" id="inlineFormInputGroupUsername" placeholder="Username">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card text-white bg-danger" style="margin-top: 2rem">
            <div class="card-header">ERROR ! </div>
            <div class="card-body">
                <h5 class="card-title">Check Your Money , and Try Again</h5>
            </div>
        </div>
    </div>




    <!-- Customize Item Modal -->
    <div class="modal fade" id="customizeItem" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header row">
                    <div class="col-lg-6">
                        <h3 class="modal-title">Item Name <span class="text-muted">Customize</span></h3>
                    </div>
                    <div class="col-lg-6 text-right">

                        <div class="nav customize-nav" id="nav-tab" role="tablist" style="display: inline-block ;">

                            <a class="btn btn-light noBorderRadius border-0" id="nav-change-table-tab" data-toggle="tab" href="#nav-change-table" role="tab" aria-controls="nav-change-table" aria-selected="false" style="margin-top: -2px ;">Table #12</a>

                        </div>

                        <div class="dropdown d-inline-block">
                            <a class="btn btn-secondary btn-block dropdown-toggle" href="#" role="button" id="service-item" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Service #2
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="service-item">
                                <a class="dropdown-item" href="#">Service #1</a>
                                <a class="dropdown-item disabled" href="#">Service #2</a>
                                <a class="dropdown-item" href="#">Service #3</a>
                                <a class="dropdown-item" href="#">Service #4</a>
                                <a class="dropdown-item" href="#">Service #5</a>
                            </div>
                        </div>

                        <!-- Open Share Client Tab -->
                        <div class="nav customize-nav" id="nav-tab" role="tablist" style="display: inline-block ;">

                            <a class="btn btn-secondary" id="nav-share-client-tab" data-toggle="tab" href="#nav-share-client" role="tab" aria-controls="nav-share-client" aria-selected="false" style="margin-top: -2px ;">Clients</a>

                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <nav>
                        <div class="nav nav-tabs customize-nav" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-component-tab" data-toggle="tab" href="#nav-component" role="tab" aria-controls="nav-component" aria-selected="true">Component</a>
                            <a class="nav-item nav-link" id="nav-weight-tab" data-toggle="tab" href="#nav-weight" role="tab" aria-controls="nav-weight" aria-selected="false">Weight</a>
                            <a class="nav-item nav-link" id="nav-discount-tab" data-toggle="tab" href="#nav-discount" role="tab" aria-controls="nav-discount" aria-selected="false">Discount</a>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <!-- Components -->
                        <div class="tab-pane fade show active" id="nav-component" role="tabpanel" aria-labelledby="nav-component-tab">
                            <div class="row" style="margin-top: 2rem">
                                <div class="col-lg-3" style="border-right : 1px solid #ddd ;">
                                    <div class="btn-group ">
                                        <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Select Cook Way
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#">Option #1</a>
                                            <a class="dropdown-item" href="#">Option #2</a>
                                            <a class="dropdown-item" href="#">Option #3</a>
                                            <a class="dropdown-item" href="#">Option #4</a>
                                            <a class="dropdown-item" href="#">Option #5</a>
                                        </div>
                                    </div>
                                    <div class="form-group" style="margin-top: 1rem">
                                        <textarea class="form-control" id="" rows="5" placeholder="Other Note"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-9">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h4 class="text-muted"> Basics </h4>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                            <button type="button" class="btn btn-light itemComponent">Basic</button>
                                        </div>
                                        <div class="col-lg-12" style="margin-top: 1rem">
                                            <h4 class="text-muted"> Optional </h4>
                                            <button type="button" class="btn btn-light itemComponent">component #1 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #2 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #3 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #4 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #5 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #6 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #7 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>
                                            <button type="button" class="btn btn-light itemComponent">component #8 <span><i class="fas fa-trash-alt"></i><i class="fas fa-undo-alt display-hidden"></i></span></button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- Weight -->
                        <div class="tab-pane fade" id="nav-weight" role="tabpanel" aria-labelledby="nav-weight-tab">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="row" style="margin-top: 1rem;">
                                        <div class="col-lg-12">
                                            <button type="button" class="btn btn-block btn-lg noBorderRadius btn-light weightSize" value="2">2 Kg</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light weightSize" value="1">1 Kg</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light weightSize" value="0.5">0.5 Kg</button>
                                        </div>
                                        <div class="w-100"></div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light weightSize" value="0.25">0.25 Kg</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light weightSize" value="0.02">200 g</button>
                                        </div>
                                        <div class="col-lg-12">
                                            <button type="button" class="btn btn-block btn-lg noBorderRadius btn-warning resetWeight">Reset</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 text-center">
                                    <input class="form-control resaultWeight" type="text" value="0">
                                </div>

                            </div>
                        </div>
                        <!-- Discount -->
                        <div class="tab-pane fade" id="nav-discount" role="tabpanel" aria-labelledby="nav-discount-tab">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="row" style="margin-top: 1rem;">
                                        <div class="col-lg-12">
                                            <button type="button" class="btn btn-block btn-lg noBorderRadius btn-light discountSize" value="100">100 % - Free</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light discountSize" value="50">50 %</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light discountSize" value="25">25 %</button>
                                        </div>
                                        <div class="w-100"></div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light discountSize" value="10">10 %</button>
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn noBorderRadius btn-lg btn-block btn-light discountSize" value="5">5 %</button>
                                        </div>
                                        <div class="col-lg-12">
                                            <button type="button" class="btn btn-block btn-lg noBorderRadius btn-warning resetDiscount">Reset</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 text-center">
                                    <input class="form-control resaultDiscount" type="text" value="0">
                                    <input class="form-control form-control-lg noBorderRadius border-0" type="text" placeholder="Item Price" readonly>
                                    <input class="form-control form-control-lg noBorderRadius border-0" style="margin-top: 0.5rem" type="text" placeholder="Item Price After Discount" readonly>
                                </div>

                            </div>
                        </div>
                        <!-- Change Table -->
                        <div class="tab-pane fade" id="nav-change-table" role="tabpanel" aria-labelledby="nav-change-table-tab">
                            <div class="row" style="margin-top: 2rem">
                                <div class="col-lg-12">
                                    <h5 class="text-muted w-100"> Choose Table To Move Item To Another Table</h5>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="15">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>15</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="12">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>12</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="33">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>33</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="45">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>45</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="66">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>66</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="88">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>88</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="77">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>77</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="99">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>99</h1>
                                    </div>
                                </div>
                                <div class="col-lg-3" data-filter-item data-filter-name="75">
                                    <div class="choose-card">
                                        <h1><span class="text-muted">#</span>75</h1>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- Share Client -->
                        <div class="tab-pane fade" id="nav-share-client" role="tabpanel" aria-labelledby="nav-share-client-tab">
                            <div class="row" style="margin-top: 2rem">
                                <div class="col-lg-12">
                                    <h5 class="w-100 text-muted"> Click On Clients To Share Item Between Them And Client #4 </h5>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>1</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>2</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>3</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card clientOwnedItem">
                                        <h1><span class="text-muted">#</span>4</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>5</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>6</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>7</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>8</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>9</h1>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <div class="choose-clientShare-card">
                                        <h1><span class="text-muted">#</span>10</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger noBorderRadius" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success noBorderRadius">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- choose table modal  -->
    <div id="choose-table" class="modal-bottom" style="display:none;">

        <!-- Modal content -->
        <div class="modal-content">
            <div class="modal-header row">
                <div class="col-8"><h2>Choose Table : </h2></div>
                <div class="col-4">
                    <input class="form-control choose-table-input" type="text" placeholder="Search Table" data-search>
                </div>
                <span class="close-btn" id="close-bottom-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div class="row">

                    <div class="col-lg-2" data-filter-item data-filter-name="15">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>15</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="12">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>12</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="33">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>33</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="45">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>45</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="66">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>66</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="88">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>88</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="77">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>77</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="99">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>99</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="75">
                        <div class="choose-card">
                            <h1><span class="text-muted">#</span>75</h1>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    <!-- choose Waiter modal  -->
    <div id="choose-waiter" class="modal-bottom" style="display:none;">

        <!-- Modal content -->
        <div class="modal-content">
            <div class="modal-header row">
                <div class="col-8"><h2>Choose Waiter : </h2></div>
                <div class="col-4">
                    <input class="form-control choose-table-input" type="text" placeholder="Search Waiter" data-search>
                </div>
                <span class="close-btn" id="close-bottom-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div class="row">

                    <div class="col-lg-2" data-filter-item data-filter-name="adnan">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Adnan</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="ahmad">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Ahmad</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="fares">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Fares</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="omar">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Omar</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="omran">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Omran</h1>
                        </div>
                    </div>
                    <div class="col-lg-2" data-filter-item data-filter-name="feras">
                        <div class="choose-card">
                            <h1><i class="fas fa-male"></i> Feras</h1>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    <!-- Are You Sure Modal -->
    <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-danger" id=""><i class="fas fa-exclamation-triangle"></i> Are You Sure </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class="text-muted">deltet Invoice number 578 - table number 25</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-danger btn-lg">Yes</button>
                </div>
            </div>
        </div>
    </div>
@endsection