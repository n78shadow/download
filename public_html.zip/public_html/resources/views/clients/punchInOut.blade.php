
<!doctype html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>UPOS</title>

    <!-- Main Style -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet" type="text/css">

    <!-- Library Files -->
    <link rel="stylesheet" href="{{ asset('assets/css/font-awesome/css/all.min.css') }}">
    <link href="{{ asset('assets/css/bootstrap-switches.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('assets/css/bootstrap-radio.css') }}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/materialColor.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/toastify.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/toastify.css') }}">

    <link href="{{ asset('assets/css/bootstrap-switches.css') }}" rel="stylesheet" type="text/css">

    <style>
        body {
            /* The image used */
            background-color: #212121 !important;

            /* Full height */
            height: 100%;

            /* Center and scale the image nicely */
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }


        .keyBtns input{
            font-size: 30px;
            border-radius: 0.25rem !important;
            border: none;
            text-align: center;
            background-color: #1A1A1A;
            color: #fff;
            padding: 8px;
            margin-top: 1rem;
            height: 60px;
        }

        .keyBtns input:hover{
            background-color: #1A1A1A;
            transition: .2s;
            color : #f5f5f5;
        }

        .keyBtns input:focus{
            background-color: #1A1A1A;
            transition: .2s;
            color : #f5f5f5;
        }

        .keyBtns a {
            font-size: 24px;
            border: none;
            text-align: center;
            padding: 8px;
            margin-top: 1rem;
            height: 60px;
            line-height: 46px;
            color : #fff !important ;
        }

        .enterCode {



        }

        .punchBtns input{
            font-size: 30px;
            border-radius: 0.25rem !important;
            border: none;
            text-align: center;
            background-color: #fff;
            color: #212121;
            padding: 8px;
            margin-top: 1rem;
            height: 60px;
        }

        .punchBtns input:hover{
            background-color: #212121;
            transition: .2s;
            color : #f5f5f5;
        }

        .punchBtns input:focus{
            background-color: #212121;
            transition: .2s;
            color : #f5f5f5;
        }

        .punchBtns a {
            font-size: 24px;
            border: none;
            text-align: center;
            padding: 8px;
            margin-top: 1rem;
            height: 60px;
            line-height: 46px;
            color : #fff !important ;
        }


        .nav-tabs {
            border-bottom: none;
            margin-bottom: -2px;
        }

        .nav-tabs .nav-link.active {
            color: #495057;
            background-color: #fff;
            /* border-color: #dee2e6 #dee2e6 #fff; */
        }

        .nav-tabs .nav-link {
            border: 1px solid transparent;
            border-top-left-radius: 0rem;
            border-top-right-radius: 0rem;
        }

        /*Small devices (landscape phones, 576px and up)*/
        @media (min-width: 400px) {
            .margin-rr {
                margin : 0 -6rem ;
            }
        }

        /*Medium devices (tablets, 768px and up)*/
        @media (min-width: 768px) {
            .margin-rr {
                margin : 0 -1rem ;
            }
        }

        /*Large devices (desktops, 992px and up)*/
        @media (min-width: 992px) {
            .margin-rr {
                margin : 0 10rem ;
            }
        }

        /*Extra large devices (large desktops, 1200px and up)*/
        @media (min-width: 1200px) {

        }

    </style>

</head>


<body>

<div class="contents" style="margin: 0 !important">
    <div class="container" style="margin-top : 4rem">
        <div class="row align-self-center" style="margin : 0 10rem">
            <!-- LOGO -->
            <div class="col-2"></div>

            <!-- invoices -->
            <div class="col-8">
                <div class="row">
                    <div class="col">
                        <h1 style="color : #fff ; margin: 0;"> UPOS </h1>
                        <h5 style="color : #fff ; margin: 0;">Restaurant System Manager</h5>
                    </div>
                    <div class="col">
                    </div>
                </div>

                <nav>
                    <div class="nav nav-tabs nav-justified" id="nav-tab" role="tablist">
                        <!--a class="nav-item nav-link" id="nav-logIn-tab" data-toggle="tab" href="#nav-logIn" role="tab" aria-controls="nav-logIn" aria-selected="true" style="font-size: 24px; background-color: #fff; color: #1A1A1A ;">Login</a-->
                        <a class="nav-item nav-link active" id="nav-punch-tab" data-toggle="tab" href="#nav-punch" role="tab" aria-controls="nav-punch" aria-selected="false" style="font-size: 24px; background-color: #1A1A1A; color: #fff ;">Punch In / Out</a>
                    </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                    <!-- Login  -->

                    <div class="tab-pane fade" id="nav-logIn" role="tabpanel" aria-labelledby="nav-logIn-tab" style="background-color: #fff">

                        <div class="card">
                            <div class="card-body" style="background-color: #fff ; ">

                                <div class="col-12" style="margin-top: 1rem">

                                    <!--
                                       <input type="password" class="form-control input-lg telNumber TableNumInput noBorderRadius" value="" readonly="" style="background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #9BAEC8;     width: 98%; margin-left: 5px; font-size: 26px;" placeholder="Enter Access Code">
                                       <input type="password" class="form-control input-lg password TableNumInput noBorderRadius" value=""
                                              placeholder="Enter password" readonly=""
                                              style="display: none; background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #282C37;     width: 98%; margin-left: 5px; padding-top: 12px; font-size: 26px;">
                                       <a class="BackToAccess" onclick="resetIsPass();" style="position: absolute; right: 22px; top: 0; padding: 12px; font-size: 22px; background-color: #282C37; color: #9BAEC8; display: none"><i class="fa fa-arrow-left" aria-hidden="true" ></i></a>
                                       -->
                                    <input class="form-control form-control-lg accessInput" type="password" placeholder="Enter Access Code" style="background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #1A1A1A; font-size: 22px; color : #000 ">
                                    <!-- Inputs Work -->


                                </div>

                                <div class="col-12" style="margin-top: 1rem ; margin-bottom: -1rem">

                                    <div class="alert alert-danger" id="wrongCcode" role="alert" >Your Access Code Is Worng !</div>

                                </div>

                                <div class="col-xs-12 keyBtns" style="margin-top: 1rem ;">
                                    <div class="row" style="margin-right: 9px ; margin-left : 5px ; margin-top : 1rem">
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="1">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="2">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="3">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="4">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="5">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="6">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="7">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="8">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="9">
                                        </div>

                                        <div class="col-4">
                                            <a class="btn btn-danger btn-lg btn-block clearPunchInInput" role="button">Clear</a>
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="0">
                                        </div>
                                        <div class="col-4">
                                            <a class="btn btn-secondary btn-lg btn-block enterCode" role="button">Enter</a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade show active" id="nav-punch" role="tabpanel" aria-labelledby="nav-out-tab">

                        <div class="card">
                            <div class="card-body" style="background-color: #1A1A1A ; ">

                                <div class="col-12" style="margin-top: 1rem">
                                    <!--
                                       <input type="password" class="form-control input-lg telNumber TableNumInput noBorderRadius" value="" readonly="" style="background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #9BAEC8;     width: 98%; margin-left: 5px; font-size: 26px;" placeholder="Enter Access Code">
                                       <input type="password" class="form-control input-lg password TableNumInput noBorderRadius" value=""
                                              placeholder="Enter password" readonly=""
                                              style="display: none; background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #282C37;     width: 98%; margin-left: 5px; padding-top: 12px; font-size: 26px;">
                                       <a class="BackToAccess" onclick="resetIsPass();" style="position: absolute; right: 22px; top: 0; padding: 12px; font-size: 22px; background-color: #282C37; color: #9BAEC8; display: none"><i class="fa fa-arrow-left" aria-hidden="true" ></i></a>
                                     -->
                                    <input class="form-control form-control-lg PunchInput" type="password" id="access-code" placeholder="Enter Access Code" style="background-color: transparent;box-shadow: none;border-radius: 0.25rem;border: 2px solid #fff; font-size: 22px; color: #FFF">

                                    <a class="clearPunchNum" style="    position: absolute; right: 15px; top: 0; padding: 10px 20px; font-size: 22px; background-color: #fff; color: #212121;border-radius: 0 .25rem .25rem 0;"><i class="fas fa-backspace"></i></a>
                                </div>

                                <div class="col-12" id="msg-box" style="margin-top: 1rem ; margin-bottom: -1rem">

                                </div>

                                <div class="col-xs-12 punchBtns" style="margin-top: 1rem ;">
                                    <div class="row" style="margin-right: 9px ; margin-left : 5px ; margin-top : 1rem">
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="1">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="2">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="3">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="4">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="5">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="6">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="7">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="8">
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="9">
                                        </div>

                                        <div class="col-4">
                                            <a class="btn btn-warning btn-lg btn-block" onclick="punchOut()" role="button">Out</a>
                                        </div>
                                        <div class="col-4">
                                            <input class="btn btn-default btn-lg btn-block" type="button" value="0">
                                        </div>
                                        <div class="col-4">
                                            <a class="btn btn-secondary btn-lg btn-block" onclick="punchIn()" role="button">In</a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div class="col-2"></div>

        </div>
    </div>
</div>



<!-- js Files -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>

<script src="{{ asset('assets/js/custom.js') }}"></script>
<script src="{{ asset('assets/js/pages/index.js') }}"></script>

<!-- Js Librareis -->
<script type="text/javascript" src="{{ asset('assets/js/toastify.js') }}"></script>

<script src="{{ asset('assets/js/html2canvas.js') }}"></script>

<script src="assets/js/https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.js"></script>

<script>

    //type number in TableNumInput
    var client_database = '{!! get_client_database() !!}';

    $(document).on('click', ".keyBtns input", function(){
        $(".accessInput").removeAttr("disabled")
        var num  = $(this).val();
        var oldNum = $(".accessInput").val();

        var finalTableNum = oldNum + num ;

        $(".accessInput").val(finalTableNum) ;
    });

    //Clear Tnum
    $(document).on('click', ".clearKeysNum", function(){
        $(".TableNumInput").val("") ;
        $(".addTableNum").attr("disabled", "")
    });
</script>

<script>
    //type number in TableNumInput
    $(document).on('click', ".punchBtns input", function(){
        $(".punshIn").removeAttr("disabled");
        $(".punshOut").removeAttr("disabled")

        var num  = $(this).val();
        var oldNum = $(".PunchInput").val();

        var finalTableNum = oldNum + num ;

        $(".PunchInput").val(finalTableNum) ;
    });

    //Clear Tnum
    $(document).on('click', ".clearPunchNum", function(){
        $(".PunchInput").val("") ;
        $(".punshIn").attr("disabled", "");
        $(".punshOut").attr("disabled", "");
    });
</script>

<script>
    /*
    $("#nav-punch-tab").click(function(){
        $("body").addClass("darkBg");
    });
    */

    $('#nav-punch-tab').on('shown.bs.tab', function (e) {
        $("body").addClass("darkBg");

    });

    $('#nav-logIn-tab').on('shown.bs.tab', function (e) {
        $("body").removeClass("darkBg");
    });

    /*
    $("#nav-logIn").click(function(){
        $("body").removeClass("darkBg");
    });
    */
</script>

<script>
    var client_token = '{!! get_auth_client_token() !!}';
    $(".BackToAccess").click(function(){
        $(".password").hide();
        $(".password").val("");
        $(".BackToAccess").hide();
        $(".telNumber").val("");
        $(".telNumber").show();

    });
    $(document).ready(function () {
        //window.location.href = 'waiter.html';
    })

    function punchIn () {
        var access_code = $('#access-code').val();
        var url = '{{ route('punch.in') }}';
        $.ajax({
            url: url,
            type: 'post',
            data: {"access_code": access_code,'client_token' : client_token},
        }).done(function(data) {
            console.log(data);
            var status = data.key;
            var msg = data.text;
            var printers = "";
            if (data.key == 'success') {
                printers = '<br>Print With: ';
                for (var i=0; i<data.printers.length; i++) {
                    var printer = data.printers[i];
                    printers += '&nbsp;&nbsp;<a style="cursor: pointer" onclick="printPunch(' + data.user_id + ', ' + printer.unique_id + ')"> ' + printer.printer_name + ' </a> &nbsp;&nbsp;|';
                }
                printers = printers.substring(0, printers.length - 1);
            }
            var html = '<div class="alert alert-' + status + '" role="alert" >' + msg + printers + '</div>';
            $('#msg-box').html(html);
            $('#access-code').val('');
            setTimeout(function () {
                $('#msg-box').html('');
            }, 10000);
        }).fail(function(ex){
            console.log(ex);
        });
    }

    function punchOut () {
        var access_code = $('#access-code').val();
        var url = '{{ route('punch.out') }}';
        $.ajax({
            url: url,
            type: 'post',
            data: {"access_code": access_code,'client_token' : client_token},
        }).done(function(data) {
            var status = data.key;
            var msg = data.text;
            var html = '<div class="alert alert-' + status + '" role="alert" >' + msg + '</div>';
            $('#msg-box').html(html);
            $('#access-code').val('');
            setTimeout(function () {
                $('#msg-box').html('');
            }, 10000);
        }).fail(function(ex){
            console.log(ex);
        });
    }

    function printPunch (user_id, printer_id) {
        var url = '{{ route('punch.print') }}';
        $.ajax({
            url: url,
            type: 'post',
            data: {"user_id": user_id, "printer_id": printer_id,'client_token' : client_token},
        }).done(function(data) {

        }).fail(function(ex){
            console.log(ex);
        });
    }
</script>

</body>
</html>


