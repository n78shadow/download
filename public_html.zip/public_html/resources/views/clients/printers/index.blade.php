<?php //dd('ok'); ?>
@extends('layouts.master')


@section('title','UPOS | Printers')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item active">Printers</li>
@endsection
@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection

@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>
        .ctg , .newCtg{
            padding: 1.5rem 1rem 2rem 1rem;
            margin-top: 1rem;
            border: none;
        }

        .ctg h3 , .newCtg h3 {
            margin: 0;
        }

        .ctg .color {
            position: absolute;
            bottom: 0;
            color: #fff;
            width: 100%;
            left: 0;
            padding: 2px 10px;
        }

        .ctg i {
            position: absolute;
            top: 6px;
            right: 8px;
            font-size: 26px;
            color: #ddd;
        }

        .newCtgIc{
            color: #ddd;
            position: absolute;
            bottom: 0;
            left: 0px;
            padding: 10px;
            font-size: 60px;
        }

        .customizeGroupBtn {
            margin: 5px;
        }

        .customizeGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .itemGroup-list i {
            float: right;
            padding: 4px;
            color: #dc3545;
        }

        .emptyCategory .addItem {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            left: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .emptyCategory .addSub {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            right: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .subCategory button  {
            background-color: rgba(0,0,0,0.1);
            color: #3e3e3e;
            border: none;
        }

        .deleteItem {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #bd2130;
        }

        h5 {
            display: inline-block;
        }
        /* item style */
        .itemInCtg{
            border: none;
        }

        .categoryColor {
            position: absolute;
            width: 2.2rem;
            height: 100%;
            top: 0;
            left: 0;
        }

        .itemNumber{
            position: absolute;
            left: 0.8rem;
            top: 50%;
            color: #fff;
            font-size: 25px;
            transform: translate( 0 , -50%);
        }

        .itemEditBtn{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #ccc;
        }

        .itemDeleteFromCtg{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #eee;
        }

        .itemDeleteFromCtg:hover{
            transition: 0.2s;
            color: #dc3545;
        }

        .itemGroupBtn {
            margin: 5px;
        }

        .itemGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .basicOptionalBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .sortable-ghost {
            border: 2px dashed #eee;
        }
    </style>



    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body" style="padding-bottom: 0.25rem;">
                <div class="row">

                    <div class="col text-right">
                        <a type="button" class="btn btn-primary border-0" href="{{ route('printers.create') }}" role="button" style="background-color: #546e7a"> New Printer </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents" id="allEmployee" style="margin: 0 3rem 2rem 6rem !important;">


        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Printer Name</th>
                        <th scope="col">Printer ID</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse ($printers as $printer)
                        <tr>
                            <td></td>
                            <td>{{ $printer['printer_name'] }}</td>
                            <td>{{ $printer['unique_id'] }}</td>
                            <td><a id="route{{ $printer['id'] }}" href="{{ route("printers.edit", $printer['id']) }}"><i class="fas fa-pen-square"></i></a></td>
                            <td>
                                <a style="cursor: pointer" onclick="DeleteRecordNormal('{{ route("printers.destroy", $printer['id']) }}', '{{ csrf_token() }}', '{{ route('printers.index') }}')">
                                    <i style="color: red" class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    @empty
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>




    </div>

@endsection

@section('extra-js')

    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>


        $(document).on("click", ".deleteUser",function(e) {
            $('#editUser').modal('hide');

            Toastify({
                text: " <span class='font-weight-bold'> @adnan </span> Deleted Successfuly ",
                duration: 6000,
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#e74c3c"
            }).showToast();
        });
    </script>
@endsection
