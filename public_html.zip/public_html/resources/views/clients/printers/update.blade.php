@extends('layouts.master')

@section('title','UPOS | Add new Printer')

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection

@section('page-links')
    <li class="breadcrumb-item"><a href="{{ route('printers.index') }}">Printers</a></li>
    <li class="breadcrumb-item active">Create Printer</li>
@endsection
@section('extra-styles')
    <style type="text/css">
        .roles-list {
            border: 1p solid #aaa;
        }

        .notSelected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #ccc;
        }

        .selected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #28a745;
        }
    </style>
@endsection
@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">
@endsection
@section('content')

    @include('partials.navbar')
    @include('partials.sidebar')

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">Printers <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;">Update Printer</span></h3>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" >Cancel</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" onclick="SubmitForm('forms_CreateUser')">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents" id="newEmployee" style="margin: 0 3rem 2rem 6rem !important;">
        <div class="card card-body">
            <h4>Update Printer</h4>
            <hr>
            <form method="post" id="forms_CreateUser" action="{{ route("printers.update", $printer['id']) }}">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col">
                        <input class="form-control {{ $errors->has('printer_name') ? 'is-invalid' : '' }}" type="text" value="{{ $printer['printer_name'] }}" name="printer_name" placeholder="Printer Name">
                        @if ($errors->has('printer_name'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('printer_name') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('unique_id') ? 'is-invalid' : '' }}" type="text" value="{{ $printer['unique_id'] }}" name="unique_id" placeholder="Printer ID">
                        @if ($errors->has('unique_id'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('unique_id') }}</strong>
                            </span>
                        @endif
                    </div>



                </div>
            </form>

        </div>
    </div>

@endsection




@section('extra-js')
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>
        function SubmitForm(formId)
        {
            $('#'+formId).submit();
        }

    </script>


@endsection