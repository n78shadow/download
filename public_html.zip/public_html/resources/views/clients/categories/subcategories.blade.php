<?php //dd($category); ?>
@extends('layouts.master')


@section('title','UPOS | subcatigories')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">@lang('categories.customize_groups')</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#" data-toggle="modal" data-target="#category_printers">Category Printers</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('categories.index') }}">Category</a></li>
<li class="breadcrumb-item active">Sub Category</li>
@endsection
@section('page-name','Sub Category')

@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection

@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>
        .ctg , .newCtg{
            padding: 1.5rem 1rem 2rem 1rem;
            margin-top: 1rem;
            border: none;
        }

        .ctg h3 , .newCtg h3 {
            margin: 0;
        }

        .ctg .color {
            position: absolute;
            bottom: 0;
            color: #fff;
            width: 100%;
            left: 0;
            padding: 2px 10px;
        }

        .ctg i {
            position: absolute;
            top: 6px;
            right: 8px;
            font-size: 26px;
            color: #ddd;
        }

        .newCtgIc{
            color: #ddd;
            position: absolute;
            bottom: 0;
            left: 0px;
            padding: 10px;
            font-size: 60px;
        }

        .customizeGroupBtn {
            margin: 5px;
        }

        .customizeGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .itemGroup-list i {
            float: right;
            padding: 4px;
            color: #dc3545;
        }

        .emptyCategory .addItem {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            left: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .emptyCategory .addSub {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            right: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .subCategory button  {
            background-color: rgba(0,0,0,0.1);
            color: #3e3e3e;
            border: none;
        }

        .deleteItem {
             position: absolute;
             top: 0;
             right: 0;
             padding: 25px;
             font-size: 20px;
             cursor: pointer;
             color: #bd2130;
         }

        h5 {
            display: inline-block;
        }
        /* item style */
        .itemInCtg{
            border: none;
        }

        .categoryColor {
            position: absolute;
            width: 2.2rem;
            height: 100%;
            top: 0;
            left: 0;
        }

        .itemNumber{
            position: absolute;
            left: 0.8rem;
            top: 50%;
            color: #fff;
            font-size: 25px;
            transform: translate( 0 , -50%);
        }

        .itemEditBtn{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #ccc;
        }

        .itemDeleteFromCtg{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #eee;
        }

        .itemDeleteFromCtg:hover{
            transition: 0.2s;
            color: #dc3545;
        }

        .itemGroupBtn {
            margin: 5px;
        }

        .itemGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .basicOptionalBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .sortable-ghost {
            border: 2px dashed #eee;
        }
    </style>

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">{{ $category["en_name"] }} #{{ $category["id"] }}</h3>
                    </div>
                    <div class="col text-right">
                        <a href="{{ route('items.create') }}" class="btn btn-primary noBorderRadius border-0" id="addNewItem" style="background-color: #546e7a">@lang('categories.create_item')</a>

                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" hidden>@lang('categories.cancel')</button>
                    <!--
                        <button type="button" href="href="{{ route('items.create') }}" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" hidden>Add</button>
                        -->
                    </div>
                </div>

                <div class="row" style="margin-top: 1rem ">
                    <div class="col">
                        <h4 class="text-muted"><i class="fas fa-search-plus"></i> @lang('categories.item_name')</h4>
                    </div>
                    <div class="col text-left">
                        <select class="data-searching form-control form-control-lg">

                        </select>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="contents" style="margin:-2rem 3rem 0rem 6rem !important">
        <div class="row">
            <div class="col">
                <ol class="breadcrumb" style="background-color: transparent ; padding-left: 0">
                    <li class="breadcrumb-item " aria-current="page">Sub #1</li>
                    <li class="breadcrumb-item " aria-current="page">Sub #2</li>
                    <li class="breadcrumb-item active" aria-current="page">Sub #3</li>
                </ol>
            </div>
        </div>
    </div>


    @if( empty($category["subcategories"]) && empty($category["categoryItems"]) )
    <div class="contents" id="empty_category">
        <div class="card emptyCategory" style="background-color: transparent ; border: 4px dashed #ccc; display: block">
            <div class="card-body">
                <div class="row text-center">

                    <div class="col-4">
                        <i class="fas fa-search-plus" style="position: absolute; right: 0; font-size: 6rem; color: #ccc;"></i>
                        <button type="button" class="btn addItem btn-lg border-0 btn-secondary" onclick="enableItemSearching()">@lang('categories.add_item')</button>
                    </div>

                    <div class="    col-4">
                        <h1 class="text-secondary">@lang('categories.empty_category') <i class="far fa-grimace"></i> </h1>
                        <h3 class="text-secondary"> @lang('categories.choose_what_want')  </h3>
                    </div>

                    <div class="col-4">
                        <i class="fas fa-project-diagram" style="position: absolute; left: -20px; font-size: 6rem; color: #ccc;"></i>
                        <button type="button" class="btn addSub btn-lg  border-0 btn-secondary" onclick="enableCategorySearching()">@lang('categories.add_subcategory')</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script>
            var searchUrl = '';
            var attachmentType = '';
    </script>
    @elseif( !empty($category["subcategories"]) && empty($category["categoryItems"]) )
        <div class="contents" id="allCtgs">

            <div class="row">
                @forelse($category["subcategories"] as $subcategory)
                    <div class="col-lg-3 text-center">
                        <div class="card ctg">
                            <div class="card-body">
                                <a href="{{ route('categories.edit',$subcategory["id"]) }}"><i class="fas fa-pen-square editCtg"></i></a>

                                <a href="{{ route('categories.show',$subcategory["id"]) }}"><h3>{{ $subcategory["en_name"] }}</h3></a>

                                <div class="color text-left" style="background-color: {{ $category["category_color"] }}">
                                    @if($subcategory["subCategories_count"] == 0)
                                        <small><span class="font-weight-bold">{{ $subcategory["products_count"] }}</span> @lang('categories.item')</small>
                                    @endif

                                    @if($subcategory["products_count"] == 0)
                                        <small><span class="font-weight-bold">{{ $subcategory["subCategories_count"] }}</span> @lang('categories.subcategory')</small>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                @endforelse
                <div class="col-lg-3 text-center">
                    <div class="card newCtg">
                        <div class="card-body">

                            <h3 class="text-muted"> @lang('categories.new_category') </h3>
                            <a href="{{ route('categories.create') }}" target="_blank"><i class="fas fa-plus newCtgIc"></i></a>

                        </div>
                    </div>
                </div>

            </div>

        </div>
        <script>
            var searchUrl = '{{ route('categories.search') }}';
            var attachmentType = 'subcategory';
        </script>

    @elseif( empty($category["subcategories"]) && !empty($category["categoryItems"]) )

        <div class="contents" id="allItems" style="margin: 0 3rem 2rem 6rem !important;">
            <div class="card-columns" id="itemsList">
                @forelse($category["categoryItems"] as $item)
                    <div class="card itemInCtg noBorderRadius" data-id="{{ $item["id"] }}" id="product{{ $item["id"] }}" onmousedown="setOldSequence({{ $item["id"].",".$item["sequence_in_category"] }})">
                        <div class="card-body" style="padding: 1rem 1rem 1rem 3rem;">
                            <h5 class="card-title">{{ $item["en_name"] }}</h5>
                            <a onclick="deleteItemFromCategory({{ $item["id"] }})">
                                <i class="fas fa-times-circle itemDeleteFromCtg"></i>
                            </a>
                            <span class="categoryColor" style="background-color: #546e7a">
                                <span class="itemNumber align-middle" id="orderSeq{{ $item["id"] }}">{{ $item["sequence_in_category"] }}</span>
                            </span>
                            <div class="row">
                                <div class="col">
                                    <h6 class="card-subtitle noMargin text-muted">{{ '#'.$item["id"] }}</h6>
                                </div>
                                <div class="col text-right">
                                    <h6 class="card-subtitle noMargin text-muted">{{ ($item["limit_quantity"] == 0 || $item["limit_quantity"] == null) ? "unlimited" : $item["limit_quantity"] }}</h6>
                                </div>
                            </div>

                        </div>
                    </div>
                    @empty
                        <p>@lang('categories.no_items')</p>
                    @endforelse
                    <input type="hidden" id="oldSequence" value="0">
                    <input type="hidden" id="idDragged" value="0">
                    <div class="col text-center">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="text-muted"> New item </h3>
                                <a href="{{ route('items.create') }}" target="_blank"><i class="fas fa-plus newCtgIc"></i></a>

                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <script>
            var searchUrl = '{{ route('items.search') }}';
            var attachmentType = 'item';

        </script>

    @else
        <h1> @lang('categories.category_has_item_subcategory')</h1>
    @endif


    <div class="modal fade" id="category_printers" tabindex="-1" role="dialog" aria-labelledby="category_printersLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="category_printersLabel">{{ $category["en_name"] . ' Printers' }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('printers.kitchen.store') }}" method="POST" id="printer_form">
                        @csrf
                        <input type="hidden" name="printer_type" value="normal">
                        <input type="hidden" name="category_id" value="{{ $category["id"] }}">
                        <ul class="list-group" id="printers_list">
                            @foreach($category["CategoryPrinters"] as $printer)
                                <li class="list-group-item">
                                    <div class="item_container">
                                        <span>{{ $printer["printer_name"] }}</span>
                                        <a href="#" onclick="event.preventDefault();removePrinter(event)" class="float-right" style="margin-left: 5px;color: #ff0000;"><i class="fas fa-times-circle"></i></a>
                                        <span class="float-right printer_id">{{ $printer["unique_id"] }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </form>
                </div>
                <button class="btn btn-primary btn-sm" type="button" onclick="add_printer_input()">add new printer</button>
                <br>
                <button class="btn btn-primary btn-sm" type="button" onclick="toggle_printer_div();">attach with existing printer</button>
                <div id="attach_printer_div" style="display: none">
                    <input type="text" class="form-control" placeholder="type printer id" id="attach_printer_input">
                    <button class="btn btn-primary btn-sm" onclick="attach_printer()">attach</button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="submitPrinterForm()">Save changes</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra-js')

    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>
        function searchingFor(url)
        {
            //console.log(url);
            if(url == '')
            {
                return;
            }
            $('.data-searching').select2({
                placeholder: "@lang('categories.type_search_word')",
                minimumInputLength: 2,
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor(searchUrl);

    </script>

    <script>
    function attachItem(){
        $('.data-searching').on('select2:select', function (event) {
            var item_id = $(event.currentTarget).find("option:selected").val();
            var text = $(event.currentTarget).find("option:selected").text();
            if(confirm('are you sure you want to add product' + text + ' to this category ?'))
            {
                var url = '{{ route("categories.attach.item") }}';
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {item_id: item_id,category_id:'{{ $category["id"] }}',_token :'{{ csrf_token() }}'}
                })
                    .done(function(data) {
                        if (data == 1) {
                            Toastify({
                                text: "<span class='font-weight-bold'> @lang('categories.error') </span> @lang('categories.cant_add_item_twice')",
                                duration: 6000,
                                close: true,
                                gravity: "bottom", // `top` or `bottom`
                                positionLeft: true, // `true` or `false`
                                backgroundColor: "#dc3545"
                            }).showToast();
                        } else {
                            location.reload();
                        }

                    })
                    .fail(function() {
                        console.log("error");
                    })
            }
        });
    }



    function attachCategory(){
        $('.data-searching').on('select2:select', function (event) {
            var sub_id = $(event.currentTarget).find("option:selected").val();
            var text = $(event.currentTarget).find("option:selected").text();
            //console.log('{{ $category["id"] }}');
            //console.log(sub_id);return;
            if(confirm('@lang('categories.sure_to_add_subcategory')'))
            {
                var url = "{{ route('categories.attach.subcategory') }}";
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {sub_id: sub_id,category_id:'{{ $category["id"] }}',_token :'{{ csrf_token() }}'}
                })
                    .done(function() {
                        location.reload();
                    })
                    .fail(function() {
                        console.log("error");
                    })
            }
        });
    }


    if (attachmentType == 'subcategory')
    {
        attachCategory();
    }
    else if (attachmentType == 'item')
    {
        attachItem();
    }
    else
    {

    }
    </script>


    <script>
        function enableCategorySearching() {
            alert("@lang('categories.category_search_enabled')");
                var searchUrl = '{{ route('categories.search') }}';
                searchingFor(searchUrl);
                attachCategory();
                $('.addItem').hide();


        }

        function enableItemSearching() {
            alert("@lang('categories.item_search_enabled')");
                var searchUrl = '{{ route('items.search') }}';
                searchingFor(searchUrl);
                attachItem();
                $('.addSub').hide();
        }

        function deleteItemFromCategory(item_id) {
            var category_id = {{ $category['id'] }};
            var url = '{{ route('categories.delete.item') }}';
            var token = '{{ csrf_token() }}';
            if (confirm('Are you sure you want to delete this Item ?')) {
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {item_id: item_id, category_id: category_id, _token :token},
                }).done(function() {
                    window.location.reload();
                }).fail(function(ex){
                    console.log(ex);
                });
            }
        }

        Sortable.create(itemsList, {
            animation: 150,
            ghostClass: "sortable-ghost",  // Class name for the drop placeholder
            chosenClass: "sortable-chosen",  // Class name for the chosen item
            dragClass: "sortable-drag",  // Class name for the dragging item
            scroll: true, // or HTMLElement
            scrollSensitivity: 30, // px, how near the mouse must be to an edge to start scrolling.
            scrollSpeed: 10, // px

            onEnd: function (/**Event*/evt) {
                var item_id = $('#idDragged').val();
                var new_sequence = 0;
                $(".itemInCtg").each(function(i) {
                    $(this).find(".itemNumber").text(++i);
                    var product_id = $(this).attr('data-id');
                    if (product_id == item_id) {
                        new_sequence = i;
                    }
                    $(this).attr("onmousedown", "setOldSequence(" + product_id + ", " + i + ")");
                });
                var old_sequence = $('#oldSequence').val();

                var url = '{{ route('categories.reorder.items') }}';
                var token = '{{ csrf_token() }}';
                var category_id = '{{ $category['id'] }}';
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {category_id: category_id, new_sequence: new_sequence, old_sequence: old_sequence, _token: token},
                }).done(function(res) {
                    //window.location.reload();
                    console.log(res);
                }).fail(function(ex){
                    console.log(ex);
                });
            }
        });

        function setOldSequence(id, order) {
            $('#oldSequence').val(order);
            $('#idDragged').val(id);

        }

        function add_printer_input()
        {
            printers_index = $('#printers_list input').length / 2;
            input_template = `<li class="list-group-item">
                                <div>
                                    <input type="text" name="printers[${printers_index}][name]" placeholder="printer name" class="form-control">
                                    <input type="text" name="printers[${printers_index}][unique_id]" placeholder="printer id" class="form-control">
                                </div>
                            </li>`;

            $('#printers_list').append($(input_template));
        }

        function submitPrinterForm() {
            $('#printer_form').submit();
        }

        function removePrinter(e) {

            clickedElement = $(e.target);
            printer_id = clickedElement.closest('.item_container').find('.printer_id').text();
            input_template = `<input type="hidden" name="removed_printers[]" value="${printer_id}" />`;
            $('#printer_form').append($(input_template));
            clickedElement.closest('li').remove();


        }

        function toggle_printer_div() {
            $('#attach_printer_div').toggle();
        }

        function attach_printer() {
            printer_id = $('#attach_printer_input').val();
            url = "{!! route('category.attach.printer') !!}";
            token = "{!! csrf_token() !!}";
            category_id = {!! $category["id"] !!}
            $.ajax({
                url: url,
                type: 'POST',
                dataType: 'json',
                data: {printer_id: printer_id,category_id : category_id,_token : token,allow_request: true},
            })
                .done(function() {
                    alert('addedd successfully');
                    location.reload();
                })
                .fail(function() {
                    alert('printer not found !!!!');
                    location.reload();
                })

        }
    </script>


@endsection
