<?php //dd($categories); ?>
@extends('layouts.master')


@section('title','UPOS | Categories')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">@lang('categories.customize_groups')</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item active">@lang('category')</li>
@endsection
@section('page-name','Categories')

@section('content')
@include('partials.navbar')
@include('partials.sidebar')

    <style>
        .ctg , .newCtg{
            padding: 1.5rem 1rem 2rem 1rem;
            margin-top: 1rem;
            border: none;
        }

        .ctg h3 , .newCtg h3 {
            margin: 0;
        }

        .ctg .color {
            position: absolute;
            bottom: 0;
            color: #fff;
            width: 100%;
            left: 0;
            padding: 2px 10px;
        }

        .ctg i {
            position: absolute;
            top: 6px;
            right: 8px;
            font-size: 26px;
            color: #ddd;
        }

        .newCtgIc{
            color: #ddd;
            position: absolute;
            bottom: 0;
            left: 0px;
            padding: 10px;
            font-size: 60px;
        }

        .customizeGroupBtn {
            margin: 5px;
        }

        .customizeGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .itemGroup-list i {
            float: right;
            padding: 4px;
            color: #dc3545;
        }

    </style>


<div class="contents" id="allCtgs">

    <div class="row">
        @forelse($categories as $category)
        <div class="col-lg-3 text-center">
            <div class="card ctg">
                <div class="card-body">
                    <a href="{{ route('categories.edit',$category["id"]) }}"><i class="fas fa-pen-square editCtg"></i></a>

                    <a href="{{ route('categories.show',$category["id"]) }}"><h3>{{ $category["en_name"] }}</h3></a>

                    <div class="color text-left" style="background-color: {{ $category["category_color"] }}">
                        @if($category["subCategories_count"] == 0)
                            <small><span class="font-weight-bold">{{ $category["products_count"] }}</span> @lang('categories.item')</small>
                        @endif

                        @if($category["products_count"] == 0)
                            <small><span class="font-weight-bold">{{ $category["subCategories_count"] }}</span> @lang('categories.subcategories')</small>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        @empty
        @endforelse
        <div class="col-lg-3 text-center">
            <div class="card newCtg">
                <div class="card-body">

                    <h3 class="text-muted"> @lang('categories.new_category') </h3>
                    <a href="{{ route('categories.create') }}" target="_blank"><i class="fas fa-plus newCtgIc"></i></a>

                </div>
            </div>
        </div>

    </div>

</div>

@endsection
