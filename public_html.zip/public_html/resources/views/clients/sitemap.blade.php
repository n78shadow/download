@extends('layouts.master')

@section('title','UPOS | Sitemap')

@section('content')
<style>
            #dark , #component , #light  {
                display: none;
            }

            body {
                font-family: 'Ropa Sans', sans-serif !important;
                background-color: #f5f5f5;
            }


            .visible {
                display: block !important;
            }
        </style>

<div class="container" style="margin-top: 2rem">

<h1 class="d-inline-block"><i class="fas fa-sitemap"></i> Vently POS Standard Version 2.0 | Site Map </h1>
<!-- Large button groups (default and split) -->
<div class="btn-group float-right">
    <button class="btn btn-dark btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span id="themeName"> Light Theme </span>
    </button>
    <div class="dropdown-menu">
        <a class="dropdown-item" id="lightTheme" href="#">Light</a>
        <a class="dropdown-item disabled" id="darkTheme" href="#">Dark</a>
        <a class="dropdown-item" id="components" href="#">Components</a>
    </div>
</div>

<div id="light" class="visible">

    <div class="row" style="margin-top: 2rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('clients.dashboard') }}" role="button" target="_blank">Dashboard</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark disabled " href="{{ route('clients.pos') }}" role="button" target="_blank" >POS</a>
        </div>

    </div>

    <div class="row" style="margin-top: 1rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('categories.index') }}" role="button" target="_blank">Categories</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('items.index') }}" role="button" target="_blank">Items</a>
        </div>

    </div>

    <div class="row" style="margin-top: 1rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('clients.supervisor') }}" role="button" target="_blank">Supervisor</a>
        </div>

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('clients.preperation') }}" role="button" target="_blank">Preperation</a>
        </div>

    </div>
    <div class="row" style="margin-top: 1rem">


        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('customizes.index') }}" role="button" target="_blank">Customize Group</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('tastingCategories.index') }}" role="button" target="_blank">Tasting</a>
        </div>


    </div>
    <div class="row" style="margin-top: 1rem">
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('users.index') }}" role="button" target="_blank">Users</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('roles.index') }}" role="button" target="_blank">Roles & Permissions</a>
        </div>
    </div>
    <div class="row" style="margin-top: 1rem">
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('reports.index') }}" role="button" target="_blank">Reports</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('printers.index') }}" role="button" target="_blank">Printers</a>
        </div>
    </div>
    <div class="row" style="margin-top: 1rem">
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('punch') }}" role="button" target="_blank">Punch</a>
        </div>
        <!--div class="col-lg-6">
            <a class="btn btn-lg btn-block btn-dark" href="{{ route('printers.index') }}" role="button" target="_blank">Printers</a>
        </div-->
    </div>
</div>
<div id="dark">

    <div class="row" style="margin-top: 2rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="index.php" role="button" target="_blank">Dashboard</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="pos.php" role="button" target="_blank">POS</a>
        </div>

    </div>

    <div class="row" style="margin-top: 1rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="index.php" role="button" target="_blank">Categories</a>

        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="pos.php" role="button" target="_blank">Items</a>
        </div>

    </div>

    <div class="row" style="margin-top: 1rem">

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="preperation.php" role="button" target="_blank">Preparation</a>
        </div>

        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="cg.php" role="button" target="_blank">Customize Group</a>
        </div>

    </div>

</div>
<div id="component">

    <div class="row" style="margin-top: 2rem">
        <div class="col-lg-12">
            <h3>Main</h3>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block disabled" href="components/navs.php" role="button" target="_blank">Navs</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block" href="components/loader.php" role="button" target="_blank">Loader</a>
        </div>
    </div>
    <div class="row" style="margin-top: 2rem">
        <div class="col-lg-12">
            <h3>POS</h3>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block" href="components/categories.php" role="button" target="_blank">Categories</a>
            <a class="btn btn-lg btn-block" href="components/bills.php" role="button" target="_blank">Bills</a>
        </div>
        <div class="col-lg-6">
            <a class="btn btn-lg btn-block" href="components/invoice.php" role="button" target="_blank">Invoice</a>
        </div>
    </div>

</div>

</div>



@endsection