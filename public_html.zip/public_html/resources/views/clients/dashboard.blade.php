@extends('layouts.master')

@section('title','UPOS | dashboard')

@section('content')

@include('partials.navbar')

<style>

    body {
        background-color: #fff !important;
    }

    .contents {
        margin: 2rem !important;
    }

    .topNav {
        padding: 0.5rem 2rem;
        background-color: #323232;
    }

    /* Side navbar Design */
    /* The sidebar menu */
    .sidenav {
        height: 100%; /* Full-height: remove this if you want "auto" height */
        width: 400px; /* Set the width of the sidebar */
        position: fixed; /* Fixed Sidebar (stay in place on scroll) */
        z-index: 1; /* Stay on top */
        top: 0; /* Stay at the top */
        right: 0;
        background-color: #323232; /* Black */
        overflow-x: hidden; /* Disable horizontal scroll */
        padding: 4rem 1rem 1rem 1rem;
    }


    /* Style page content */
    .main {
        margin-right: 400px; /* Same as the width of the sidebar */
    }

    /* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
    @media screen and (max-height: 450px) {
        .sidenav {padding-top: 15px;}
        .sidenav a {font-size: 18px;}
    }

    #time {
        text-align: center;
        color: white;
        font-family: "Lato", sans-serif;
        font-size: 2em;
    }

    /* main buttons style */
    .dashboard-btn  {
        position: relative;
        margin-bottom: 1rem;
        padding: 1.2rem 1rem;
    }

    .dashboard-btn .icon {
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
    }

    .dashboard-btn .icon:after {
        content: '\f101';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        position: absolute;
        opacity: 0;
        top: 0;
        right: -20px;
        transition: 0.5s;
    }

    .dashboard-btn:hover .icon {
        padding-right: 25px;
    }

    .dashboard-btn:hover .icon:after {
        opacity: 1;
        right: 0;
    }

    .dashboard-btn .btn-color {
        width : 8px ;
        height : 100% ;
        position: absolute;
        left: 0;
        top: 0;
        border-radius: .25rem 0 0 .2rem;
    }

</style>

<!-- Side navigation -->
<div class="sidenav">

    <h3 class="text-white">{{ $user->first_name . ' ' . $user->last_name }} <span class="badge badge-secondary float-right" style="font-size: 1rem">{{ $user->job }}</span></h3>
    <div class="container">
        <p id="time"></p>
    </div>

    <hr class="bg-white">
    <div class="btn-group w-100" role="group" aria-label="Basic example">
        <button type="button" class="btn btn-secondary w-50"><i class="fas fa-cog"></i></button>
        <button type="button" class="btn btn-secondary w-25"><i class="fas fa-sync-alt"></i></button>
        <button type="button" class="btn btn-secondary w-25" onclick="SubmitForm('forms_logout')"><i class="fas fa-sign-out-alt"></i></button>
    </div>
    <!--
        <hr class="bg-white">
        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>

        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>

        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>

        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>

        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>

        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" data-autohide="false">
            <div class="toast-header">
                <img src="..." class="rounded mr-2" alt="...">
                <strong class="mr-auto">Bootstrap</strong>
                <small>11 mins ago</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body">
                Hello, world! This is a toast message.
            </div>
        </div>
        -->
</div>

<!-- Page content -->
<div class="main">
    <div class="contents">

        <div class="row">

            <div class="col-12">
                <h1> {{ $branch_name }}</h1>
            </div>

            <div class="col-4">
                <button type="button" class="btn btn-lg btn-block btn-light dashboard-btn disabled"><span class="icon">POS</span> <span class="btn-color" style="background-color: #263238"></span> </button>
            </div>
            <div class="col-4">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('supervisor') ? route('clients.supervisor') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('supervisor') ? '' : 'disabled' }}"><span class="icon">@lang('general.supervisor')</span> <span class="btn-color" style="background-color: #263238"></span></button>
            </div>

            <div class="col-4">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('kitchen') ? route('clients.preperation') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('preperation') ? '' : 'disabled' }}"><span class="icon">@lang('general.preparation')</span> <span class="btn-color" style="background-color: #263238"></span></button>
            </div>
            <div class="w-100" style="margin-bottom: 1rem">
                <hr>
            </div>
            <div class="col-6">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('items_admin') ? route('items.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('items_admin') ? '' : 'disabled' }}"><span class="icon">@lang('general.items')</span> <span class="btn-color" style="background-color: #37474f"></span></button>
            </div>

            <div class="col-6">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('category_admin') ? route('categories.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('category_admin') ? '' : 'disabled' }}"><span class="icon">@lang('general.categories')</span> <span class="btn-color" style="background-color: #37474f"></span></button>
            </div>
            <div class="w-100" style="margin-bottom: 1rem">
                <hr>
            </div>

            <div class="col-3">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('reports') ? route('reports.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('reports') ? '' : 'disabled' }}"><span class="icon">@lang('general.reports')</span> <span class="btn-color" style="background-color: #455a64"></span> </button>
            </div>

            <div class="col-3">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('punch') ? route('punch') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('punch') ? '' : 'disabled' }}"><span class="icon">@lang('general.punch') @lang('general.in') \ @lang('general.out')</span> <span class="btn-color" style="background-color: #455a64"></span></button>
            </div>

            <div class="col-3">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('users_admin') ? route('users.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('users_admin') ? '' : 'disabled' }}"><span class="icon">@lang('general.employees')</span> <span class="btn-color" style="background-color: #455a64"></span></button>
            </div>

            <div class="col-3">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('users_admin') ? route('roles.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('users_admin') ? '' : 'disabled' }}"><span class="icon">@lang('general.roles')</span> <span class="btn-color" style="background-color: #455a64"></span></button>
            </div>

            <div class="w-100" style="margin-bottom: 1rem">
                <hr>
            </div>

            <div class="col-4">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('items_admin') ? route('customizes.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('items_admin') ? '' : 'disabled' }}"><span class="btn-color" style="background-color: #455a64"></span>@lang('general.customize_group')</button>
            </div>

            <div class="col-4">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('tasting_admin') ? route('tastingCategories.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('tasting_admin') ? '' : 'disabled' }}"><span class="btn-color" style="background-color: #455a64"></span>@lang('general.tastings')</button>
            </div>

            <div class="col-4">
                <button type="button" onclick="return window.location.href = '{{ Auth::user()->canDo('printers') ? route('printers.index') : '#' }}'" class="btn btn-lg btn-block btn-light dashboard-btn {{ Auth::user()->canDo('printers') ? '' : 'disabled' }}"><span class="btn-color" style="background-color: #455a64"></span>@lang('general.printers')</button>
            </div>

        </div>

    </div>
</div>


@endsection

@section('extra-js')

    <!--\\ categories Function \\-->

    <script>
        $(document).ready(function(){
            $('.toast').toast('show');
            //alert(1);
        });

    </script>

    <!-- function for invoice type in Details & Edit -->
    <script>
        $(document).on("click", ".editCtg",function() {
            $("#allCtgs").hide();
            $("#ctg-new").removeClass("display-block");
            $("#ctg-edit").addClass("display-block");
        });

        $(document).on("click", ".saveCtgInfo , .cancelCtgEdit",function() {
            $("#allCtgs").show();
            $("#ctg-edit").removeClass("display-block");
            $("#ctg-new").removeClass("display-block");
        });

        $(document).on("click", ".newCtg",function() {
            $("#allCtgs").hide();
            $("#ctg-edit").removeClass("display-block");
            $("#ctg-new").addClass("display-block");
        });

    </script>

    <script>
        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <script>
        //inline times for pickup in delivery situation
        $('.startCtg').pickatime({
            clear: '',
            interval: 30,
        });

        $('.endCtg').pickatime({
            clear: '',
            interval: 30,
        });
    </script>

    <!-- Edit Ctg -->
    <script>
        function limitTimeValue() {
            if($('#limitTimeForThisCategory').is(":checked")) {
                //alert(1);
                $("#showPickTimeToLimitCategoryTime").addClass("display-block");
            }
            else {
                $("#showPickTimeToLimitCategoryTime").removeClass("display-block");
            }
        }
    </script>

    <!-- Add Customize Group -->
    <script>
        $(".allCustomizeGroup a").click(function(){
            var customizegroupName = $(this).data("cg-name") ;
            $(this).parents().find(".customizeGroupForThisCategory").append('<a class="btn btn-light customizeGroupBtn" href="#" role="button"> '+customizegroupName+' <i class="fas fa-times-circle"></i></a>');
        })
    </script>

    <!-- Remove Customize Group -->
    <script>
        $(document).on('click', '.customizeGroupBtn .fa-times-circle', function(){
            $(this).parent().remove();
            Toastify({
                text: " Customize Group <span class='font-weight-bold'> Removed </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        })
    </script>

    <!-- Disable Or Inable Customize Group In Item Group -->
    <script>
        $(".customizeGroupBtnInIG > span").click(function(){
            $(this).parent().toggleClass("line-through-delete");
            $(this).find(".fa-trash-alt").toggleClass("display-hidden");
            $(this).find(".fa-undo-alt").toggleClass("display-hidden");
        });
    </script>

    <!-- Add filter -->
    <script>
        //add Filter in Edit Ctg
        $(".addItemGroupInNewCtg").click(function(){
            //$(this).parent().remove();
            var itemGroupInputValue = $(".addNewItemGroupInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(itemGroupInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> Error - </span> You Can't Add Empty Filter",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parent().find(".itemGroup-list").append('<a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#itemGroup"> '+itemGroupInputValue+' <i class="fas fa-times-circle"></i></a>');
                $(".addNewItemGroupInput").val("");
                Toastify({
                    text: " <span class='font-weight-bold'> " + itemGroupInputValue + "</span> Filter , Added Successfully To This Category",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#218838"
                }).showToast();
            }
        });

        //add Filter in new Ctg
        $(".addItemGroup").click(function(){
            //$(this).parent().remove();
            var itemGroupInputValue = $(".addItemGroupInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(itemGroupInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> Error - </span> You Can't Add Empty Filter",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parent().find(".itemGroup-list").append('<a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#itemGroup"> '+itemGroupInputValue+' <i class="fas fa-times-circle"></i></a>');
                $(".addItemGroupInput").val("");
                Toastify({
                    text: " <span class='font-weight-bold'> " + itemGroupInputValue + "</span> Item Group , Added Successfully To This Category",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#218838"
                }).showToast();
            }
        });

        //remove Filter After Add
        $(document).on('click', '.itemGroup-list i', function(e){
            e.stopPropagation();
            $(this).parent().remove();
            Toastify({
                text: " Item Group <span class='font-weight-bold'> Removed </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        });
    </script>

    <!-- Check if customize group empty -->
    <script>
        if ( $('#CGForNewCtg').length > 0 ) {
            //alert(1);
            $('#emptyCTGG').removeClass("display-block");
        }else{
            //alert(0);
            $('#emptyCTGG').addClass("display-block");
        }
    </script>
    <script>
        $(document).ready(function(){
            $('.toast').toast('show');
            //alert(1);
        });

    </script>

    <script>
        const MONTHS = {
            0: 'Jan',
            1: 'Feb',
            2: 'Mar',
            3: 'Apr',
            4: 'May',
            5: 'Jun',
            6: 'Jul',
            7: 'Aug',
            8: 'Sep',
            9: 'Oct',
            10: 'Nov',
            11: 'Dec'
        };
        let showTime = true;

        function addZero(val) {
            return val < 10 ? '0' + val : val;
        }

        function refresh() {
            let now = new Date();
            if (showTime) {
                let time = [now.getHours(), now.getMinutes(), now.getSeconds()];
                time.forEach(function(val, index, arr) {
                    arr[index] = addZero(val);
                });

                let time_str = time.join(":");
                document.title = time_str;
                document.getElementById('time').innerHTML = time_str;
            } else {
                let date = [addZero(now.getDay()), MONTHS[now.getMonth()], now.getFullYear().toString().slice(2, 4)];
                let date_str = date.join(" ");
                document.title = date_str;
                document.getElementById('time').innerHTML = date_str;
            }
        }

        refresh();
        setInterval(refresh, 1000);

        document.getElementById('time').addEventListener('click', function() {
            showTime = !showTime;
            refresh();
        });

        function SubmitForm(id) {
            $('#' + id).submit();
        }
    </script>
@endsection
