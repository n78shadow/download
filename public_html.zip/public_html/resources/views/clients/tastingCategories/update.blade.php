<?php //dd($customizes); ?>
@extends('layouts.master')

@section('title','UPOS | create new Tasting category')

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('tastingCategories.index') }}">Tasting</a></li>
<li class="breadcrumb-item active">Update Tasting</li>
@endsection

@section('extra-styles')
    <style>
        .newCtgIc{
            color: #ddd;
            position: absolute;
            bottom: 0;
            left: 0px;
            padding: 10px;
            font-size: 60px;
        }
    </style>
@endsection

@section('content')

    @include('partials.navbar')
    @include('partials.sidebar')

    <div class="contents" id="ctg-new">
        <form action="{{ route('tastingCategories.update',$category["id"]) }}" method="POST" id="forms_CreateCategory">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="col-lg-9">

                    <div class="row">
                        <div class="col">
                            <button type="submit" class="btn btn-primary saveCtgInfo noBorderRadius">Save</button>
                            <button type="reset" class="btn btn-danger cancelCtgEdit noBorderRadius">Cancel</button>
                        </div>
                        <div class="col text-right">
                            <div class="form-group noMargin">
                          <span class="switch switch-sm">
                            <input type="checkbox" class="switch" id="switch-sm" name="status"  data-on="primary" data-off="info" checked>
                            <label for="switch-sm">Active</label>
                          </span>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 1rem">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg noBorderRadius {{ $errors->has('en_name') ? 'is-invalid' : '' }}" type="text" name="en_name" placeholder="En Category Name" value="{{ $category['en_name'] }}">
                                    @if ($errors->has('en_name'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('en_name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg noBorderRadius {{ $errors->has('fr_name') ? 'is-invalid' : '' }}" type="text" name="fr_name" placeholder="Fr Category Name" value="{{ $category['fr_name'] }}">
                                    @if ($errors->has('fr_name'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('fr_name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg noBorderRadius {{ $errors->has('cost') ? 'is-invalid' : '' }}" type="text" name="cost" placeholder="cost" value="{{ $category['cost'] }}">
                                    @if ($errors->has('cost'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('cost') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="col-lg-3">
                                    <input class="form-control form-control-lg noBorderRadius {{ $errors->has('price') ? 'is-invalid' : '' }}" type="text" name="price" placeholder="price" value="{{ $category['price'] }}">
                                    @if ($errors->has('price'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="row" style="margin-top: 1rem">
                                <div class="col-lg-6">
                                    <div class="row">
                                        <div class="col">
                                            <input class="form-control form-control-lg noBorderRadius d-inline-block " type="text" placeholder="Printer ID" readonly >
                                            @if ($errors->has('fr_name'))
                                                <span class="invalid-feedback">
                                        <strong>{{ $errors->first('fr_name') }}</strong>
                                    </span>
                                            @endif
                                        </div>
                                        <div class="col text-right">
                                            <div class="dropdown d-inline-block">
                                                <button class="btn btn-secondary noBorderRadius dropdown-toggle btn-lg disabled" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    ERP Warehouse
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item" href="#">Action</a>
                                                    <a class="dropdown-item" href="#">Another action</a>
                                                    <a class="dropdown-item" href="#">Something else here</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">

                                    <div class="row">
                                        <div class="col">
                                            <div class="input-group input-group-lg">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text noBorderRadius text-white border-0" style="background-color: #546e7a" data-toggle="modal" data-target="#colors"><i class="fas fa-palette"></i></div>
                                                </div>
                                                <input type="text" class="form-control noBorderRadius border-0" id="" value="{{ $category['color'] }}" placeholder="#3e3e3e" name="color">
                                            </div>
                                        </div>
                                        <div class="col text-right">
                                            <button type="button" class="btn btn-light noBorderRadius btn-lg">Reset Color</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="row" style="margin-top: 1rem">

                                <div class="col-lg-12">
                                    <div class="custom-control custom-checkbox mr-sm-2">
                                        <input type="checkbox" class="custom-control-input" id="limitTimeForThisCategory" onchange="limitTimeValue(event)">
                                        <label class="custom-control-label" for="limitTimeForThisCategory">Limit Time For This Category ?</label>
                                    </div>
                                </div>
                                <div class="col-lg-12" style="margin-top: 1rem">
                                    <div data-picktime="limitTimeForThisCategory" hidden>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <input class="form-control form-control-lg noBorderRadius startCtg" type="text" placeholder="Start From">
                                            </div>

                                            <div class="col-lg-6">
                                                <input class="form-control form-control-lg noBorderRadius endCtg" type="text" placeholder="End ..">
                                            </div>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 1rem">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h4>Customize Group</h4>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>

                </div>
            </div>
        </form>

    </div>


    <!-- Color Picker Modal -->


    <div class="modal fade" id="colors" tabindex="-1" role="dialog" aria-labelledby="colors" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background-color: transparent; width: max-content;">
                <div class="material-color-picker">
                    <div class="material-color-picker__left-panel">
                        <ol class="color-selector" data-bind="foreach: materialColors">
                            <li>
                                <input name="material-color" type="radio" data-bind="attr: { id: 'materialColor' + $index() }, checked: selectedColor, value: color">
                                <label data-bind="attr: { for: 'materialColor' + $index(), title: color }, style: { 'color': $data.variations[4].hex }"></label>
                            </li>
                        </ol>
                    </div>
                    <div class="material-color-picker__right-panel" data-bind="foreach: materialColors">
                        <div class="color-palette-wrapper" data-bind="css: { 'js-active': selectedColor() === color }">
                            <h2 class="color-palette-header" data-bind="text: color"></h2>
                            <ol class="color-palette" data-bind="foreach: variations">
                                <li id="clipboardItem" class="color-palette__item" data-bind="attr: { 'data-clipboard-text': hex }, style: { 'background-color': hex }">
                                    <span data-bind="text: weight"></span>
                                    <span data-bind="text: hex"></span>
                                    <span class="copied-indicator" data-bind="css: { 'js-copied': copiedHex() === hex }">Color copied!</span>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- End Color Picker -->

@endsection




@section('extra-js')
    <script>
        $(document).on("click", ".editCtg",function() {
            $("#allCtgs").hide();
            $("#ctg-new").removeClass("display-block");
            $("#ctg-edit").addClass("display-block");
        });

        $(document).on("click", ".saveCtgInfo , .cancelCtgEdit",function() {
            $("#allCtgs").show();
            $("#ctg-edit").removeClass("display-block");
            $("#ctg-new").removeClass("display-block");
        });

        $(document).on("click", ".newCtg",function() {
            $("#allCtgs").hide();
            $("#ctg-edit").removeClass("display-block");
            $("#ctg-new").addClass("display-block");
        });

    </script>

    <script>
        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <script>
        //inline times for pickup in delivery situation
        $('.startCtg').pickatime({
            clear: '',
            interval: 30,
        });

        $('.endCtg').pickatime({
            clear: '',
            interval: 30,
        });
    </script>

    <!-- Edit Ctg -->
    <script>
        function limitTimeValue() {
            if($('#limitTimeForThisCategory').is(":checked")) {
                //alert(1);
                $("#showPickTimeToLimitCategoryTime").addClass("display-block");
            }
            else {
                $("#showPickTimeToLimitCategoryTime").removeClass("display-block");
            }
        }
    </script>

    <!-- Add Customize Group -->
    <script>
        $(".allCustomizeGroup a").click(function(){
            var customizegroupName = $(this).data("cg-name") ;
            var customizegroupId = $(this).data("cg-id") ;
            $(this).parents().find(".customizeGroupForThisCategory").append(`<span><input name="customizes[]" type="hidden" value="${customizegroupId}" ><a class="btn btn-light customizeGroupBtn" href="#" role="button"> ${customizegroupName} <i class="fas fa-times-circle"></i></a><span>`);
        })
    </script>

    <!-- Remove Customize Group -->
    <script>
        $(document).on('click', '.customizeGroupBtn .fa-times-circle', function(){
            $(this).parent().closest('span').remove();
            Toastify({
                text: " Customize Group <span class='font-weight-bold'> Removed </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        })
    </script>

    <!-- Disable Or Inable Customize Group In Item Group -->
    <script>
        $(".customizeGroupBtnInIG > span").click(function(){
            $(this).parent().toggleClass("line-through-delete");
            $(this).find(".fa-trash-alt").toggleClass("display-hidden");
            $(this).find(".fa-undo-alt").toggleClass("display-hidden");
        });
    </script>

    <!-- Add filter -->
    <script>
        //add Filter in Edit Ctg
        $(".addItemGroupInNewCtg").click(function(){
            //$(this).parent().remove();
            var itemGroupInputValue = $(".addNewItemGroupInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(itemGroupInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> Error - </span> You Can't Add Empty Filter",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parent().find(".itemGroup-list").append('<a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#itemGroup"> '+itemGroupInputValue+' <i class="fas fa-times-circle"></i></a>');
                $(".addNewItemGroupInput").val("");
                Toastify({
                    text: " <span class='font-weight-bold'> " + itemGroupInputValue + "</span> Filter , Added Successfully To This Category",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#218838"
                }).showToast();
            }
        });

        //add Filter in new Ctg
        $(".addItemGroup").click(function(){
            //$(this).parent().remove();
            var itemGroupInputValue = $(".addItemGroupInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(itemGroupInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> Error - </span> You Can't Add Empty Filter",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parent().find(".itemGroup-list").append('<a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#itemGroup"> '+itemGroupInputValue+' <i class="fas fa-times-circle"></i></a>');
                $(".addItemGroupInput").val("");
                Toastify({
                    text: " <span class='font-weight-bold'> " + itemGroupInputValue + "</span> Item Group , Added Successfully To This Category",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#218838"
                }).showToast();
            }
        });

        //remove Filter After Add
        $(document).on('click', '.itemGroup-list i', function(e){
            e.stopPropagation();
            $(this).parent().remove();
            Toastify({
                text: " Item Group <span class='font-weight-bold'> Removed </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        });
    </script>

    <!-- Check if customize group empty -->
    <script>
        if ( $('#CGForNewCtg').length > 0 ) {
            //alert(1);
            $('#emptyCTGG').removeClass("display-block");
        }else{
            //alert(0);
            $('#emptyCTGG').addClass("display-block");
        }
    </script>

    <script>
        clipboard.on("success", function(el) {
            $("input[name='color']").val(el.text);

        });

    </script>


@endsection