<?php //dd($tastingCategory); ?>
@extends('layouts.master')


@section('title','UPOS | tasting Category')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection

@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection
@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('tastingCategories.index') }}">Tasting</a></li>
<li class="breadcrumb-item active">Tasting Details</li>
@endsection
@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>
        .editService {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #ccc;
        }

        .deleteService {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #bd2130;
        }

        .customizeItems a , #emptyCGItems a {
            margin: 2px  ;
        }

        .tastingItem {
            padding: .5rem ;
        }

        .tastingItem:hover {
            background-color: #eee;
            transition: 0.2s;
        }

        .tastingItem:hover .btn  {
            background-color: #fff;
            transition: 0.2s;
        }

        .kitchenDots .dot:after {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin: 2px;
            font-size: 12px;
        }

        .kitchens .btn {
            margin-top: 0.5rem;
            position: relative;
        }

        .kitchens .notSelected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #ccc;
        }

        .kitchens .selected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #28a745;
        }

        .replacementItem .btn {

            margin-top: 0.5rem;

        }

        .replacementItem .btn > .delete {

            margin: 0 4px 0 8px;
            color : #bd2130 ;

        }
    </style>

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">

        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">{{ $tastingCategory["en_name"] .' #' .$tastingCategory["id"] }} <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;" hidden>Add New Item</span></h3>
                    </div>
                    <div class="col text-right">
                        <!--
                        <button type="button" class="btn btn-light noBorderRadius" id="viewByGroup"><i class="fas fa-object-group"></i></button>
                        <button type="button" class="btn btn-light noBorderRadius" id="OrganizeItems"><i class="fas fa-arrows-alt"></i></button>
                        -->
                        <button type="button" class="btn btn-primary noBorderRadius border-0" style="background-color: #546e7a" data-toggle="modal" data-target="#addTastingItem">Add Item</button>
                        <!--<button type="button" class="btn btn-primary noBorderRadius border-0" style="background-color: #3e3e3e" onclick="CreateEmptyService({{ $tastingCategory["id"] }})">Create Service</button>-->

                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" hidden>Cancel</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" hidden>Add</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents">
        <div class="card-columns">
            @forelse($tastingCategory['services'] as $item)
                <div class="card">
                    <div class="card-body">
                        <h3 class="serviceNo">Service #{{ $item['service_number'] }}</h3>
                        <i class="fas fa-pen-square editService"></i>
                        <i class="fas fa-trash-alt deleteService" data-toggle="modal" data-target="#confirmDeleteModal" hidden></i>
                        @forelse($item['products'] as $prod)
                            <div class="tastingItem" data-toggle="modal" data-target="#updateTastingItem" onclick="getTastData('{{ route('tastingcategories.update.data', [$prod['unique_id'], $tastingCategory["id"]]) }}','{{ route('tastingcategories.get.data', $prod['unique_id']) }}', '{{ route('tastingcategories.update.replace', [$prod['unique_id'], $tastingCategory["id"]]) }}')">
                                <a class="btn btn-light" href="#" role="button">{{ $prod['product_name'] }}</a>
                                <span class="kitchenDots">
                                    @forelse($prod['categories'] as $category)
                                        <span class="dot" style="color: {{ $category['category_color'] }}"></span>
                                    @empty
                                    @endforelse
                                </span>
                                <span class="float-right text-muted">#{{ $prod['product_id'] }}</span>
                                <div class="w-100" id="replace{{ $prod['product_id'] }}">
                                @forelse($prod['replacements'] as $rep)
                                    <span class="badge badge-light">{{ $rep['product_name'] }}<span class="badge badge-light">#{{ $rep['product_id'] }}</span></span>
                                @empty
                                @endforelse
                                </div>
                            </div>
                            <hr>
                        @empty
                        @endforelse
                    </div>
                    <div class="actionBtnsService" hidden>
                        <div class="btn-group btn-block btn-group-sm" role="group">
                            <button type="button" class="btn btn-success w-50 noBorderRadius saveCG">Save</button>
                            <button type="button" class="btn btn-secondary w-50 noBorderRadius cancelEditCG">Cancel</button>
                        </div>
                    </div>
                </div>
            @empty
            @endforelse
        </div>
    </div>




    <!-- Modals -->
    <!-- Are You Sure Modal for remove Service -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content confirmDeleteItem">

            </div>
        </div>
    </div>

    <!-- Are You Sure Modal for remove Service -->
    <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-danger" id=""><i class="fas fa-exclamation-triangle"></i> Are You Sure </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class="text-muted">You Want To Delete This Customize Group ?</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-danger btn-lg">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add item to service  -->
    <div class="modal fade" id="addTastingItemOld" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Add Item</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- add Item Modal [Multi Step] -->
    <form class="modal multi-step" id="addTastingItem" method="post" action="{{ route('tastingcategories.add.basic', $tastingCategory['id']) }}">
        @csrf
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title step-1 step-2" data-step="1">Add Item</h4>
                </div>
                <div class="modal-body step-1" data-step="1">

                    <div class="row">
                        <div class="col-8">
                            <div class="input-group">
                                <select type="text" class="form-control itemsSelect" name="product_id" style="width: 200px!important; border: 1px solid #888!important;" placeholder="Add Tasting Item">
                                    @forelse($products as $row)
                                        <option value="{{ $row['id'] }}">{{ $row['en_name'] }} {{ $row['id'] }}</option>
                                    @empty
                                    @endforelse
                                </select>
                                <div class="input-group-append">
                                    <select class="btn btn-outline-secondary dropdown-toggle" name="service_number">
                                        <option value="1">#1</option>
                                        <option value="2">#2</option>
                                        <option value="3">#3</option>
                                        <option value="4">#4</option>
                                        <option value="5">#5</option>
                                        <option value="6">#6</option>
                                        <option value="7">#7</option>
                                        <option value="8">#8</option>
                                        <option value="9">#9</option>
                                        <option value="10">#10</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <?php //<a class="btn btn-primary step step-1" href="#" role="button" data-step="1" onclick="sendEvent('#addTastingItem', 2)">Add Replacement</a> ?>
                        </div>
                    </div>

                    <div class="row kitchens" style="margin-top: 1rem">
                        <div class="col-12">
                            <h4 class="text-muted">Kitchens</h4>
                        </div>
                        @forelse($categories as $row)
                            <div class="col">
                                <a class="btn  btn-light notSelected btn-block" href="#" onclick="setChecked(this, {{ $row['id'] }})" role="button"><input type="checkbox" style="display: none" name="categories_list[]" value="{{ $row['id'] }}" id="item{{ $row['id'] }}">{{ $row['en_name'] }} </a>
                            </div>
                        @empty
                        @endforelse



                    </div>
                    <?php /*
                    <hr>

                    <div class="row">
                        <div class="col-12 replacementItem" style="margin-top: 1rem">
                            <a class="btn btn-light btn-sm" href="#" role="button">item <span class="text-muted">- #4453 </span></a>
                            <a class="btn btn-light btn-sm" href="#" role="button">item <span class="text-muted">- #4453 </span></a>
                            <a class="btn btn-light btn-sm" href="#" role="button">item <span class="text-muted">- #4453 </span></a>
                            <a class="btn btn-light btn-sm" href="#" role="button">item <span class="text-muted">- #4453 </span></a>
                        </div>
                    </div> */ ?>
                </div>
                <?php /*
                <div class="modal-body step-2" data-step="2">

                    <div class="row">
                        <div class="col-12">
                            <ol class="breadcrumb step-2" data-step="2" style="background-color: transparent ; padding-left: 0">
                                <li class="breadcrumb-item " aria-current="page" onclick="sendEvent('#addTastingItem', 1)"><a>Item Name</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Replacement Item</li>
                            </ol>
                        </div>
                        <div class="col-8">
                            <input class="form-control" type="text" placeholder="Replacement Item Name">
                        </div>

                        <div class="col-4">
                            <button type="button" class="btn btn-primary btn-block"> Add Item </button>
                        </div>
                    </div>

                    <div class="row kitchens" style="margin-top: 1rem">
                        <div class="col-12">
                            <h4 class="text-muted">Kitchens</h4>
                        </div>

                        <div class="col">
                            <a class="btn  btn-light notSelected btn-block" href="#" role="button">Kitchen #1 </a>
                        </div>
                        <div class="col">
                            <a class="btn  btn-light notSelected btn-block" href="#" role="button">Kitchen #2 </a>
                        </div>
                        <div class="col">
                            <a class="btn  btn-light selected btn-block" href="#" role="button">Kitchen #3 </a>
                        </div>
                        <div class="col">
                            <a class="btn  btn-light notSelected btn-block" href="#" role="button">Kitchen #4 </a>
                        </div>
                        <div class="col">
                            <a class="btn  btn-light selected btn-block" href="#" role="button">Kitchen #5 </a>
                        </div>
                        <div class="col">
                            <a class="btn  btn-light notSelected btn-block" href="#" role="button">Kitchen #6 </a>
                        </div>



                    </div>

                    <hr>

                    <div class="col-12 replacementItem" style="margin-top: 1rem">
                        <a class="btn btn-light" href="#" role="button">item <span class="text-muted"> #4453 </span><span class="kitchenDots"><span class="dot" style="color: rgb(255, 171, 145)"></span><span class="dot" style="color: rgb(244, 81, 30)"></span><span class="dot" style="color: #717171"></span></span><span class="delete"><i class="fas fa-trash-alt"></i></span></a>
                        <a class="btn btn-light" href="#" role="button">item <span class="text-muted"> #4453 </span><span class="delete"><i class="fas fa-trash-alt"></i></span> </a>
                        <a class="btn btn-light" href="#" role="button">item <span class="text-muted"> #4453 </span><span class="kitchenDots"><span class="dot" style="color: rgb(255, 171, 145)"></span><span class="dot" style="color: rgb(244, 81, 30)"></span></span><span class="delete"><i class="fas fa-trash-alt"></i></span></a>
                        <a class="btn btn-light" href="#" role="button">item <span class="text-muted"> #4453 </span><span class="delete"><i class="fas fa-trash-alt"></i></span></a>
                    </div>

                </div>
                */ ?>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </div>
        </div>
    </form>


    <!-- Edit Data Modal -->
    <form class="modal multi-step" id="updateTastingItem" method="post" action="">
        @csrf
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="serviceNo prodName"></h3>
                    <i class="fas fa-trash-alt deleteService deleteTastingItem"></i>
                </div>
                <div class="modal-body step-1" data-step="1">

                    <div class="row">
                        <div class="col-12">
                            <ol class="breadcrumb step-2" data-step="2" style="background-color: transparent ; padding-left: 0">
                                <li class="breadcrumb-item " aria-current="page" onclick="sendEvent('#addTastingItem', 1)"><a>Item Name</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Replacement Item</li>
                            </ol>
                        </div>
                        <div class="col-8 replace_items">
                            <div class="input-group">
                                <label>Replace Item Name</label>
                                <select type="text" class="form-control itemsSelect" id="replacement_item" name="replacement_item" style="width: 200px!important; border: 1px solid #888!important;">';
                                    <option value=""></option>
                                </select>
                                <div class="input-group-append">
                                    <select class="btn btn-outline-secondary dropdown-toggle" id="uservice_number" name="uservice_number">
                                        <option value="1">#1</option>
                                        <option value="2">#2</option>
                                        <option value="3">#3</option>
                                        <option value="4">#4</option>
                                        <option value="5">#5</option>
                                        <option value="6">#6</option>
                                        <option value="7">#7</option>
                                        <option value="8">#8</option>
                                        <option value="9">#9</option>
                                        <option value="10">#10</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-4">
                            <label> </label>
                            <button type="button" class="btn btn-primary btn-block replacementButton"> Add Replace Item </button>
                        </div>
                    </div>

                    <div class="row kitchens updateKitchen" style="margin-top: 1rem">

                    </div>
                    <input type="hidden" name="isTastingReplace" id="isTastingReplace">
                    <hr>
                    <div class="col-12 replacementItem replacementItems" style="margin-top: 1rem"></div>
                </div>


                <div class="modal-footer">
                    <input type="submit" class="btn btn-primary saveBut" value="Save">
                </div>
            </div>
        </div>
    </form>
@endsection


@section('extra-js')

    <script src="{{ asset('assets/js/multi-step-modal.js') }}"></script>
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script>
        sendEvent = function(sel, step) {
            $(sel).trigger('next.m.' + step);
        }
    </script>

    <!--\\ CustomizeGroup Functions \\-->
    <script>
        $('.sideNav > a').tooltip() ;
        $('.item-qnt').tooltip();

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <script>
        //Open Edit mode in this customize group
        $(document).on('click', '.editService', function(){
            //disable edit in all CGs
            $(".editService").hide();
            //show Delete Icon To Delete This CG
            $(this).parent().find(".deleteService").addClass("display-block");
            //Add Delete Icon To All Items In This CG
            //$(this).parent().find(".customizeItems a").append('<span class="removeItemFromCG"><i class="fas fa-trash-alt"></i></span>');
            //Show Action Btns To Save Or Cancel CG
            $(this).parent().parent().find(".actionBtnsCG").addClass("display-block");
        });

        //Save CG And Close It
        $(document).on('click', '.saveCG , .cancelEditCG', function(){

            //ReEnable edit in all CGs
            $(".editCG").show();
            //get New CG Name From Input
            var newserviceNo = $(this).parent().parent().parent().find(".serviceNoInput").val() ;
            // Hide Input
            $(this).parent().parent().parent().find(".serviceNoInput").removeClass("display-block");
            //Retrive New Name & show It
            $(this).parent().parent().parent().find(".serviceNo").text(newserviceNo).show();

            //remove Delete Icon from CG
            $(this).parent().parent().parent().find(".deleteCG").removeClass("display-block");
            //remove remove Item from All items in this CG
            $(".removeItemFromCG").remove();

            //Hide Add Btn & Input in CG
            $(this).parents().find(".addNewItemToCG").removeClass("display-block");
            //hide Action Btns To Save Or Cancel CG
            $(this).parents().find(".actionBtnsCG").removeClass("display-block");

        });

    </script>

    <script>
        $(document).ready(function () {
            /* $('.itemsSelect').select2({
                theme: "bootstrap",
                placeholder: "type item name ..."
            }); */
        });

        function setChecked(ele, id) {
            var itemClass = $(ele).attr('class');
            if (itemClass.search('notSelected') != -1) {
                $('#item' + id).attr("checked", "checked");
                $(ele).removeClass('notSelected').addClass('selected');
            } else {
                $('#item' + id).removeAttr('checked');
                $(ele).removeClass('selected').addClass('notSelected');
            }
        }

        function setCheckedU(ele, id) {
            var itemClass = $(ele).attr('class');
            if (itemClass.search('notSelected') != -1) {
                $('#uitem' + id).attr("checked", "checked");
                $(ele).removeClass('notSelected').addClass('selected');
            } else {
                $('#uitem' + id).removeAttr('checked');
                $(ele).removeClass('selected').addClass('notSelected');
            }
        }

        function getTastData (targetUrl, getUrl, replaceUrl) {
            $('#isTastingReplace').val(0);
            $('.replacementButton').attr("onclick", "addTastingReplace('" + replaceUrl + "')");
            //var targetArr = targetUrl.split('/');
            //targetArr[6] = id;
            //targetUrl = targetArr.join('/');
            $('#updateTastingItem').attr('action', targetUrl);
            //var tasting_id = id;
            var token = '{{ csrf_token() }}';

            $.ajax({
                url: getUrl,
                type: 'get',
                dataType: 'json',
                //data: {"tasting_id": tasting_id},
            }).done(function(data) {
                $('.prodName').html(data.product.en_name);
                var replacement_list = data.replacment_list;
                var html = '';
                var categories_list = data.categories_list;
                $("#uservice_number").val(data.service_number);
                $('.deleteTastingItem').attr("onclick",  "deleteTastingItem("+data.id+", " + data.product_id + ")");
                html = '';
                html += '<div class="col-12">';
                html += '<h4 class="text-muted">Kitchens</h4>';
                html += '</div>';
                @forelse($categories as $row)
                    var checked = '';
                    var selected = 'notSelected';
                    for (var s=0; s<categories_list.length; s++) {
                        if (categories_list[s].id == {{ $row['id'] }}) {
                            selected = 'selected';
                            checked = 'checked="checked"';
                        }
                    }
                    html += '<div class="col">';
                    html += '<a class="btn  btn-light ' + selected + ' btn-block" href="#" onclick="setCheckedU(this, {{ $row['id'] }})" role="button">';
                    html += '<input type="checkbox" ' + checked + ' style="display: none" class="categoriesList" name="ucategories_list[]" value="{{ $row['id'] }}" id="uitem{{ $row['id'] }}">{{ $row['en_name'] }}';
                    html += '</a>';
                    html += '</div>'
                @empty
                @endforelse
                $('.updateKitchen').html(html);

                html = '';
                for (var s=0; s<replacement_list.length; s++) {
                    html += '<a class="btn btn-light" href="#" role="button">';
                    html += replacement_list[s].product_name + '<span class="text-muted"> #' + replacement_list[s].id + ' </span>';
                    html += '<span class="kitchenDots">';
                    var categories_list = replacement_list[s].categories_list;
                    for (var i=0; i < categories_list.length; i++) {
                        html += '<span class="dot" style="color: '+categories_list[i].category_color+'"></span>';
                    }
                    html += '</span>';
                    html += '<span class="delete"><i class="fas fa-trash-alt" onclick="deleteTastingItem(' + replacement_list[s].id + ', ' + data.product_id + ')"></i></span>';
                    html += '</a>';
                }
                $('.replacementItems').html(html);
            }).fail(function(err) {
                console.log(err.responseText);
            })
        }

        function addTastingReplace(url) {
            $('#updateTastingItem').attr('action', url);
            var token = '{{ csrf_token() }}';
            var categoriesList = [];
            //updateKitchen
            var i = 0;
            $('.categoriesList').each(function () {
                if (this.checked) {
                    categoriesList[i] = $(this).val();
                    i++;
                }
            });
            $('.saveBut').hide();
            $.ajax({
                url: url,
                type: 'post',
                data: {replacement_item: $('#replacement_item').val(), categories_list: categoriesList, _token :token},
                dataType: 'json',
            }).done(function(data) {
                var replacement_list = data.replacment_list;
                var product_id = data.product_id;
                var html = '';
                var replace_html = "";
                for (var s = 0; s < replacement_list.length; s++) {
                    html += '<a class="btn btn-light" href="#" role="button">';
                    html += replacement_list[s].product_name + '<span class="text-muted"> #' + replacement_list[s].id + ' </span>';
                    html += '<span class="kitchenDots">';
                    var categories_list = replacement_list[s].categories_list;
                    for (var i=0; i < categories_list.length; i++) {
                        html += '<span class="dot" style="color: '+categories_list[i].category_color+'"></span>';
                    }
                    html += '</span>';
                    html += '<span class="delete"><i class="fas fa-trash-alt" onclick="deleteTastingItem(' + replacement_list[s].id + ', ' + data.product_id + ')"></i></span>';
                    html += '</a>';

                    replace_html += '<span class="badge badge-light">' + replacement_list[s].product_name + ' <span class="text-muted"> #' + replacement_list[s].id + ' </span></span>';
                }
                $('.replacementItems').html(html);
                $('#replace' + product_id).html(replace_html);
                $('.saveBut').show();
            }).fail(function(ex){
                console.log(ex);
            });
            //$('#updateTastingItem').submit();
        }

        function deleteTastingItem(id, product_id) {
            var url = '{{ route('tastingcategories.delete.item') }}';
            var token = '{{ csrf_token() }}';
            var tasting_id = '{{ $tastingCategory["id"] }}';
            if (confirm('Are you sure you want to delete this Item ?')) {
                $('.saveBut').hide();
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {id: id, tasting_id: tasting_id, product_id: product_id, _token :token},
                }).done(function() {
                    window.location.reload();
                }).fail(function(ex){
                    console.log(ex);
                });
            }
        }

        function deleteTastingReplace(product_id, replacement_id) {
            var url = '{{ route('tastingcategories.delete.replace') }}';
            var token = '{{ csrf_token() }}';
            var tasting_id = '{{ $tastingCategory["id"] }}';
            if (confirm('Are you sure you want to delete this Item ?')) {
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {tasting_id: tasting_id, product_id: product_id, replacement_id: replacement_id, _token :token},
                }).done(function() {
                    window.location.reload();
                }).fail(function(ex){
                    console.log(ex);
                });
            }
        }

        function searchingFor()
        {
            var url = '{{ route('items.search') }}';
            if(url == '')
            {
                return;
            }
            $('.itemsSelect').select2({
                placeholder: "type any word to find ...",
                minimumInputLength: 2,
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor();

    </script>
@endsection