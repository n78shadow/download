<?php //dd($customizes); ?>
@extends('layouts.master')


@section('title','UPOS | Customizes')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#"  data-toggle="modal" data-target="#addCG">@lang('customizes.new_customize_groups')</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item active">Customize Groups</li>
@endsection

@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>
        .editCG {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #ccc;
        }

        .deleteCG {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #bd2130;
        }

        .customizeItems a , #emptyCGItems a {
            margin: 2px  ;
        }

        .removeItemFromCG {
            color: #bd2130;
            margin-left: 4px;
        }

        .CGNameInput { width: 82%}
    </style>

    <div class="contents">
        <div class="card-columns">
            @forelse($customizes as $customize)
                <form id="addItemToCG{{ $customize['id'] }}" method="post" action="{{ route('customizes.update', $customize['id']) }}">
                    @csrf
                    @method('PUT')
                    <div class="card">
                        <div class="card-body">
                            <h3 class="CGName">{{ $customize["group_name"] }}</h3>
                            <input class="form-control CGNameInput" type="text" name="group_name" value="" hidden>
                            <i class="fas fa-pen-square editCG"></i>
                            <a onclick="deleteCG({{ $customize["id"] }})">
                                <i class="fas fa-trash-alt deleteCG" hidden></i>
                            </a>
                            <hr>
                            <div class="customizeItems">
                                @forelse($customize["items"] as $item)
                                    <a class="btn btn-light btn-sm" id="removeItemFromCG{{ $item["id"] }}" href="#" role="button">{{ $item["custom_name"] }} <span class="removeItemFromCG" style="display: none" onclick="RemoveItemFromCG({{ $item["id"] }})"><i class="fas fa-trash-alt"></i></span></a>
                                @empty
                                    <a class="btn btn-light btn-sm" href="#" role="button">@lang('customizes.want_add_item')</a>
                                @endforelse
                            </div>
                            <div class="addNewItemToCG" style="margin-top: 1rem"  hidden>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-9">
                                        <input class="form-control form-control-sm addItemToCGInput" type="text" placeholder="@lang('customizes.item_name')">
                                    </div>
                                    <div class="col-lg-3">
                                        <button type="button" class="btn btn-primary btn-sm btn-block addItemToCG">@lang('customizes.add')</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="actionBtnsCG" hidden>
                            <div class="btn-group btn-block btn-group-sm" role="group">
                                <button type="button" onclick="saveCustomize({{ $customize['id'] }})" class="btn btn-success w-50 noBorderRadius saveCG">@lang('categories.save')Save</button>
                                <button type="button" class="btn btn-secondary w-50 noBorderRadius cancelEditCG">@lang('categories.cancel')Cancel</button>
                            </div>
                        </div>
                    </div>
                </form>
                <form id="deleteCG{{ $customize['id'] }}" method="post" action="{{ route('customizes.destroy', $customize['id']) }}">
                    @csrf
                    @method('DELETE')

                </form>
            @empty
            @endforelse

        </div>
    </div>

    <!-- Modals -->
    <!-- Add New Customize Group Modal -->
    <div class="modal fade" id="addCG" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="{{ route('customizes.store') }}" method="POST" id="forms_CreateCustomizeGroup">
                @csrf
            <div class="modal-content">
                <div class="modal-body">
                    <input class="form-control form-control-lg border-0 newCGNameInputModal" type="text" placeholder="@lang('categories.group_name')Customize Group Name" name="group_name">
                    <hr>
                    <div class="newCustomizeItems"></div>
                    <!--<div id="emptyCGItems">
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">Examble</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 2</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 3</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 4</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">Examble</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 5</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 6</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 7</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">Examble</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 8</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 9</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 10</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">Examble</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 11</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 12</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 13</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">item 14</a>
                        <a class="btn btn-light btn-sm disabled" href="#" role="button">Examble</a>
                        <p class="text-muted" style="margin: 16px 5px !important;"> This Customize Group Is empty Add Some Items Now </p>
                    </div>-->
                    <hr>
                    <div class="row" style="margin-top: 1.5rem">
                        <div class="col-lg-9">
                            <input class="form-control noBorderRadius addItemToNewCGInput" type="text" placeholder="@lang('customizes.item_name')">
                        </div>
                        <div class="col-lg-3">
                            <button type="button" class="btn btn-primary btn-block addItemToNewCG  noBorderRadius">@lang('customizes.add_item')</button>
                        </div>
                    </div>
                </div>
                <div class="btn-group btn-block " style="margin-top: .5rem" role="group">
                    <button type="button" class="btn btn-danger w-50 noBorderRadius" data-dismiss="modal">@lang('categories.cancel')</button>
                    <button type="button" class="btn btn-success w-50 noBorderRadius addNewCGToCGs" data-dismiss="modal">@lang('categories.save')</button>
                </div>
            </div>
            </form>
        </div>
    </div>

    <!-- Are You Sure Modal for remove CG -->
    <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">

            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-danger" id=""><i class="fas fa-exclamation-triangle"></i> @lang('customizes.are_you_sure') </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5 class="text-muted">@lang('customizes.delete_customize_group')</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">@lang('customizes.no')</button>
                    <button type="button" class="btn btn-danger btn-lg">@lang('customizes.yes')</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('extra-js')

    <script>
        $('.sideNav > a').tooltip() ;
        $('.item-qnt').tooltip();

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <script>
        //Open Edit mode in this customize group
        $(document).on('click', '.editCG', function(){
            //disable edit in all CGs
            $(".editCG").hide();
            //get CG Name For Change
            var oldCGName = $(this).parent().find(".CGName").text() ;
            //hide Old Name
            $(this).parent().find(".CGName").hide();
            //Retrive Old Name To Input
            $(this).parent().find(".CGNameInput").val(oldCGName).addClass("display-block");
            //show Delete Icon To Delete This CG
            $(this).parent().find(".deleteCG").addClass("display-block");
            //Add Delete Icon To All Items In This CG
            $(this).parent().find(".removeItemFromCG").show();
            //Show Add Btn & Input To Add New Item To This CG
            $(this).parent().find(".addNewItemToCG").addClass("display-block");
            //Show Action Btns To Save Or Cancel CG
            $(this).parent().parent().find(".actionBtnsCG").addClass("display-block");
        });

        //Save CG And Close It
        $(document).on('click', '.saveCG , .cancelEditCG', function(){

            //ReEnable edit in all CGs
            $(".editCG").show();
            //get New CG Name From Input
            var newCGName = $(this).parent().parent().parent().find(".CGNameInput").val() ;
            // Hide Input
            $(this).parent().parent().parent().find(".CGNameInput").removeClass("display-block");
            //Retrive New Name & show It
            $(this).parent().parent().parent().find(".CGName").text(newCGName).show();

            //remove Delete Icon from CG
            $(this).parent().parent().parent().find(".deleteCG").removeClass("display-block");
            //remove remove Item from All items in this CG
            $(".removeItemFromCG").hide();

            //Hide Add Btn & Input in CG
            $(this).parents().find(".addNewItemToCG").removeClass("display-block");
            //hide Action Btns To Save Or Cancel CG
            $(this).parents().find(".actionBtnsCG").removeClass("display-block");
        });

        //add item to New CG
        $(".addItemToNewCG").click(function (){
            var itemNewCGInputValue = $(this).parent().parent().find(".addItemToNewCGInput").val() ;
            console.log(itemNewCGInputValue);
            if($.trim(itemNewCGInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('categories.error') </span> @lang('customizes.cant_add_empty_item') ",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();
            } else {
                $(this).parent().parent().parent().parent().find(".newCustomizeItems").append(`<input name="items[][custom_name]" type="hidden" value="${itemNewCGInputValue}"><a class="btn btn-light btn-sm" href="#" role="button">${itemNewCGInputValue} <span class="removeItemFromCG"><i class="fas fa-trash-alt"></i></span></a></input>`);
                $(".addItemToNewCGInput").val("");

                if($('.newCustomizeItems').find('a').length !== 0){
                    $('#emptyCGItems').hide();
                }

            }
        });

        //add new Cg To Other Cgs
        $(".addNewCGToCGs").click(function (){
            var newCGNameInputValue = $(".newCGNameInputModal").val() ;
            var noItemsInOrNot = $('.newCustomizeItems').html().length ;

            //alert(noItemsInOrNot);
            if(($.trim(newCGNameInputValue) == "") || (noItemsInOrNot == 0)){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('categories.error') </span> @lang('customizes.empty_name_or_items') ",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

                $(".newCustomizeItems a" ).remove();
                $(".newCGNameInputModal").val("");
            } else {
                $(".card-columns").append(
                    '<div class="card">' +
                    '        <div class="card-body">' +
                    '            <h3 class="CGName">'+newCGNameInputValue+'</h3>' +
                    '            <input class="form-control CGNameInput" type="text" value="" hidden>' +
                    '            <i class="fas fa-pen-square editCG"></i>' +
                    '            <i class="fas fa-trash-alt deleteCG" data-toggle="modal" data-target="#confirmModal" hidden></i>' +
                    '            <hr>' +
                    '            <div class="customizeItems tempCustomizeGItems">' +
                    '            </div>' +
                    '            <div class="addNewItemToCG" style="margin-top:1rem"  hidden>' +
                    '                <hr>' +
                    '                <div class="row">' +
                    '                    <div class="col-lg-9">' +
                    '                        <input class="form-control form-control-sm addItemToCGInput" type="text" placeholder="@lang('customizes.item_name')Item Name">' +
                    '                    </div>' +
                    '                    <div class="col-lg-3">' +
                    '                        <button type="button" class="btn btn-primary btn-sm btn-block addItemToCG">@lang('categories.add')Add</button>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '        <div class="actionBtnsCG" hidden>' +
                    '            <div class="btn-group btn-block btn-group-sm" role="group">' +
                    '                <button type="button" class="btn btn-success w-50 noBorderRadius saveCG">@lang('categories.save')</button>' +
                    '                <button type="button" class="btn btn-secondary w-50 noBorderRadius cancelEditCG">@lang('categories.cancel')</button>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>');

                $(".removeItemFromCG" ).remove();
                $(".newCustomizeItems a" ).clone().appendTo( ".tempCustomizeGItems" );

                $(".newCustomizeItems a" ).remove();


                $('#emptyCGItems').show();

                $(".tempCustomizeGItems").removeClass("tempCustomizeGItems");
                SubmitForm('forms_CreateCustomizeGroup');
                $(".newCGNameInputModal").val("");
            }
        });

        //add item to CG
        $(".addItemToCG").click(function (){
            var itemCGInputValue = $(this).parent().parent().find(".addItemToCGInput").val() ;

            if($.trim(itemCGInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('categories.error') </span> @lang('customizes.cant_add_empty_item') ",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();
            } else {
                var html = '<a class="btn btn-light btn-sm" href="#" role="button">'+itemCGInputValue;
                html += '<input name="items[][custom_name]" type="hidden" value="'+itemCGInputValue+'">';
                html += '<span class="removeItemFromCG"><i class="fas fa-trash-alt"></i></span>';
                html += '</a>';
                html += '</input>';
                $(this).parent().parent().parent().parent().find(".customizeItems").append(html);
                $(".addItemToCGInput").val("");
            }
        });

        function saveCustomize(id) {
            SubmitForm('addItemToCG' + id);
        }

        function deleteCG(id) {
            if (confirm('@lang('customizes.sure_delete_group')')) {
                SubmitForm('deleteCG' + id);
            }
        }

        //Remove item From CG
        function RemoveItemFromCG(id) {
            if (confirm('@lang('customizes.sure_delete_item')')) {
                var url = '{{ route('customizes.remove.item') }}';
                var token = '{{ csrf_token() }}';
                $("#removeItemFromCG" + id).remove();
                //alert('.removeItemFromCG' + id);
                if ($('.newCustomizeItems').find('a').length !== 0) {
                    $('#emptyCGItems').hide();
                } else {
                    $('#emptyCGItems').show();
                }
                //return;
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {id: id, _token :token, _method: 'DELETE'},
                }).done(function(data) {

                }).fail(function(ex){
                    console.log(ex);
                });
            }
        }

    </script>
@endsection