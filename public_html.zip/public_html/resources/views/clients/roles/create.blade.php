@extends('layouts.master')

@section('title','UPOS | create new user')

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection
@section('page-links')
    <li class="breadcrumb-item"><a href="{{ route('roles.index') }}">Roles</a></li>
    <li class="breadcrumb-item active">Create Role</li>
@endsection

@section('extra-styles')
    <style type="text/css">
        .roles-list {
            border: 1p solid #aaa;
        }

        .notSelected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #ccc;
        }

        .selected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #28a745;
        }
    </style>
@endsection
@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection
@section('content')

    @include('partials.navbar')
    @include('partials.sidebar')

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">Roles <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;">Add New Role</span></h3>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" >Cancel</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" onclick="SubmitForm('forms_CreateRole')">Add</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents" id="newEmployee" style="margin: 0 3rem 2rem 6rem !important;">
        <div class="card card-body">
            <h4>New Role</h4>
            <hr>
            <form method="post" id="forms_CreateRole" action="{{ route("roles.store") }}">
                @csrf
                <div class="row">
                    <div class="col">
                        <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" placeholder="Name">
                        @if ($errors->has('name'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('slug') ? 'is-invalid' : '' }}" type="text" name="slug" placeholder="Slug">
                        @if ($errors->has('slug'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('slug') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="w-100" style="margin: .5rem 0"></div>

                    <div class="col">
                        <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" type="text" style="height: 125px!important;" name="description" placeholder="Description"></textarea>
                        @if ($errors->has('description'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('description') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="w-100" style="margin: .5rem 0"></div>
                    <div class="col-12">
                        <h1><i class="fas fa-lock "></i></h1>
                    </div>

                    @forelse($permissions as $permission)
                        <div class="col-2">
                            <a class="btn btn-light notSelected btn-block" id="selector{{ $permission['id'] }}" onclick="setChecked(this, {{ $permission['id'] }})" style="text-align: left!important;" role="button">
                                <input type="checkbox" style="display: none" name="permissions[]" value="{{ $permission['id'] }}" id="item{{ $permission['id'] }}">
                                {{ $permission['name'] }}
                            </a>
                        </div>
                    @empty
                    @endforelse
                    <div class="col-2 new-permission-button">
                        <a class="btn btn-light btn-block" data-toggle="modal" data-target="#new-permission" id="selector{{ $permission['id'] }}" onclick="setChecked(this, {{ $permission['id'] }})" style="text-align: left!important;" role="button">
                            New Permession
                        </a>
                    </div>
                    <div class="w-100" style="margin: .5rem 0"></div>
                    <div class="col-12">
                        <h1><i class="fas fa-utensils "></i></h1>
                    </div>
                    @forelse($kitchens as $kitchen)
                        <div class="col-2">
                            <a class="btn btn-light notSelected btn-block parentOf{{ $kitchen['parent'] }}" id="select-kitchen{{ $kitchen['id'] }}" onclick="setKitchenChecked(this, {{ $kitchen['id'] }})" style="text-align: left!important;" role="button">
                                <input type="checkbox" style="display: none" name="kitchens[]" value="{{ $kitchen['id'] }}" id="kitchen{{ $kitchen['id'] }}" class="parentOfCheck{{ $kitchen['parent'] }}">
                                {{ $kitchen['en_name'] }}
                            </a>
                        </div>
                    @empty
                    @endforelse
                </div>
            </form>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="new-permission" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header row">
                    <div class="col-9">
                        <h4 class="modal-title" id="exampleModalLabel">Add Permission</h4>
                    </div>
                    <div class="col-3">

                    </div>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="permission-name" id="permission-name" placeholder="Name">
                            @if ($errors->has('name'))
                                <span class="invalid-feedback">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                            @endif
                        </div>
                        <div class="col">
                            <input class="form-control {{ $errors->has('slug') ? 'is-invalid' : '' }}" type="text" name="permission-slug" id="permission-slug" placeholder="Slug">
                            @if ($errors->has('slug'))
                                <span class="invalid-feedback">
                                <strong>{{ $errors->first('slug') }}</strong>
                            </span>
                            @endif
                        </div>
                        <div class="w-100" style="margin: .5rem 0"></div>

                        <div class="col">
                            <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" type="text" style="height: 125px!important;" name="permission-description" id="permission-description" placeholder="Description"></textarea>
                            @if ($errors->has('description'))
                                <span class="invalid-feedback">
                                <strong>{{ $errors->first('description') }}</strong>
                            </span>
                            @endif
                        </div>
                        <div class="w-100" style="margin: .5rem 0"></div>


                    </div>
                </div>
                <div class="w-100">
                    <hr>
                </div>
                <div class="modal-footer row" style="border: none">
                    <div class="col text-right">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" onclick="newPermission()" class="btn btn-primary">Save changes</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection




@section('extra-js')
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>


        $('.roles-list').select2({
            theme: "bootstrap",
            placeholder: "search for role ...",
            width: "100%",
            height: "100%",
        });

        function setKitchenChecked(ele, id) {
            var itemClass = $(ele).attr('class');
            if (itemClass.search('notSelected') != -1) {
                $('#kitchen' + id).attr("checked", "checked");
                $(ele).removeClass('notSelected').addClass('selected');
                $('.parentOfCheck' + id).attr("checked", "checked");
                $('.parentOf' + id).removeClass('notSelected').addClass('selected');
            } else {
                $('#kitchen' + id).removeAttr('checked');
                $(ele).removeClass('selected').addClass('notSelected');
                $('.parentOfCheck' + id).removeAttr("checked");
                $('.parentOf' + id).removeClass('selected').addClass('notSelected');
            }
        }

        function SubmitForm(formId)
        {
            $('#'+formId).submit();
        }

        $('.roles-list').on('select2:select', function (event) {
            var role_id = $(event.currentTarget).find("option:selected").val();
            var role_name = $(event.currentTarget).find("option:selected").text();

            if($.trim(role_name) == "") {
                Toastify({
                    text: "<span class='font-weight-bold'> ERROR - </span> Can't add empty role",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            } else {
                var html = `<span><input type="hidden" name="roles[]" value=${role_id}> <button type="button" class="btn btn-light basicOptionalBtn"> ${role_name}<i class="fas fa-times-circle remove-role"></i></button></span>`;
                $(".newRole").append(html);
                //$(".addOptionalToNewItemInput").val("");
            }
        });

        $(document).on("click", ".remove-role", function () {
            $(this).parent().parent().remove();
        });

        function setChecked(ele, id) {
            var itemClass = $(ele).attr('class');
            if (itemClass.search('notSelected') != -1) {
                $('#item' + id).attr("checked", "checked");
                $(ele).removeClass('notSelected').addClass('selected');
            } else {
                $('#item' + id).removeAttr('checked');
                $(ele).removeClass('selected').addClass('notSelected');
            }
        }

        function newPermission () {
            var url = '{{ route('permissions.store') }}';
            var token = '{{ csrf_token() }}';
            var name = $('#permission-name').val();
            var slug = $('#permission-slug').val();
            var description = $('#permission-description').val();
            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                data: {_token: token, name: name, slug: slug, description: description},
            }).done(function(data) {
                console.log(data);
                //$permission
                var html = '<div class="col-2">';
                html += '<a class="btn btn-light selected btn-block" id="selector' + data.id + '" onclick="setChecked(this, ' + data.id + ')" style="text-align: left!important;" role="button">';
                html += '<input type="checkbox" checked="checked" style="display: none" name="permissions[]" value="' + data.id + '" id="item' + data.id + '">';
                html += name;
                html += '</a>';
                html += '</div>';
                $(html).insertBefore('.new-permission-button');
                $('#new-permission').modal('hide');
                $('#permission-name').val('');
                $('#permission-slug').val('');
                $('#permission-description').val('');
            }).fail(function(ex){
                console.log(ex);
            });
        }
    </script>


@endsection