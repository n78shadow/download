<?php //dd($category); ?>
@extends('layouts.master')


@section('title','UPOS | Users')
@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Reports</a></li>
<li class="breadcrumb-item active">Punch Report</li>
@endsection

@section('extra-links')
<li class="nav-item">
    <a class="nav-link" href="#">Customize Groups</a>
</li>
@endsection

@section('extra-css-links')
<link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">
<!--link rel="stylesheet" href="{{ asset('assets/css/gijgo.min.css') }}"-->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datetimepicker.min.css') }}">

<style type="text/css">
    .table thead th {
        border-bottom: none !important;
    }

    .removeRole {
        color: #dc3545;
        margin: 4px 0px 0px 4px;
        padding: 2px;
    }

    .editUser {
        visibility: hidden;
        cursor: pointer;
        font-size: 18px;
        color: #3e3e3e;
    }

    .editUser:hover {
        color: #212121;
        transition: 0.2s;
    }

    tr:hover .editUser {
        transition: 0.2s;
        visibility: visible;
    }


    /** Carusel Indicator **/
    .carousel-indicators li {
        position: relative;
        -ms-flex: 0 1 auto;
        flex: 0 1 auto;
        width: 30px;
        height: 3px;
        margin-right: 3px;
        margin-left: 3px;
        text-indent: -999px;
        background-color: rgba(0,0,0,0.2);
    }

    .carousel-indicators .active {
        background-color: rgba(0,0,0,0.4);
    }

    .saveGraphPng {
        position: absolute;
        top: 15px;
        right: 20px;
        color: #b0b0b0;
    }

    .saveGraphPng:hover {
        transition: 0.2s;
        color: #3e3e3e;
    }

    .totalResault span {
        background-color: #ddd;
        color: #3e3e3e;
        border-radius: 50px;
        padding: 2px 16px;
        float: right;
        font-size: 18px ;
    }

    td.details-control {
        background: url({{ asset('assets/images/details_open.png') }}) no-repeat center center;
        cursor: pointer;
    }
    tr.shown td.details-control {
        background: url({{ asset('assets/images/details_close.png') }}) no-repeat center center;
    }
</style>
@endsection

@section('content')
@include('partials.navbar')
@include('partials.sidebar')


<div class="contents" style="margin: 0rem 2rem 0rem 0rem !important">
    <div class="row">
        <div class="col-10">
            <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
                <div class="card border-0 noBorderRadius">
                    <div class="card-body">
                        <div class="row">
                            <div class="col" style="padding: 0 ; margin-top: 4px">
                                <div class="col text-left">
                                </div>
                                <div class="col text-left" id="myBtnFilter">
                                    <select class="user-search"></select>
                                    <button type="button" onclick="getPunches('daily')" class="btn btn-outline-secondary btn-sm active">Today</button>
                                    <button type="button" onclick="getPunches('yesterday')" class="btn btn-outline-secondary btn-sm">Yesterday</button>
                                    <button type="button" onclick="getPunches('weekly')" class="btn btn-outline-secondary btn-sm">Last Week</button>
                                    <!--button type="button" onclick="getPunches('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Week</button-->
                                    <button type="button" onclick="getPunches('monthly')" class="btn btn-outline-secondary btn-sm">Last Month</button>
                                    <!--button type="button" onclick="getPunches('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Month</button-->
                                    <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"> Advanced <i class="fas fa-search-plus"></i></button>
                                </div>

                                <div class="collapse" id="collapseExample" style="margin-top: 1rem">
                                    <div class="row" style="margin: 0">
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="From ..">
                                        </div>
                                        <div class="col">
                                            <input class="form-control" type="text" placeholder="To ..">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-secondary">Generate</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-2 text-center align-self-center">

            <div class="row">
                <div class="col" style="padding: 0 ; margin-top: 4px">
                    <button type="button" class="btn btn-warning border-0"> Export As PDF <i class="fas fa-file-export"></i> <i class="fas fa-file-pdf"></i></button>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">

    <div class="card">
        <div class="card-body data-table-div">
            <input type="button" class="btn btn-primary" data-toggle="modal" data-target="#addTimeModal" id="add-record" value="Add Record" style="margin: 1rem 0; display: none">
            <table class="table table-hover" id="data-table">
                <thead>
                <tr>
                    <th class="details-control sorting_disabled" rowspan="1" colspan="1" aria-label="" style="width: 16px;"></th>
                    <th scope="col">id</th>
                    <th scope="col">Status</th>
                    <th scope="col">Date</th>
                </tr>
                </thead>
                <tbody>
                <tr >
                </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<div class="modal fade" id="editTimeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">Update Time</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editedTimeId">
                <div class="row" style="margin: 0">
                    <div class='col-sm-6'>
                        <label>Enter Date</label>
                        <input type="text" id="enter-date" class="form-control">
                    </div>
                    <div class='col-sm-6'>
                        <label>Exit Date</label>
                        <input type="text" id="exit-date" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="updatePunchTimes()" onclick="updatePunchTimes()" data-dismiss="modal">Save changes</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addTimeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">Add New Punch</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="user-id">
                <div class="row" style="margin: 0">
                    <div class='col-sm-6'>
                        <label>Enter Date</label>
                        <input type="text" id="new-enter-date" class="form-control">
                    </div>
                    <div class='col-sm-6'>
                        <label>Exit Date</label>
                        <input type="text" id="new-exit-date" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addPunch()" data-dismiss="modal">Save changes</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('extra-js')

<script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('assets/js/select2.min.js') }}"></script>
<script src="{{ asset('assets/js/sortable.js') }}"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!--script src="{{ asset('assets/js/gijgo.min.js') }}"></script-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js" type="text/javascript"></script>
<script src="{{ asset('assets/js/bootstrap-datetimepicker.min.js') }}"></script>

<script>
    var called = 0;
    $('#enter-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });
    $('#exit-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });
    $('#new-enter-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });
    $('#new-exit-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });
    var myData = {};
    var tableHtml = $('.data-table-div').html();
    var table;
    function getPunches (filter) {
        var user_id = $('.user-search').val();
        //$('.data-table-div').html(tableHtml);
        myData = {user_id: user_id, filter: filter};
        if (called == 1) {
            table.ajax.reload();
            return;
        }
        called = 1;
        var url = '{{ route('reports.punchIn') }}';
        table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: url,
                data: function (d) {
                    return  $.extend(d, myData);
                }
            },
            columns: [
                {
                    "className":      'details-control',
                    "orderable":      false,
                    "data":           null,
                    "defaultContent": ''
                },
                { data: 'id', name: 'id' },
                { data: 'status', name: 'Status' },
                { data: 'created_at', name: 'Date' },
            ],
            order: [[1, 'asc']]
        });
        $('#add-record').show();
        $(document).on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.row(tr);
            if ( row.child.isShown() ) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            } else {
                // Open this row
                row.child( subTable(row.data()) ).show();
                tr.addClass('shown');
            }
        } );
    }

    function subTable (data) {
        data = data.logins;
        // `data` is the original data object for the row
        var html = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;width: 100%;">';
        html += '<tr>';
        html += '<th>Enter date</th>';
        html += '<th>Exit date</th>';
        html += '<th>Duration</th>';
        html += '<th>Order counts</th>';
        html += '<th>Edit</th>';
        html += '</tr>';

        for (var s = 0; s < data.length; s++) {
            html += '<tr>';
            html += '<td id="enter' + data[s].id + '">'+data[s].enter_date+'</td>';
            html += '<td id="exit' + data[s].id + '">'+data[s].exit_date+'</td>';
            html += '<td id="duration' + data[s].id + '">'+data[s].duration+'</td>';
            html += '<td>'+data[s].order_counts+'</td>';
            html += '<td><a style="cursor: pointer" data-toggle="modal" data-target="#editTimeModal" onclick="setEditedPunch(' + data[s].id + ')"><i class="fas fa-edit"></i></a></td>';
            html += '</tr>';
        }
        html += '</table>';
        return html;
    }

    function setEditedPunch(id) {
        $('#editedTimeId').val(id);
        $('#enter-date').val($('#enter' + id).text());
        $('#exit-date').val($('#exit' + id).text());
    }

    function updatePunchTimes () {
        var url = '{{ route('punch.update.time') }}';
        var token = '{{ csrf_token() }}';
        var id = $('#editedTimeId').val();
        var enter_time = $('#enter-date').val();
        var exit_time = $('#exit-date').val();
        if ($('#exit-date').val() == '' || $('#enter-date').val() == '') {
            Toastify({
                text: "<span class='font-weight-bold'> Error! </span> You can not leave date empty",
                duration: 6000,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
            return;
        }

        $.ajax({
            url: url,
            type: 'post',
            dataType: 'json',
            data: {id: id, enter_date: enter_time, exit_date: exit_time, _token :token},
        }).done(function(data) {
            table.ajax.reload();
        }).fail(function(ex){
            console.log(ex);
        });
    }
    
    function addPunch() {
        var url = '{{ route('punches.store') }}';
        var token = '{{ csrf_token() }}';
        var id = $('.user-search').val();
        var enter_time = $('#new-enter-date').val();
        var exit_time = $('#new-exit-date').val();
        if (enter_time == 'null') {
            enter_time = null;
        }
        if (exit_time == 'null') {
            exit_time = null;
        }

        $.ajax({
            url: url,
            type: 'post',
            dataType: 'json',
            data: {id: id, enter_date: enter_time, exit_date: exit_time, _token :token},
        }).done(function(data) {
            console.log(data);
            table.ajax.reload();
        }).fail(function(ex){
            console.log(ex);
        });
    }

    function searchingFor()
    {
        var url = '{{ route('users.search') }}';
        if(url == '')
        {
            return;
        }
        $('.user-search').select2({
            placeholder: "type any word to find ...",
            minimumInputLength: 2,
            width: "130px",
            ajax: {
                url: url,
                dataType: 'json',
                data: function (params) {
                    return {
                        q: $.trim(params.term)
                    };
                },
                processResults: function (data) {
                    //console.log(data);
                    return {
                        results: data
                    };
                },
                error: function (err) {
                    console.log(err);
                },
                cache: true
            }
        });
    }

    searchingFor();
</script>
@endsection
