<?php //dd($category); ?>
@extends('layouts.master')


@section('title','UPOS | Users')

@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Reports</a></li>
<li class="breadcrumb-item active">Invoice Report</li>
@endsection
@section('extra-links')
<li class="nav-item">
    <a class="nav-link" href="#">Customize Groups</a>
</li>
@endsection

@section('extra-css-links')
<link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datetimepicker.min.css') }}">
<style type="text/css">
    .table thead th {
        border-bottom: none !important;
    }

    .removeRole {
        color: #dc3545;
        margin: 4px 0px 0px 4px;
        padding: 2px;
    }

    .editUser {
        visibility: hidden;
        cursor: pointer;
        font-size: 18px;
        color: #3e3e3e;
    }

    .editUser:hover {
        color: #212121;
        transition: 0.2s;
    }

    tr:hover .editUser {
        transition: 0.2s;
        visibility: visible;
    }


    /** Carusel Indicator **/
    .carousel-indicators li {
        position: relative;
        -ms-flex: 0 1 auto;
        flex: 0 1 auto;
        width: 30px;
        height: 3px;
        margin-right: 3px;
        margin-left: 3px;
        text-indent: -999px;
        background-color: rgba(0,0,0,0.2);
    }

    .carousel-indicators .active {
        background-color: rgba(0,0,0,0.4);
    }

    .saveGraphPng {
        position: absolute;
        top: 15px;
        right: 20px;
        color: #b0b0b0;
    }

    .saveGraphPng:hover {
        transition: 0.2s;
        color: #3e3e3e;
    }

    .totalResault span {
        background-color: #ddd;
        color: #3e3e3e;
        border-radius: 50px;
        padding: 2px 16px;
        float: right;
        font-size: 18px ;
    }
</style>
@endsection

@section('content')
@include('partials.navbar')
@include('partials.sidebar')



<div class="contents" style="margin: 0rem 2rem 0rem 0rem !important">
    <div class="row">
        <div class="col-10">
            <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
                <div class="card border-0 noBorderRadius">
                    <div class="card-body">
                        <div class="row">
                            <div class="col" style="padding: 0 ; margin-top: 4px">
                                <form id="filter-form">
                                    <div class="col text-left" id="myBtnFilter">
                                        <button type="button" onclick="getInvoices('daily')" class="btn btn-outline-secondary btn-sm active">Today</button>
                                        <button type="button" onclick="getInvoices('yesterday')" class="btn btn-outline-secondary btn-sm">Yesterday</button>
                                        <button type="button" onclick="getInvoices('weekly')" class="btn btn-outline-secondary btn-sm">Last Week</button>
                                        <!--button type="button" onclick="getInvoices('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Week</button-->
                                        <button type="button" onclick="getInvoices('monthly')" class="btn btn-outline-secondary btn-sm">Last Month</button>
                                        <!--button type="button" onclick="getInvoices('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Month</button-->
                                        <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"> Advanced <i class="fas fa-search-plus"></i></button>
                                    </div>
                                    <input type="hidden" name="filter" id="filter">
                                    <div class="collapse" id="collapseExample" style="margin-top: 1rem">
                                        <div class="row" style="margin: 0">
                                            <div class="col">
                                                <input class="form-control" id="from-date" name="from_date" type="text" placeholder="From ..">
                                            </div>
                                            <div class="col">
                                                <input class="form-control" id="to-date" name="to_date" type="text" placeholder="To ..">
                                            </div>
                                            <div class="col">
                                                <button type="button" onclick="getInvoices('')" class="btn btn-secondary">Generate</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-2 text-center align-self-center">

            <div class="row">
                <div class="col" style="padding: 0 ; margin-top: 4px">
                    <button type="button" class="btn btn-warning border-0"> Export As PDF <i class="fas fa-file-export"></i> <i class="fas fa-file-pdf"></i></button>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">
    <div class="card">
        <div class="card-body">
            <h2>Invoice Report</h2>
            <table class="table table-hover" id="data-table">
                <thead>
                <tr>
                    <th scope="col">Invoice Id</th>
                    <th scope="col">Date</th>
                    <th scope="col">Cost</th>
                    <th scope="col">Sell</th>
                    <th scope="col">Profit</th>
                    <th scope="col">Discount</th>
                    <th scope="col">TPS</th>
                    <th scope="col">TVQ</th>
                    <th scope="col">Served By</th>
                    <th scope="col">Total Invoice</th>
                    <th scope="col">status</th>
                </tr>
                </thead>
                <tbody>
                <tr >
                </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection

@section('extra-js')

<script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('assets/js/select2.min.js') }}"></script>
<script src="{{ asset('assets/js/sortable.js') }}"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!--script src="{{ asset('assets/js/gijgo.min.js') }}"></script-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js" type="text/javascript"></script>
<script src="{{ asset('assets/js/bootstrap-datetimepicker.min.js') }}"></script>
<script>

    $('#from-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });
    $('#to-date').datetimepicker({
        format:'YYYY-MM-DD HH:mm',
    });

    var formData = {};
    var table;
    var called = 0;
    function getInvoices (filter) {
        formData = {filter: filter, from_date: $('#from-date').val(), to_date: $('#to-date').val()};
        console.log(formData);
        if (called == 1) {
            table.ajax.reload();
            return;
        }
        called = 1;
        var url = '{{ route('reports.invoices') }}';
        table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: url,
                data: function (d) {
                    return  $.extend(d, formData);
                }
            },
            columns: [
                { data: 'id', name: 'Invoice Id' },
                { data: 'date' },
                { data: 'cost', name: 'Cost' },
                { data: 'price', name: 'Sell' },
                { data: 'profit', name: 'Profit' },
                { data: 'discount', name: 'Discount' },
                { data: 'TPS', name: 'TPS' },
                { data: 'TVQ', name: 'TVQ' },
                { data: 'serve_by', name: 'Serve by' },
                { data: 'total', name: 'Total' },
                { data: 'status', name: 'Status','render': function(data, type, row, meta){
                        if (data == 'paid') {
                            data = '<span class="badge badge-success">Paid</span>';
                        } else if (data == 'addition_print') {
                            data = '<span class="badge badge-warning">Addition Print</span>';
                        } else if (data == 'refunded') {
                            data = '<span class="badge badge-danger">Refunded</span>';
                        } else if (data == 'clients_splitted') {
                            data = '<span class="badge badge-primary">Splited</span>';
                        }
                        return data;
                    }
                },
            ],
            order: [[1, 'asc']]
        });
    }

    function submitFilter (filter) {
        $('#filter').val(filter);
        //$('#filter-form').submit();
    }
</script>
@endsection
