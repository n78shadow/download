<?php //dd($category); ?>
@extends('layouts.master')


@section('title','UPOS | Users')
@section('page-links')
    <li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Reports</a></li>
    <li class="breadcrumb-item active">Sales By Shift</li>
@endsection

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection

@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datetimepicker.min.css') }}">
    <style type="text/css">
        .table thead th {
            border-bottom: none !important;
        }

        .removeRole {
            color: #dc3545;
            margin: 4px 0px 0px 4px;
            padding: 2px;
        }

        .editUser {
            visibility: hidden;
            cursor: pointer;
            font-size: 18px;
            color: #3e3e3e;
        }

        .editUser:hover {
            color: #212121;
            transition: 0.2s;
        }

        tr:hover .editUser {
            transition: 0.2s;
            visibility: visible;
        }


        /** Carusel Indicator **/
        .carousel-indicators li {
            position: relative;
            -ms-flex: 0 1 auto;
            flex: 0 1 auto;
            width: 30px;
            height: 3px;
            margin-right: 3px;
            margin-left: 3px;
            text-indent: -999px;
            background-color: rgba(0,0,0,0.2);
        }

        .carousel-indicators .active {
            background-color: rgba(0,0,0,0.4);
        }

        .saveGraphPng {
            position: absolute;
            top: 15px;
            right: 20px;
            color: #b0b0b0;
        }

        .saveGraphPng:hover {
            transition: 0.2s;
            color: #3e3e3e;
        }

        .totalResault span {
            background-color: #ddd;
            color: #3e3e3e;
            border-radius: 50px;
            padding: 2px 16px;
            float: right;
            font-size: 18px ;
        }
    </style>
@endsection

@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')



    <div class="contents" style="margin: 0rem 2rem 0rem 0rem !important">
        <div class="row">
            <div class="col-10">
                <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
                    <div class="card border-0 noBorderRadius">
                        <div class="card-body">
                            <div class="row">
                                <div class="col" style="padding: 0 ; margin-top: 4px">
                                    <form id="filter-form">
                                        <div class="col text-left" id="myBtnFilter">
                                            <button type="button" onclick="submitFilter('daily')" class="btn btn-outline-secondary btn-sm active">Today</button>
                                            <button type="button" onclick="submitFilter('yesterday')" class="btn btn-outline-secondary btn-sm">Yesterday</button>
                                            <button type="button" onclick="submitFilter('weekly')" class="btn btn-outline-secondary btn-sm">Last Week</button>
                                            <!--button type="button" onclick="submitFilter('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Week</button-->
                                            <button type="button" onclick="submitFilter('monthly')" class="btn btn-outline-secondary btn-sm">Last Month</button>
                                            <!--button type="button" onclick="submitFilter('daily')" class="btn btn-outline-secondary btn-sm">Same Day Last Month</button-->
                                            <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"> Advanced <i class="fas fa-search-plus"></i></button>
                                        </div>
                                        <br>
                                        <div class="col text-left">
                                            <span>{{ 'From : ' . $from_date . '  To : ' . $to_date}}</span>
                                        </div>
                                        <input type="hidden" name="filter" id="filter">
                                        <input type="hidden" name="export" id="export" value="no">
                                        <div class="collapse" id="collapseExample" style="margin-top: 1rem">
                                            <div class="row" style="margin: 0">
                                                <div class="col">
                                                    <input class="form-control" id="from-date" name="from_date" type="text" placeholder="From ..">
                                                </div>
                                                <div class="col">
                                                    <input class="form-control" id="to-date" name="to_date" type="text" placeholder="To ..">
                                                </div>
                                                <div class="col">
                                                    <button type="button" onclick="submitFilter('')" class="btn btn-secondary">Generate</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-2 text-center align-self-center">

                <div class="row">
                    <div class="col" style="padding: 0 ; margin-top: 4px">
                        <button type="button" class="btn btn-warning border-0" onclick="generatePDF()" > Export As PDF <i class="fas fa-file-export"></i> <i class="fas fa-file-pdf"></i></button>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <!--
    <div class="contents" style="margin: -1rem 3rem 1rem 6rem !important;">
        <div class="row">
            <div class="col text-left" id="myBtnFilter">
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Yesterday</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Last Week</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Same Day Last Week</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Last Month</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Same Day Last Month</button>
            </div>
        </div>
    </div>
    -->

    <div class="contents" style="margin: 0 3rem 2rem 6rem !important;">
        <div class="card-deck">
            <div class="card" id="Graph">
                <div class="card-body" style="padding: 1.25rem 1.25rem 3rem 1.25rem">
                    <h3 class="card-title">Graph</h3>
                    <button type="button" class="btn btn-light saveGraphPng"><i class="fas fa-download"></i></button>

                    <hr>
                    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                        <ol class="carousel-indicators" style="bottom: -40px;">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner" style="height: 325px">
                            <div class="carousel-item active">
                                <canvas id="myChart"></canvas>
                            </div>
                            <div class="carousel-item">
                                <canvas id="myChart2"></canvas>
                            </div>
                            <div class="carousel-item">
                                <canvas id="myChart3"></canvas>
                            </div>
                        </div>

                        <!--
                        <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        -->
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Total</h3>
                    <div class="row">
                        <div class="col">
                            <div class="col totalResault">
                                <h4>Subtotal <span class="subtotal">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Taxes <span class="taxes">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Discount <span class="discount">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Total <span class="total">  </span> </h4>
                            </div>
                        </div>
                        <div class="col">
                            <div class="col totalResault">
                                <h4>Clients Count <span class="client_count">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Dishes Count <span class="dishs_count">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Tables Count <span class="tables_count">  </span> </h4>
                            </div>
                            <hr>
                            <div class="col totalResault">
                                <h4>Total Tips <span class="tips">  </span> </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">

        <div class="card">
            <div class="card-body">
                <h2>Totals</h2>
                <table class="table table-hover" id="data-total">
                    <thead>
                    <tr>

                        <th scope="col">Subtotal</th>
                        <th scope="col">Taxes</th>
                        <th scope="col">Discount</th>
                        <th scope="col">Total</th>
                        <th scope="col">Total Tips</th>
                        <th scope="col">Clients Count</th>
                        <th scope="col">Dishes Count</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr >
                        <td><span class="subtotal">  </span></td>
                        <td><span class="taxes">  </span></td>
                        <td><span class="discount">  </span></td>
                        <td><span class="total">  </span></td>
                        <td><span class="tips">  </span></td>
                        <td><span class="client_count">  </span></td>
                        <td><span class="dishs_count">  </span></td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>

    </div>


    <div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">

        <div class="card">
            <div class="card-body">
                <h2>Medias</h2>
                <table class="table table-hover" id="payment-data">
                    <thead>
                    <tr>

                        <th scope="col">#</th>
                        <th scope="col">Payment</th>
                        <th scope="col">Total Paid</th>
                        <th scope="col">Total Tips</th>

                    </tr>
                    </thead>
                    <tbody>
                    <tr >
                        <th scope="row">1</th>
                        <td>Cash</td>
                        <td id="cash-payment"></td>
                        <td id="cash-tips"></td>
                    </tr>
                    <tr >
                        <th scope="row">2</th>
                        <td>Credit</td>
                        <td id="credit-payment"></td>
                        <td id="credit-tips"></td>
                    </tr>
                    <tr >
                        <th scope="row">3</th>
                        <td>Debit</td>
                        <td id="debit-payment"></td>
                        <td id="debit-tips"></td>
                    </tr>
                    <tr >
                        <th scope="row">4</th>
                        <td>Coupon</td>
                        <td id="coupon-payment"></td>
                        <td id="coupon-tips"></td>
                    </tr>
                    <tr >
                        <th scope="row">5</th>
                        <td>Total Tips</td>
                        <td class="tips"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">

        <div class="card">
            <div class="card-body">
                <h2>Credit Details</h2>
                <table class="table table-hover" id="credit-data">
                    <thead>
                    <tr>

                        <th scope="col">#</th>
                        <th scope="col">Payment</th>
                        <th scope="col">Total Paid</th>
                        <th scope="col">Total Tips</th>

                    </tr>
                    </thead>
                    <tbody id="credit-details">

                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <div class="contents" id="reportTable" style="margin: 0 3rem 2rem 6rem !important;">

        <div class="card">
            <div class="card-body">
                <h2>Taxes</h2>
                <table class="table table-hover" style="text-align: center" id="taxes-data">
                    <thead>
                    <tr>
                        <th scope="col">TPS</th>
                        <th scope="col">TVQ</th>
                        <th scope="col">Total Taxes</th>
                    </tr>
                    </thead>
                    <tbody id="credit-details">
                    <tr >
                        <td id="tps"></td>
                        <td id="tvq"></td>
                        <td id="total-tax" class="taxes"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
@endsection

@section('extra-js')

    <script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!--script src="{{ asset('assets/js/gijgo.min.js') }}"></script-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js" type="text/javascript"></script>
    <script src="{{ asset('assets/js/bootstrap-datetimepicker.min.js') }}"></script>
    <script>

        $('#from-date').datetimepicker({
            format:'YYYY-MM-DD HH:mm',
        });
        $('#to-date').datetimepicker({
            format:'YYYY-MM-DD HH:mm',
        });


        function getSales() {
            var data = {!! $data !!};
            console.log(data.payments);
            $('.subtotal').text(' ' + data.sub_total + ' ');
            var tps = parseFloat(data.taxes.TPS);
            var tvq = parseFloat(data.taxes.TVQ);
            $('#tps').text(tps.toFixed(2));
            $('#tvq').text(tvq.toFixed(2));
            $('.taxes').text(' ' + (tps + tvq).toFixed(2) + ' ');
            $('.total-tax').text(' ' + (tps + tvq).toFixed(2) + ' ');
            $('.discount').text(' ' + data.discount + ' ');
            $('.total').text(' ' + data.total + ' ');
            $('.tips').text(' ' + data.total_tips.toFixed(2) + ' ');
            $('.client_count').text(' ' + data.clients_count + ' ');
            $('.dishs_count').text(' ' + data.dishes_count + ' ');
            $('.tables_count').text(' ' + data.tables_count + ' ');

            var payments = data.payments;
            var cash_tips = parseFloat(payments.cash.tips_value);
            var cash_value = parseFloat(payments.cash.paid_value);
            $('#cash-payment').text((cash_value).toFixed(2));
            $('#cash-tips').text('');
            // $('#cash-tips').text((cash_tips).toFixed(2));
            var debit_tips = parseFloat(payments.debit.tips_value);
            var debit_value = parseFloat(payments.debit.paid_value);
            $('#debit-payment').text((debit_value).toFixed(2));
            $('#debit-tips').text((debit_tips).toFixed(2));

            if (typeof payments.coupon !== 'undefined') {
                var coupon_tips = parseFloat(payments.coupon.tips_value);
                var coupon_value = parseFloat(payments.coupon.paid_value);
            }
            else
            {
                var coupon_tips = 0;
                var coupon_value = 0
            }



            $('#coupon-payment').text((coupon_value).toFixed(2));
            $('#coupon-tips').text((coupon_tips).toFixed(2));

            var credit_sum = 0.00;
            var credit_tips = 0.00;
            credit = payments.credit.channels;

            //var master_card
            //credit_sum = parseFloat(credit.master_card.paid_value);
            var credit_details = '';
            var s = 1;
            $.each(credit, function(i, index) {
                credit_tips += parseFloat(index.tips_value);
                credit_sum += parseFloat(index.paid_value);
                credit_details += '<tr>';
                credit_details += '<th scope="row">' + s++ + '</th>';
                credit_details += '<td>' + i.replace(/_/g, ' ') + '</td>';
                credit_details += '<td>' + (parseFloat(index.paid_value)).toFixed(2) + '</td>';
                credit_details += '<td>' + (parseFloat(index.tips_value)).toFixed(2) + '</td>';
                credit_details += '</tr>';
            });

            credit_details += '<tr>';
            credit_details += '<th scope="row">' + s++ + '</th>';
            credit_details += '<td>Total Tips</td>';
            credit_details += '<td>' + credit_tips.toFixed(2) + '</td>';
            credit_details += '</tr>';
            $('#credit-details').html(credit_details);
            $('#credit-payment').text(credit_sum.toFixed(2));
            $('#credit-tips').text(credit_tips.toFixed(2));


            var categories_list = {!! $categories_data !!};
            $('#food-count').text(categories_list.food.item_counts);
            $('#food-price').text(categories_list.food.sub_total);
            $('#bar-count').text(categories_list.bar.item_counts);
            $('#bar-price').text(categories_list.bar.sub_total);

        }
        getSales();

        function submitFilter (filter) {
            $('#filter').val(filter);
            $('#filter-form').submit();
        }

        function submitExport () {
            $('#export').val('yes');
            $('#filter-form').submit();
        }

    </script>

    <script src="{{ asset('assets/js/jspdf.debug.js') }}"></script>
    <script src="{{ asset('assets/js/jspdf.plugin.autotable.js') }}"></script>
    <script src="{{ asset('assets/js/jspdf_examples.js') }}"></script>

    <script>
        function generatePDF() {
            var funcStr = 'html';
            var client = "Sales By Shift";
            var fromDate = '{!! $from_date !!}';
            var toDate =  '{!! $to_date !!}';
            var htmlTables = "data-total,payment-data,taxes-data,credit-data";
            htmlTables = htmlTables.split(',');//.replace(/ /g, '');
            var branchName = '{!! $rest_name !!}';
            var doc = examples[funcStr](htmlTables, client, fromDate, toDate, 0, 0, 0, branchName);
            doc.setProperties({
                title: 'Sales By Shift ' + fromDate,
                subject: 'Powered By UPOS'
            });
            doc.save('SalesByShift' + fromDate + '.pdf');
        }
    </script>
@endsection
