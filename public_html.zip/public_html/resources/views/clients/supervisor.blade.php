@extends('layouts.master')

@section('title','UPOS | supervision')

@section('extra-js')

    <script src="{{ asset('js/supervisor/supervisor.js?11') }}" defer></script>



@endsection
@section('extra-head-js')

            <script src="{{ asset('js/app.js?11') }}" defer></script>
            <script src="{{ asset('js/masonry.pkgd.min.js') }}" defer></script>


@endsection

@section('extra-css-links')
    <!-- <link rel="stylesheet" href="{{URL::asset('assets/css/pos.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/font-awesome/css/all.min.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/bootstrap-switches.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/bootstrap-radio.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/materialColor.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/toastify.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/pickDateTime/default.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/pickDateTime/default.time.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/pickDateTime/default.date.css')}}">-->

    <link rel="stylesheet" href="{{URL::asset('assets/css/easy-numpad/easy-numpad.css')}}">




@endsection


@section('content')
<style>
      body{
            background-color: #212121 !important;
        }

        .topNav {
            padding: .5rem 1.5rem !important;
            background-color: #323232;
        }

        .topNav li {
            font-size: 22px;
            padding: 3.5px;
        }

        .nav-link .badge {
            margin-left: 5px;
        }

        .sideNav {
            position: fixed;
            width: 55px;
            height: 100%;
            padding-top: 0;
            background-color: #0a0a0a;
            top: 0;
            z-index: 1210;
        }

        .hold-invoice {
            opacity: 0.2;
            border: 2px solid #ffc107 !important;
        }

        .hold-invoice .card-title {

            background-color: #ffc107 !important;
            color : #fff ;

        }
        .hold-invoice .bill-handle {
            background-color: #ffc107;
            color: #fff;
        }

        .flipped-invoice {
            border: 2px solid #007bff !important;
        }

        .flipped-invoice .card-title {

            background-color: #007bff !important;
            color : #fff ;

        }

        .flipped-invoice .bill-handle {
            background-color: #007bff;
            color: #fff;
        }

        .contents {
            margin: .5rem !important;
        }
        .fororder{
            display:block;
        }

        .card {
            background-color: transparent;
            border: 2px solid #fff;
            color: #fff !important;
        }

        .card .card-body{
            padding: 2rem .75rem .75rem .75rem;
        }

        .card .card-title {
            margin-left: -2rem !important;
        }

        /*  less than 20 - 8 card */
        @media screen and (max-width: 20in) {
            .invoice-size,
            //.card { margin-top: 4px ; width: 12.5% !important ;}

            .card-columns {
                -webkit-column-count: 7;
                -moz-column-count: 7;
                column-count: 7 ;
                orphans: 1;
                widows: 1;
        }
        }​

        /* No greater than 30, no less than 21 - 12 card */
        /* @media (max-width:30in) and (min-width:21in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 8.333333333333333% !important; }
        }​ */

        /* No greater than 40, no less than 31 - 16 card */
        /* @media (max-width:40in) and (min-width:31in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 6.25% !important; }
        }​ */

        /*  greater than 40 - 20 card */
        /* @media screen and (min-width: 41in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 5% !important; }
        } */

        .invoices-container {
            margin: 1rem ;
        }

        .service-preperation {
            opacity: 0.4;
            margin-bottom: 1rem;
        }

        .service-preperation h4 {
            margin: 0;
        }

        .service-preperation .item {
            display: block;
            text-align: left;
        }

        .service-active {
            opacity: 1 !important;
        }

        hr {
            background-color: #fff;
            margin-top: 0.25rem;
            margin-bottom: 0.25rem;
        }

        .deletedItem {
            opacity: 0.5;
            padding: 5px 5px 5px 30px !important;
        }

        .deletedItem:after {
            content: '\f2ed';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            position: absolute;
            left: 7px;
        }

        .addedItem {
            position: relative;
            cursor: pointer;
            box-shadow: 0 0 0 0 rgba(0,0,0,0.2);
            -webkit-animation: pulse 1.5s infinite;
        }

        .addedItem:hover {
            -webkit-animation: none;
        }

        @-webkit-keyframes pulse {
            0% {
                -moz-transform: scale(0.95);
                -ms-transform: scale(0.95);
                -webkit-transform: scale(0.95);
                transform: scale(0.95);
            }
            70% {
                -moz-transform: scale(1);
                -ms-transform: scale(1);
                -webkit-transform: scale(1);
                transform: scale(1);
                box-shadow: 0 0 0 6px rgba(90, 153, 212, 0);
            }
            100% {
                -moz-transform: scale(0.95);
                -ms-transform: scale(0.95);
                -webkit-transform: scale(0.95);
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(90, 153, 212, 0);
            }
        }

        .served-dishes {
            display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .1rem;
            padding-top: .1rem;
            font-size: 12px;
        }

        .customize-item {
            display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .2rem;
            padding-left: .4rem;
            padding-top: .2rem;
            font-size: 16px;
        }

        .customize-itemWithDishNum {
            display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .2rem;
            padding-left: 1.4rem;
            padding-top: .2rem;
            font-size: 16px;
        }

        .dishNumCustomize {
            background-color: rgba(0,0,0,0.2);
            padding: 2px 8px;
            margin-left: -1.4rem;
        }

        .finishedKit {
            background-color: #fff !important;
            color: #28a745  !important;
        }

        .tasting .servedItem {
            position: relative;
            opacity: 0.5;
            padding: 0px 3px 12px 5px !important;
        }

        .servedItem {
            opacity: 0.5;
        }

        .tasting a:not(.numpadbutton) {
            display: inline-block  !important;
            margin: 6px 0 0 0;
            background-color: #28a745 ;
            width: 30%;
            text-align: center;
        }
        .merge { background-color: transparent ; color: #ffc107 ; border: none }
        .merge:hover { background-color: #ffc107 ; color: #000 ; transition: 0.2s }
        .serviceNum { background-color: transparent ; color: #fff ; border: none ; font-size: 20px}
        .serviceNum:hover { background-color: #fff ; color: #000 ; transition: 0.2s}
        .call { background-color: transparent ; color: #28a745  ; border: none }
        .call:hover { background-color: #33691E ; color: #000  ; transition: 0.2s }

/*
        .tasting .title {
            position: absolute;
            top: 12px;
            right: 11px;
            padding: 2px;
            text-align: center;
        }

        .title {
            position: absolute;
            top: 12px;
            right: 11px;
            padding: 2px;
            text-align: center;
        }
*/
        .item{
            margin-top : 4px !important;
        }
        .item .clients {
            display: block;
        }

        .item .clients .num {
            background-color: #3e3e3e;
            padding: 1px 5px;
            margin: 0 0px;
            color: #fff;
            border-radius: 50px;
            font-size: 14px;
            margin-right: 2px;
        }

        .dishNumCustomize .clientNum {
            position: absolute;
            /* bottom: -23px; */
            right: 5px;
            padding: 1px 5px;
            background-color: #3e3e3e;
            /* border-radius: 50px; */
            font-size: 14px;
            color: #fff;
            border-radius: 50px;

        }

        .options a {
            color: #fff !important;
        }

        .activeOption {
            background-color: #212121;
        }

        .bill-handle {
            position: absolute;
            top: 0;
            background-color: #fff;
            padding: 4px 16px 8px 4px;
            color: #3e3e3e;
            font-size: 22px;
            left: 0;
            border-radius: 0 0 50px 0;
            z-index: 1;
        }

        .readyDishes {
            padding: 0 10px;
        }

        .readyDishes .col {
            padding-right: 5px;
            padding-left: 5px;
            margin-bottom: 10px;
        }

        .readyDishes .btn {
            position: relative;
        }

        .readyDishes .ready:before{
            content: '\f00c';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            position: absolute;
            top: -1px;
            left: -1px;
            color: #fff;
            background-color: #28a745;
            padding: 2px 12px 8px 4px;
            border-radius: .25rem 0 50px 0;
            font-size: 12px;
        }

        .timer {
            padding: 0 10px;
        }

        .timer .col {
            padding-right: 5px;
            padding-left: 5px;
            margin-bottom: 10px;
        }

        .btn-group.actions {
            display: flex;
        }

        .actions .btn {
            flex: 1 ;
            border: none;
        }

        .card .card-title {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 25px;
            background-color: #fff;
            width: 100%;
            color: #3e3e3e;
        }

        .addedNum {
            background-color: #1976d2;
            padding: 2px 8px;
            margin: 0 4px;
            font-size: 18px;
        }

        .addedNumColor {
            color: #1976d2;
        }

        .deletedNum {
            background-color: #dc3545;
            padding: 2px 8px;
            margin: 0 4px;
            font-size: 18px;
        }

        .deletedNumColor {
            color: #dc3545;
        }
        .nav-item {
            cursor: pointer;
        }




        /* Murri Grid */

        .grid {
            position: relative;
        }

        .card {
            display: block;
            position: absolute;
             width: 210px;
            margin: 5px;
            /* z-index: 1; */
            background: #000;
            color: #fff;
        }
        .card.muuri-item-dragging {
            z-index: 3;
        }
        .card.muuri-item-releasing {
            z-index: 2;
        }
        .card.muuri-item-hidden {
            z-index: 0;
        }
        .card-body {
            position: relative;
            width: 100%;
            height: 100%;
        }


                /* modal */
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}

.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}

.modal-container {
  max-width: 500px;
  margin: 0px auto;
  padding: 20px 30px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
  font-family: Helvetica, Arial, sans-serif;
}

.modal-header h3 {
  margin-top: 0;
  color: #42b983;
}

.modal-body {
  margin: 20px 0;
}

.modal-default-button {
  float: right;
}

/*
 * The following styles are auto-applied to elements with
 * transition="modal" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the modal transition by editing
 * these styles.
 */

.modal-enter {
  opacity: 0;
}

.modal-leave-active {
  opacity: 0;
}

.modal-enter .modal-container,
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
/* ************************************         spinner */


.lds-roller {
  display: inline-block;
  position: absolute;
  width: 64px;
  height: 64px;
  left: 50%;
top: 50%;
}
.lds-roller div {
  animation: lds-roller 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  transform-origin: 32px 32px;
}
.lds-roller div:after {
  content: " ";
  display: block;
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #fff;
  margin: -3px 0 0 -3px;

}
.lds-roller div:nth-child(1) {
  animation-delay: -0.036s;
}
.lds-roller div:nth-child(1):after {
  top: 50px;
  left: 50px;
}
.lds-roller div:nth-child(2) {
  animation-delay: -0.072s;
}
.lds-roller div:nth-child(2):after {
  top: 54px;
  left: 45px;
}
.lds-roller div:nth-child(3) {
  animation-delay: -0.108s;
}
.lds-roller div:nth-child(3):after {
  top: 57px;
  left: 39px;
}
.lds-roller div:nth-child(4) {
  animation-delay: -0.144s;
}
.lds-roller div:nth-child(4):after {
  top: 58px;
  left: 32px;
}
.lds-roller div:nth-child(5) {
  animation-delay: -0.18s;
}
.lds-roller div:nth-child(5):after {
  top: 57px;
  left: 25px;
}
.lds-roller div:nth-child(6) {
  animation-delay: -0.216s;
}
.lds-roller div:nth-child(6):after {
  top: 54px;
  left: 19px;
}
.lds-roller div:nth-child(7) {
  animation-delay: -0.252s;
}
.lds-roller div:nth-child(7):after {
  top: 50px;
  left: 14px;
}
.lds-roller div:nth-child(8) {
  animation-delay: -0.288s;
}
.lds-roller div:nth-child(8):after {
  top: 45px;
  left: 10px;
}
@keyframes lds-roller {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* ********************overlay */
#showspinner {
  position: fixed; /* Sit on top of the page content */
  display: block; /* Hidden by default */
  width: 100%; /* Full width (cover the whole page) */
  height: 100%; /* Full height (cover the whole page) */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5); /* Black background with opacity */
  z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
  cursor: pointer; /* Add a pointer on hover */
}
#hidespinner{
    display:none;
}






</style>
<!----------------placeholder do not remove------------>
<div class="invoices-container"></div>

<!-- audio -->
<audio id="supervisorSound" src="{{ asset('storage/supervisor.mp3')}}"></audio>

<div id="app">


    <supervisor v-bind:user="{{json_encode($user)}}" v-bind:page="'supervisor'" ></supervisor>
</div>



<!--------------------supervisor component------------------------->


<script type="text/x-template"  id="supervisor">

    <div>
    <notifications group="foo" />
    <nav class="navbar topNav sticky-top navbar-dark navbar-expand-lg">
        <!-- PageName -->
        <a class="navbar-brand navbar-nav mr-auto" id="showBreadCrumbs" href="#" style="padding-right: 2rem;">@{{this.$store.state.user.username}}</a>
        <!-- BreadCrumps -->
        <ol class="breadcrumb col-lg-2" style="display: none">
            <li class="breadcrumb-item"><a href="javascript: history.go(-2)">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">@{{this.$store.state.user.username}}</li>
        </ol>
        <!-- links -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#links" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="nav navbar-nav nav-fill w-100" id="links" role="tablist">

            <!----------------------------------components tabs----------------------------------------->
            <li class="nav-item" v-for="tab in tabs" v-bind:key="tab" v-on:click="setcurrenttab(tab)">
                <a class="nav-link " v-bind:class="{active: currentTabComponent===tab}" id="new-order-tab" data-toggle="tab" href="#new-order" role="tab" aria-controls="new-order" aria-selected="true" >@{{tab}}<span class="badge badge-warning badge-warning">@{{numbers[tab]}}</span></a>
            </li>



            <!----------------------------------------------------------------------------------------------->

            <li class="nav-item options " style="border-left: 2px solid #fff">
                <a class="nav-link " @click="showall">@{{this.$store.state.visibiltiy.showall ? 'ShowActive':'ShowAll'}}</a>
            </li>
            <li class="nav-item options">
                <a class="nav-link" @click="hideStation">@{{this.$store.state.visibiltiy.hideStation ? 'Show Station':'Hide Station'}}</a>
            </li>
            <li class="nav-item options">
                <a class="nav-link" @click="hideDishes">@{{this.$store.state.visibiltiy.hideDishes ? 'Show Dishes':'Hide Dishes'}}</a>
            </li>
            <li class="nav-item options">
                <a class="nav-link" @click="showServed">@{{this.$store.state.visibiltiy.showServed ? 'HideServed':'ShowServed'}}</a>
            </li>
            <li class="nav-item options">
                <a class="nav-link"><clock></clock></a>
            </li>
            <li class="nav-item options">
                <a class="nav-link" v-bind:style="{'color':this.$store.state.connected ? '#33691E !important' :'#bd2130 !important'}" @click="refresh"><i class="fas fa-circle"></i></a>
            </li>


        </ul>
    </nav>
    <div v-if="this.$store.state.status === 'working'" id="showspinner" >

    <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    </div>

    <keep-alive>
        <component

           v-bind:is="currentTabComponent"
           class="tab"
        ></component>
    </keep-alive>

    </div>



</script>






<script type="text/x-template"  id="calledcomponent">

        <div  class="supervisor-container" >
          <template v-for="invoice,index in calledOrder">

          <invoice

                 v-bind:invoice="invoice"
                 v-bind:key="invoice.id+invoice.category"
                 v-bind:section="'called'"
                 >

                 </invoice>

          </template>





        </div>



</script>

<script type="text/x-template"  id="tobecalledcomponent">
        <div  class="supervisor-container" >

            <invoice  v-for="(invoice,index) in tobecalledOrder"
                      v-bind:key="invoice.id+invoice.category"
                      v-bind:invoice="invoice"
                      v-bind:section="'tocalled'"

                      ></invoice>
        </div>

</script>
<script type="text/x-template"  id="servedcomponent">
            <div  class="supervisor-container" >

            <invoice  v-for="(invoice,index) in servedOrder"
                      v-bind:key="invoice.id+invoice.category"
                      v-bind:invoice="invoice"
                      v-bind:section="'served'"

                      ></invoice>
        </div>

</script>

<script type="text/x-template"  id="paidcomponent">

        <div  class="supervisor-container" >



        <paidinvoicecomponent  v-for="(invoice,index) in paidInvoices"
                  v-bind:key="index"
                  v-bind:invoice="invoice"
                  v-bind:section="'paid'"


                  ></paidinvoicecomponent>


        </div>

</script>




<!----------------------------------------invoice component------------>

<script type="text/x-template"  id="invoicecomponent">

            <div class="card" v-show="!entireHide"  v-bind:id="type + invo.id" v-bind:class="{'tasting':tasting,'hold-invoice':hold , 'flipped-invoice':flip ,'request-error':error}" >
                <div class="card-body">

                    <span  class="bill-handle" >
                    <i class="order" v-long-press="1000"
                        @long-press-start="shownumpad"></i>
                     <easynumpad  v-if="numpad"  v-bind:invo="invoice" v-on:hidenumpad="hidenumpad"></easynumpad>
                    </span>


                    <h1 class="card-title noMargin text-center">@{{title}}</h1>
                    <!-- <h1 class="card-title noMargin text-center">id:@{{invo.id}}</h1> -->
                    <div class="title">
                        <div class="row">
                            <div class="col text-right">
                                <p class="card-subtitle mb-2 noMargin "> <i class="fas fa-male"></i>@{{invo.waiter}}</p>
                            </div>

                            <div class="col text-right">
                                <p class="card-subtitle noMargin mb-2"> <i class="fas fa-clock"></i> @{{invo.created_at}}</p>
                            </div>
                        </div>
                    </div>


                    <div class="col text-center" style="margin-top: 0.5rem ; padding: 0 ;">
                        <p class="text-warning noMargin warningForUpdateNote addedItem" v-if="changes" >@{{changes.note ? '!! Note Updated !!':'!! Order Updated !!' }}</p>
                        <p class="noMargin">@{{invo.note}}</p>
                    </div>
                    <div class="row" style="margin-top: .5rem" v-if="invo.tastings_header.length">

                        <div class="col text-center">
                            <p class="card-subtitle noMargin mb-2" >
                                <span v-for="(header,index) in invo.tastings_header">@{{header.tasting_count}} @{{header.tasting_name}} <template v-if="index+1 < invo.tastings_header.length" >-</template></span>

                            </p>

                        </div>
                    </div>

                    <hr>
                    <!-----------------------services ------------------------------------>


                    <servicecomponent
                            v-for="service,index in invo.services"
                            v-bind:service="service"
                            v-bind:tasting="tasting"
                            v-bind:index="index"
                            v-bind:key="service.service_number"
                            v-bind:bar="bar"
                            v-bind:type="type"
                            v-bind:hold="hold"
                            v-bind:invoice="invoice"
                            v-on:visibiltyChanged = "invoiceVisibiltyChanged"

                    ></servicecomponent>


                    <!----------------------------------------------end of services------------------->
                    <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_normal.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_normal" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">
                        </div>

                    </div>
                    <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_bar.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_bar" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">

                        </div>

                    </div>

                </div>  <!-- card body --->





                <div class="btn-group btn-block actions" role="group" aria-label="service_2">
                    <template v-if="buttons">
                        <button type="button" class="btn  btn-secondary noBorderRadius" @click="confirm('holding',()=>{sethold()})">@{{hold? 'UnHold':'Hold'}} </button>
                        <button type="button" class="btn  btn-secondary noBorderRadius" style="background-color: #ddd ; color: #3e3e3e ;" @click="setflip">@{{flip ? 'unFlip':'Flip'}}</button>
                        <button type="button" class="btn  btn-secondary noBorderRadius" style="background-color: #eee ; color: #3e3e3e ;" @click="confirm('undo',()=>{undo()})">Undo</button>
                    </template>
                    <template v-else>
                    <!-- <button type="button" class="btn  btn-secondary noBorderRadius" style="background-color: #eee ; color: #3e3e3e ;" >Serve</button>     -->
                    </template>

                </div>


             </div> <!--card -->





</script>


<!-- service component -->
<script type="text/x-template" id="serviceComponent">
    <div        class="service-preperation "

                                v-bind:ref="service.service_number"
                                v-bind:class="{'service-active':service.service_status === 'Called'}"
                                v-show="isServiceVisible"
                                v-bind:id="service.service_number" >

                        <div class="btn-group btn-block" role="group" aria-label="service_2">
                            <button v-if="index && !(service.service_status === 'Called')" type="button" class="btn w-25 merge" v-on:click="confirm('Merge',()=>{serviceCalled(false)})"><i class="fas fa-plus"></i></button>
                            <button type="button" class="btn w-50 serviceNum">#SRV-@{{service.service_number}}</button>:
                            <button v-if="(service.service_status === 'Called')" type="button" class="btn w-25 call" v-on:click="confirm('UnCall',()=>{serviceCalled(false)})">@{{service.call_date}}</button>
                            <button v-if="!(service.service_status === 'Called')" type="button" class="btn w-25 call" v-on:click="confirm('Calling',()=>{serviceCalled(true)})"><i class="fas fa-concierge-bell" ></i></button>


                        </div>

                        <itemcomponent

                            v-for="item,index in service.products"
                            v-bind:item="item"
                            v-bind:tasting="tasting"
                            v-bind:bar="bar"
                            v-bind:srvnumber="service.service_number"
                            v-bind:service_status = "service.service_status === 'Called'"
                            v-bind:invoid = "invoice.id"
                            v-bind:key="index"
                            v-bind:type = "type"
                            v-on:itemVisible = "visibiltyChanged"
                            v-bind:ServeItemsLocal = "ServeItemsLocal"
                        ></itemcomponent>

                    </div>



</script>

<!-- timer  -->


<script type="text/x-template" id="modal-template">
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">

            <slot name="header">
              default header
            </slot>
            <button type="button" class="close" aria-label="Close" @click="$emit('close')">
                        <span aria-hidden="true">&times;</span>
                    </button>
          </div>

          <div class="modal-body">
          <div class="row readyDishes" style="overflow:auto;max-height:150px" >
                        <div class="col" v-for="(dish,index) in dish_number" >
                            <button type="button" class="btn btn-block btn-lg btn-light" v-bind:class="{ready: dish.number == readynum}" @click="servedish(dish)">@{{index+1}}</button>
                        </div>


                    </div>
                    <hr>
                    <div class="row timer">
                        <div class="col text-left" style="margin-top: 1rem">
                            <h4 class="text-secondary"><i class="fas fa-stopwatch"></i> Timer:</h4>
                        </div>
                        <div class="col text-right" style="margin-top: 1rem">
                            <button type="button" class="btn btn-block btn-lg btn-danger" @click="removetimer">Remove Timer</button>
                        </div>
                        <div class="w-100"></div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(5)">5</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(10)">10</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(15)">15</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(20)">20</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(25)">25</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(30)">30</button>
                        </div>
                        <div class="w-100"></div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(35)">35</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(40)">40</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(45)">45</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(50)">50</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(55)">55</button>
                        </div>
                        <div class="col">
                            <button type="button" class="btn btn-block btn-lg btn-secondary" @click="settimer(60)">60</button>
                        </div>
                    </div>
          </div>

          <div class="modal-footer">

          </div>
        </div>
      </div>
    </div>
  </transition>
</script>

<!------------------------------------Item Component------------------------>


<script type="text/x-template" id="itemComponent">
<span v-if="isItemVisibile"  class="singleItem">

  <a

    role="button"
    class="btn item itemWithoutOption"
    v-bind:class="{'servedItem':isServed}"
    v-bind:style="{
      backgroundColor: color,
      color : color === '#ffffff' ? 'black !important':'#ffffff'
      }"

    v-on:click="serveall"
    v-long-press="3000"
    @long-press-start="onLongPressStart()"
    @long-press-stop="onLongPressStop"
  >
    <span
      class="item-qnt"
      data-toggle="tooltip"
      data-placement="top"
      title
      data-original-title="#1 , #2 , #3 , #4 "
    >@{{item.dish_number.length}} @{{tasting ? item.tasting_name : item.short_name}}</span>

    <span v-if="isServed" style="float: right">@{{served_date}}</span>
    <!-- clients -->
    <template v-if="!tasting">

        <span class="clients" >
            <template v-if="mode">
          <span style="display:inline-block" class="num" v-for="(cl,index) in item.clients" v-bind:key="index">@{{cl}}</span>
            </template>

          <span class="deletedNum" v-if="item.deletedNum">@{{item.deletedNum}}</span>
          <span class="addedNum" v-if="item.addedNum">@{{item.addedNum}}</span>
          <span class="addedNum" v-if="item.addedBar">@{{item.addedBar}}</span>
          <span class="deletedNum" v-if="item.deletedBar">@{{item.deletedBar}}</span>
          <span  style="float: right" v-if="timer != '00:00'">@{{timer}}</span>
        </span>


    </template>


    <template v-if="!tasting">
      <!-- <span v-if="item.note">-@{{item.note}}</span> -->
      <template v-for="(opt,index) in item.product_customizes">


        <span
          v-if="opt.options.length"
          v-bind:class="{'customize-itemWithDishNum':opt.dish_number,'customize-item':!opt.dish_number}"
          v-bind:key="index"
        >
          <span class="dishNumCustomize" v-if="opt.dish_number">@{{opt.dish_number}}
                <template v-if="mode">
              <span class="clientNum" v-for="cl in opt.client_number" v-bind:key="cl">@{{cl}}</span>
              </template>
          </span>
          <template v-for="(option, index) in opt.options">
            <span v-bind:key="index">-@{{option.custom_name ? option.custom_name : option.option_name}}</span>
            <template v-if="index + 1 < opt.options.length">
              <br>
            </template>

          </template>
        </span>
      </template>
    </template>



  </a>
   <modal
      v-if = "showmodal"
      v-on:close = "hidedishes"
      v-bind:dish_number = "dishNumber"
      v-bind:ready = "ready"
      v-bind:settimer = "settimer"
      v-bind:removetimer = "removetimer"
      v-bind:servedDishes = "servedDishes"

    ></modal>
    </span>
</script>



<!-- easynumbad -->

<script type="text/x-template" id="numbadComponent">

<div class="easy-numpad-frame" id="easy-numpad-frame">
            <div class="easy-numpad-container">
                <div class="easy-numpad-output-container">
                    <p class="easy-numpad-output" id="easy-numpad-output">New Order:@{{number}}</p>
                </div>
                <div class="easy-numpad-number-container">
                    <table>
                        <tr>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'7')">7</a></td>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'8')">8</a></td>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'9')">9</a></td>
                            <td><a   href="#" class="del numpadbutton" id="del" v-on:click="easy_numpad_del($event)">Del</a></td>
                        </tr>
                        <tr>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'4')">4</a></td>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'5')">5</a></td>
                            <td><a  class="numpadbutton" href="#" v-on:click="easynum($event,'6')">6</a></td>
                            <td><a href="Clear" class="clear numpadbutton" id="clear" v-on:click="easy_numpad_clear($event)">Clear</a></td>
                        </tr>
                        <tr>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'1')">1</a></td>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'2')">2</a></td>
                            <td><a class="numpadbutton" href="#" v-on:click="easynum($event,'3')">3</a></td>
                            <td><a  href="#" class="cancel numpadbutton" id="cancel" v-on:click="easy_numpad_cancel($event)">Cancel</a></td>
                        </tr>
                        <tr>
                            <td colspan="3" v-on:click="easynum($event,'0')"><a class="numpadbutton" href="#">0</a></td>

                            <td><a  href="#" class="done numpadbutton" id="done" v-on:click="easy_numpad_done($event)">Done</a></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

</script>

<!-- paid invoice -->
<script type="text/x-template" id="paidInvoice">
<div class="card"   v-bind:id="'paid'+invo.id"  >
                <div class="card-body">

                    <span  class="bill-handle" >
                    <i

                    >id:@{{invo.id}}-@{{invo.index ? invo.index : ''}}</i>



                </span>
                    <h1 class="card-title noMargin text-center">T:@{{invo.table_number}}</h1>
                    <!-- <h1 class="card-title noMargin text-center">id:@{{invo.id}}</h1> -->
                    <div class="title">
                        <div class="row">
                            <div class="col text-right">
                                <p class="card-subtitle mb-2 noMargin "> <i class="fas fa-male"></i>@{{invo.waiter}}</p>
                            </div>

                            <div class="col text-right">
                                <p class="card-subtitle noMargin mb-2"> <i class="fas fa-clock"></i> @{{invo.created_at}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="fororder">

                        <div style="width: 100%;height: 120px;background: grey;display:table">
                            <h1 style="display: table-cell;vertical-align: middle;text-align: center">Paid</h1>
                        </div>

                    <!-- <div class="col text-center" style="margin-top: 0.5rem ; padding: 0 ;">
                        <p class="text-warning noMargin warningForUpdateNote addedItem" v-if="changes" >@{{changes.note ? '!! Note Updated !!':'!! Order Updated !!' }}</p>
                        <p class="noMargin">@{{invo.note}}</p>
                    </div> -->
                    <!-- <div class="row" style="margin-top: .5rem" v-if="invo.tastings_header.length">

                         <div class="col text-center">
                            <p class="card-subtitle noMargin mb-2" >
                                <span v-for="(header,index) in invo.tastings_header">@{{header.tasting_count}} @{{header.tasting_name}} <template v-if="index+1 < invo.tastings_header.length" >-</template></span>

                            </p>

                        </div>
                    </div> -->

                    <hr>
                    <!-----------------------services ------------------------------------>


                    <!----------------------------------------------end of services------------------->
                    <!-- <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_normal.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_normal" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">
                        </div>

                    </div>
                    <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_bar.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_bar" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">
                        </div>

                    </div> -->
                </div>
                </div>
                <div class="btn-group btn-block actions" role="group" aria-label="service_2">
                    <!-- <button type="button" class="btn  btn-secondary noBorderRadius" @click="sethold">@{{hold? 'UnHold':'Hold'}} </button>
                    <button type="button" class="btn  btn-secondary noBorderRadius" style="background-color: #ddd ; color: #3e3e3e ;" @click="setflip">@{{flip ? 'unFlip':'Flip'}}</button>
                    <button type="button" class="btn  btn-secondary noBorderRadius" style="background-color: #eee ; color: #3e3e3e ;" @click="undo">Undo</button> -->
                </div>


            </div>

</script>



@endsection
