@extends('layouts.master')

@section('extra-js')
    <script src="{{ asset('assets/js/toastify.js') }}" defer></script>
    <script src="{{ asset('assets/js/knockout-min.js') }}" defer></script>
    <script src="{{ asset('assets/js/clipboard.min.js') }}" defer></script>
    <script src="{{ asset('assets/js/materialColor.js') }}" defer></script>
  
@endsection
@section('css')
<link rel="stylesheet" href="{{URL::asset('assets/css/materialColor.css')}}">
@endsection
@section('content')
@include('partials.navbar')
@include('partials.sidebar')


<script type="text/x-template" id="allCtgs">

<div class="contents" >

        <div class="row">
        
        
            <div class="col-lg-3 text-center">
                <div class="card ctg">
                    <div class="card-body">
                        <i class="fas fa-pen-square editCtg" v-on:click="renderOther('newEditCat',74)"></i>

                        <h3>Category #1</h3>

                        <div class="color text-left" style="background-color: #546e7a">
                            <small><span class="font-weight-bold">116</span> Item</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 text-center">
                <div class="card ctg ">
                    <div class="card-body">
                        <i class="fas fa-pen-square editCtg" v-on:click="renderOther('newEditCat',74)"></i>

                        <h3>Category #1</h3>

                        <div class="color text-left" style="background-color: #6d4c41">
                            <small><span class="font-weight-bold">116</span> Item</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 text-center">
                <div class="card ctg">
                    <div class="card-body">
                        <i class="fas fa-pen-square editCtg" v-on:click="renderOther('newEditCat',74)"></i>

                        <h3>Category #2</h3>

                        <div class="color text-left" style="background-color: #7cb342">
                            <small><span class="font-weight-bold">116</span> Item</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 text-center">
                <div class="card ctg">
                    <div class="card-body">
                        <i class="fas fa-pen-square editCtg" v-on:click="renderOther('newEditCat',74)"></i>

                        <h3>Category #3</h3>

                        <div class="color text-left" style="background-color: #fdd835">
                            <small><span class="font-weight-bold">116</span> Item</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 text-center">
                <div class="card ctg">
                    <div class="card-body">
                        <i class="fas fa-pen-square editCtg" v-on:click="renderOther('newEditCat',74)"></i>

                        <h3>Category #4</h3>

                        <div class="color text-left" style="background-color: #e53935">
                            <small><span class="font-weight-bold">116</span> Item</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 text-center" v-on:click="renderOther('newEditCat')">
                <div class="card newCtg">
                    <div class="card-body">

                        <h3 class="text-muted"> New Category </h3>
                        <i class="fas fa-plus newCtgIc"></i>

                    </div>
                </div>
            </div>

        </div>
    </div>
</script>


<script type="text/x-template" id="ctg-edit">

<div class="contents"  >

<div class="row">
    <div class="col-lg-9">
    
    
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-primary saveCtgInfo noBorderRadius" v-on:click="submit">Save</button>
                <button type="button" class="btn btn-danger cancelCtgEdit noBorderRadius" v-on:click="renderOther('allCats')">Cancel</button>
            </div>
            <div class="col text-right">
                <div class="form-group noMargin">
                  <span class="switch switch-sm">
                    <input type="checkbox" class="switch" id="switch-sm" checked>
                    <label for="switch-sm">Active</label>
                  </span>
                </div>
            </div>
        </div>

        <div class="card" style="margin-top: 1rem">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">
                        <input class="form-control form-control-lg noBorderRadius" type="text" value="En Category Name">
                    </div>
                    <div class="col-lg-6">
                        <input class="form-control form-control-lg noBorderRadius" type="text" value="Fr Category Name">
                    </div>
                </div>
                <div class="row" style="margin-top: 1rem">
                    <div class="col-lg-6">
                        <div class="row">
                        
                        
                        
                        
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius d-inline-block" type="text" value="I34FDHVJKC-556">
                            </div>
                            
                            
                            <div class="col text-right">
                                <div class="dropdown d-inline-block">
                                    <button class="btn btn-secondary noBorderRadius dropdown-toggle btn-lg " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        ERP Warehouse
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    <div class="col-lg-6">

                        <div class="row">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text noBorderRadius text-white border-0"  v-bind:style="{'background-color':form.color}" data-toggle="modal" data-target="#colors"><i class="fas fa-palette"></i></div>
                                    </div>
                                    <input type="text" class="form-control noBorderRadius border-0" id="" v-model="form.color">
                                </div>
                            </div>
                            <div class="col text-right">
                                <button type="button" class="btn btn-light noBorderRadius btn-lg">Reset Color</button>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row" style="margin-top: 1rem">

                    <div class="col-lg-12">
                        <div class="custom-control custom-checkbox mr-sm-2">
                            <input type="checkbox" class="custom-control-input" id="limitTimeForThisCategoryEdit" onchange="limitTimeValue(event)">
                            <label class="custom-control-label" for="limitTimeForThisCategoryEdit">Limit Time For This Category ?</label>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div data-picktime="limitTimeForThisCategoryEdit" hidden>
                            <div class="row" style="margin-top: 1rem">
                                <div class="col-lg-6">
                                    <input class="form-control form-control-lg noBorderRadius startCtg" type="text" placeholder="Start From">
                                </div>

                                <div class="col-lg-6">
                                    <input class="form-control form-control-lg noBorderRadius endCtg" type="text" placeholder="End ..">
                                </div>
                            </div>

                        </div>
                    </div>


                </div>
            </div>
        </div>

        <div class="card" style="margin-top: 1rem">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Customize Group</h4>
                    </div>
                    <div class="col-lg-6 text-right">
                        <div class="dropdown d-inline-block">
                            <a class="btn btn-light dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Add Customize Group
                            </a>

                            <div class="dropdown-menu allCustomizeGroup">
                                <a class="dropdown-item" href="#" data-cg-name="Customize Group #7" data-name="Customize Group #7" v-on:click="addCustomGroup($event)">Customize Group #7</a>
                                <a class="dropdown-item" href="#" data-cg-name="Customize Group #8" data-name="Customize Group #8" v-on:click="addCustomGroup($event)">Customize Group #8</a>
                                <a class="dropdown-item" href="#" data-cg-name="Customize Group #9" data-name="Customize Group #9" v-on:click="addCustomGroup($event)">Customize Group #9</a>
                                
                            </div>
                        </div>

                        <button type="button" class="btn btn-link d-inline-block">Create Customize Group</button>

                    </div>
                </div>
                <hr>
                <div class="customizeGroupForThisCategory" id="CGForEditCtg">
                    <a class="btn btn-light customizeGroupBtn" href="#" role="button" v-for="cuGroup in form.customizeGrop">@{{cuGroup}} <i class="fas fa-times-circle"></i></a>
                    

                </div>

            </div>
        </div>

        <button type="button" class="btn btn-danger cancelCtgEdit noBorderRadius" style="margin-top: 2rem"><i class="fas fa-trash-alt"></i> Delete This Category ?</button>

    </div>
    <div class="col-lg-3">


        <h4>Subcategories</h4>

        <div class="list-group itemGroup-list">
            <a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#itemGroup" v-for="sub in form.subcats">@{{sub}} <i class="fas fa-times-circle" ></i></a>
           
        </div>

        <input class="form-control form-control-lg noBorderRadius addItemGroupInput" style="margin-top: 1rem" type="text" placeholder="Add New Item Group" v-model="subcat">
        <button type="button" class="btn btn-primary noBorderRadius addItemGroup" style="margin-top: 1rem" v-on:click="addSub($event)">Add Subcategory</button>
    </div>
</div>

<!-- Color Palette -->
<div class="modal fade" id="colors" tabindex="-1" role="dialog" aria-labelledby="colors" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background-color: transparent; width: max-content;">
                <div class="material-color-picker">
                    <div class="material-color-picker__left-panel">
                        <ol class="color-selector" >
                            <li v-for="(color,index) in colors">
                                <input name="material-color" type="radio" v-bind:value="color.color" v-bind:id="'material'+index" v-on:click="chooseColor($event,index)">
                                <label v-bind:for="'material'+index" title="color" v-bind:style="{'color':color.variations[4].hex}"></label>
                            </li>
                        </ol>
                    </div>
                     <div class="material-color-picker__right-panel" >
                        <div class="color-palette-wrapper" v-bind:class="'js-active'" >
                            <h2 class="color-palette-header" ></h2>
                            <ol class="color-palette" >
                                <li id="clipboardItem" class="color-palette__item" v-for="vari in variations" v-bind:style="{'background-color':vari.hex}" v-on:click="pickupColor($event,vari.hex)">
                                    <span >@{{vari.weight}}</span>
                                    <span >@{{vari.hex}}</span>
                                    <span class="copied-indicator" >Color copied!</span>
                                </li>
                            </ol>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>


</div>

</script>

<div id="app">

    

</div>




@endsection