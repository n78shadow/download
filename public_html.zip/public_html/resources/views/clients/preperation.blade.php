@extends('layouts.master')

@section('title','UPOS | Preperation')

@section('extra-js')

    <script src="{{ asset('js/supervisor/supervisor.js?9') }}" defer></script>


@endsection

@section('extra-head-js')

            <script src="{{ asset('js/app.js?9') }}" defer></script>
            <script src="{{ asset('js/masonry.pkgd.min.js') }}" defer></script>

@endsection

@section('css')

@endsection

@section('content')
<style>
       body{
            background-color: #212121 !important;
        }

        .contents {
            margin: .5rem !important;
        }

        .card {
            background-color: transparent;
            border: 2px solid #fff;
            color: #fff !important;
            width: 150px;
            margin-bottom: 4px;
        }

        .card .card-body{
            padding:.75rem;
            position:relative;

        }

        .card .card-title{
            margin-top: -.5rem !important;
            margin-bottom: 2rem !important;
        }


        .item {
            background-color: transparent !important;
            color: #fff;
            //border: 2px solid #fff;
            font-size: 20px;
            margin: 0;
        }

        .item-qnt {
            font-size: 20px;
            /* font-weight: bold; */
            padding: 0px 2px 0px 0px;
            margin-right: 4px;

        }


        .tasting .item  .item-qnt{
            font-size: 12px !important;
            margin-right: 0 !important;
        }


        /*
        @media screen and (max-width: 18in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 14% !important ;}
        }

        @media (min-width: 22in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 10% !important; }
        }​

        @media (min-width: 26in)  {
            .invoice-size,
            .card { margin-top: 4px ; width: 6% !important; }
        }​

        @media screen and (min-width: 30in) {
            .invoice-size,
            .card { margin-top: 4px ; width: 1% !important; }
        }
        */

        @media (min-width: 128em)  {

            //.invoice-size,
            //.card { margin-top: 4px ; width:7% !important; }

        }​ ;

        .invoices-container {
            margin: 1rem ;
        }

        .service-preperation {
            opacity: 0.4;
            margin-bottom: 1rem;
        }

        .service-preperation h4 {
            margin: 0;
        }

        .service-preperation .item {
            display: block;
            text-align: left;
        }

        .service-active {
            opacity: 1 !important;
        }

        hr {
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .deletedItem {
            opacity: 0.5;
            font-size:16px;
            padding: 5px 5px 5px 30px !important;
        }

        .deletedItem:after {
            content: '\f2ed';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            position: absolute;
            left: 7px;
        }

        .addedItem {
            position: relative;
            cursor: pointer;
            box-shadow: 0 0 0 0 rgba(255,255,255,0.4);
            -webkit-animation: pulse 1.5s infinite;
        }

        .addedItem:hover {
            -webkit-animation: none;
        }

        @-webkit-keyframes pulse {
            0% {
                -moz-transform: scale(0.95);
                -ms-transform: scale(0.95);
                -webkit-transform: scale(0.95);
                transform: scale(0.95);
            }
            70% {
                -moz-transform: scale(1);
                -ms-transform: scale(1);
                -webkit-transform: scale(1);
                transform: scale(1);
                box-shadow: 0 0 0 6px rgba(90, 153, 212, 0);
            }
            100% {
                -moz-transform: scale(0.95);
                -ms-transform: scale(0.95);
                -webkit-transform: scale(0.95);
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(90, 153, 212, 0);
            }
        }

        .served-dishes {
            //display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .1rem;
            padding-top: .1rem;
            font-size: 16px;
        }

        .customize-item {
            display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .2rem;
            padding-left: .4rem;
            padding-top: .2rem;
            font-size: 14px;
        }

        .customize-itemWithDishNum {
            display: block;
            text-align: left;
            border-top: 1px solid rgba(0,0,0,0.1);
            margin-top: .2rem;
            padding-left: 1.4rem;
            padding-top: .2rem;
            font-size: 14px;
        }

        .dishNumCustomize {
            background-color: rgba(0,0,0,0.4);
            padding: 2px 8px;
            margin-left: -1.4rem;
        }

        .title {
            //position: absolute;
            //top: 0;
            //right: 0.5rem;
            margin-top: 1.5rem;
        }

        .title .col {
            margin-top: .2rem;
        }


        .tasting {
            border : 2px solid #33691E !important;
        }

        .tasting  .card-title, .tasting .invNo{
            border-color :  #33691E !important;
        }

        .tasting a {
            font-size: 14px;
            display: inline-block !important;
            margin: 2px 0 0 0;
            border: 2px solid #33691E !important;
            /* width: 30%; */
            text-align: center;
            margin-top: 2px !important;
        }

        .servedItem {
            opacity: 0.5;
            text-decoration: line-through !important;
        }


        .addedNum {
            background-color: #1976d2;
            padding: 2px 8px;
            margin: 0 4px;
            font-size: 18px;
        }

        .addedNumColor {
            color: #1976d2;
        }

        .deletedNum {
            background-color: #dc3545;
            padding: 2px 8px;
            margin: 0 4px;
            font-size: 18px;
        }

        .deletedNumColor {
            color: #dc3545;
        }

        .kitchenDots {
            position: absolute;
            left: .4rem;
            top: 1.4rem;
        }


        .kitchenDots .dot:after {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin: 2px;
            font-size: 12px;
        }

        .invoices-container {
            margin: 0 auto;
        }

        /* over write */
        .card h2 {
            font-size: 1.8rem;
        }

        .notes {
            margin-top: .5rem ;
            padding: 0 !important;
        }

        .itemWithoutCustomize {
            margin-top: -1rem;
        }

        .tatsetitle {
            padding: 0;
        }

        .card .card-title {
            position: absolute;
            top: 7px;
            right: 0;
            font-size: 25px;
            background-color: #212121;
            width: 100%;
            color: #fff;
            height: 37px;
            padding: 0 .5rem;
            border-bottom: 2px solid ;
        }

        .invNo{
            position: absolute;
            top: -4px;
            right: -2px;
            font-size: 15px;
            color: #fff;
            padding: .5rem;
            border: 2px solid #fff;
            border-top: none;
            border-bottom: none;
        }

        .counter {
            background-color: #151515;
            padding: .5rem;
            position: fixed;
            bottom: 0;
            width: 100%;
            color : #fff ;
        }

        .counter .item {
            border : 2px solid #fff ;
            margin : 2px ;
        }

        .counter .tastingItem {
            border : 2px solid #33691E ;
            margin : 2px ;
        }
        /* ************************************         spinner */


.lds-roller {
  display: inline-block;
  position: absolute;
  width: 64px;
  height: 64px;
  left: 50%;
top: 50%;
}
.lds-roller div {
  animation: lds-roller 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  transform-origin: 32px 32px;
}
.lds-roller div:after {
  content: " ";
  display: block;
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #fff;
  margin: -3px 0 0 -3px;

}
.lds-roller div:nth-child(1) {
  animation-delay: -0.036s;
}
.lds-roller div:nth-child(1):after {
  top: 50px;
  left: 50px;
}
.lds-roller div:nth-child(2) {
  animation-delay: -0.072s;
}
.lds-roller div:nth-child(2):after {
  top: 54px;
  left: 45px;
}
.lds-roller div:nth-child(3) {
  animation-delay: -0.108s;
}
.lds-roller div:nth-child(3):after {
  top: 57px;
  left: 39px;
}
.lds-roller div:nth-child(4) {
  animation-delay: -0.144s;
}
.lds-roller div:nth-child(4):after {
  top: 58px;
  left: 32px;
}
.lds-roller div:nth-child(5) {
  animation-delay: -0.18s;
}
.lds-roller div:nth-child(5):after {
  top: 57px;
  left: 25px;
}
.lds-roller div:nth-child(6) {
  animation-delay: -0.216s;
}
.lds-roller div:nth-child(6):after {
  top: 54px;
  left: 19px;
}
.lds-roller div:nth-child(7) {
  animation-delay: -0.252s;
}
.lds-roller div:nth-child(7):after {
  top: 50px;
  left: 14px;
}
.lds-roller div:nth-child(8) {
  animation-delay: -0.288s;
}
.lds-roller div:nth-child(8):after {
  top: 45px;
  left: 10px;
}
@keyframes lds-roller {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
        /* ********************overlay */
#showspinner {
  position: fixed; /* Sit on top of the page content */
  display: block; /* Hidden by default */
  width: 100%; /* Full width (cover the whole page) */
  height: 100%; /* Full height (cover the whole page) */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5); /* Black background with opacity */
  z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
  cursor: pointer; /* Add a pointer on hover */
}
#hidespinner{
    display:none;
}


</style>

<!----------------placeholder do not remove------------>
<div class="supervisor-container"></div>
        <!-- audio -->
<audio id="preperationSound" src="{{ asset('storage/Kitchen.mp3')}}"></audio>



<div id="app">
    <supervisor v-bind:user="{{json_encode($user)}}" v-bind:page="'preperation'"></supervisor>
</div>


<!-- called -->

<script type="text/x-template"  id="calledcomponent">
    <div>
        <div  class="invoices-container" style="margin-bottom:200px">


          <template v-for="(invoice,index) in calledOrder" >
                <invoice

                        v-bind:invoice="invoice"
                        v-bind:key="invoice.id+invoice.category"
                        v-bind:section = "'called'"



                ></invoice>

          </template>

        </div>




 </div>



</script>

<script type="text/x-template"  id="supervisor">
    <div>

         <called ></called>
         <counter></counter>

    <div v-if="this.$store.state.status === 'working'" id="showspinner" >

    <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    </div>

    </div>
</script>



<script type="text/x-template" id="invoicecomponent">
    <div class="card" v-show="!entireHide && !hold"  v-bind:id="type + invo.id"   v-bind:class="{'tasting':tasting,'hold-invoice':hold , 'flipped-invoice':flip}" >
            <div class="card-body">
                <h2 class="card-title noMargin">@{{invo.table_number.match(/^\d+$/) ? 'T':'O'}} : @{{invo.table_number.match(/^\d+$/) ? invo.table_number: invo.table_number.replace('take-out','')}}</h2>
                <span class="kitchenDots" v-if="otherKitchen">
				<span v-for="kitchen in otherKitchen" class="dot" v-bind:style="{color: kitchen.color}"></span>


				</span>
                <span class="invNo order"></span>
                <div class="title">
                    <div class="row">
                        <div class="col text-left">
                            <p class="card-subtitle mb-2 noMargin "> @{{invo.waiter}} </p>
                        </div>
                        <div class="col text-right">
                            <p class="card-subtitle noMargin mb-2"> @{{invo.created_at}}</p>
                        </div>

                    </div>
                </div>
                <div class="col notes text-center">
                    <p class="text-warning noMargin warningForUpdateNote addedItem" v-if="changes">@{{changes.note ? '!! Note Updated !!':'!! Order Updated !!' }}</p>
                    <p class="noMargin">@{{invo.note}}</p>
                </div>

                <div class="row" style="margin-top: .2rem" v-if="invo.tastings_header.length">

                        <div class="col text-center tatsetitle">
                            <p class="card-subtitle noMargin mb-2" >
                                <span v-for="(header,index) in invo.tastings_header">@{{header.tasting_count}} @{{header.tasting_name}} <template v-if="index+1 < invo.tastings_header.length" >-</template></span>

                            </p>

                        </div>
                </div>


                <hr>
                <servicecomponent
                            v-for="service,index in invo.services"
                            v-bind:service="service"
                            v-bind:tasting="tasting"
                            v-bind:index="index"
                            v-bind:bar="bar"
                            v-bind:type="type"
                            v-bind:hold="hold"
                            v-bind:key="index"
                            v-bind:invoice="invoice"
                            v-on:visibiltyChanged = "invoiceVisibiltyChanged"

                > </servicecomponent>
                <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_normal.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_normal" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">
                        </div>

                    </div>
                    <div class="row" style="margin-top: 1rem" v-if="invo.permDeleted_bar.length">
                        <div class="col">
                            <h4 class="">Deleted</h4>
                            <a v-for="deleted in invo.permDeleted_bar" role="button" class="btn item itemWithoutOption deletedItem" style="background-color: #546e7a ; display: block"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 "></span>@{{deleted.deleted_count}}- @{{deleted.product_name}}</a>
                        </div>
                        <div class="w-100">
                        </div>

                    </div>
            </div>
        </div>
    </script>

    <!-- item -->

<script type="text/x-template" id="itemComponent">
<span v-if="isItemVisibleKitchen"  class="singleItem">
<a  v-bind:class="{'servedItem':isServed || isReady }" role="button" class="btn item itemWithoutOption singleItem" v-bind:style="{'border-color': borderColor ? borderColor + '!important' : 'transparent'}"><span class="item-qnt" data-toggle="tooltip" data-placement="top" title="" data-original-title="#1 , #2 , #3 , #4 ">@{{item.dish_number.length}} @{{tasting ? item.tasting_name : item.short_name}}</span>


                    <span style="display: block ; font-size: 18px" v-if="!tasting">
								<span class="addedNum" v-if="item.addedNum">@{{item.addedNum}}</span>
                                <span class="deletedNum" v-if="item.deletedNum">@{{item.deletedNum}}</span>
                                <span class="addedNum" v-if="item.addedBar">@{{item.addedBar}}</span>
                                <span class="deletedNum" v-if="item.deletedBar">@{{item.deletedBar}}</span>
                                <span  style="float: right;margin:-8px" v-if="timer != '00:00'">@{{timer}}</span>

							</span>
                    <template v-if="!tasting">
                        <template v-for="opt,index in item.product_customizes">
                            <span   v-if="opt.options.length" v-bind:class="{'customize-itemWithDishNum':opt.dish_number,'customize-item':!opt.dish_number}">
                                <span class="dishNumCustomize" v-if="opt.dish_number" >@{{opt.dish_number}}</span>
                                <template v-for="(option, index) in opt.options">
                                    <span>-@{{option.custom_name ? option.custom_name : option.option_name }}</span><template v-if="index + 1 < opt.options.length"><br></template>
                                </template>
                            </span>


                        </template>
                    </template>


                    </a>
                    </span>

</script>


<!-- service component -->
<script type="text/x-template" id="serviceComponent">
    <div  class="service-preperation " v-bind:ref="service.service_number" v-bind:class="{'service-active': status }" v-bind:id="service.service_number" data-drop-target="true" v-show="isServiceVisibleKitchen" >
                    <h3>#svr-@{{service.service_number}}</h3>
                    <itemcomponent
                            ref="item"
                            v-for="item,index in service.products"
                            v-bind:item="item"
                            v-bind:tasting="tasting"
                            v-bind:bar="bar"
                            v-bind:srvnumber="service.service_number"
                            v-bind:service_status = "service.service_status === 'Called'"
                            v-bind:invoid = "invoice.id"
                            v-bind:key="index"
                            v-bind:type = "type"
                            v-on:itemVisible = "visibiltyChanged"
                    ></itemcomponent>


                </div>



</script>


@endsection
