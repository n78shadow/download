<?php //dd($items); ?>
@extends('layouts.master')


@section('title','UPOS | Items')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">@lang('items.customize_groups')</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item active">Items</li>
@endsection
@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection
@section('content')
@include('partials.navbar')
@include('partials.sidebar')

<style>

    .itemInCtg{
        border: none;
    }

    .categoryColor {
        position: absolute;
        width: 2.2rem;
        height: 100%;
        top: 0;
        left: 0;
    }

    .itemNumber{
        position: absolute;
        left: 0.8rem;
        top: 50%;
        color: #fff;
        font-size: 25px;
        transform: translate( 0 , -50%);
    }

    .itemEditBtn{
        position: absolute;
        top: 0;
        right: 0;
        padding: 15px;
        font-size: 22px;
        color: #ccc;
    }

    .itemGroupBtn {
        margin: 5px;
    }

    .itemGroupBtn i {
        color: #dc3545;
        padding: 4px 6px;
        margin: 0px -10px 0px 5px;
    }

    .basicOptionalBtn i {
        color: #dc3545;
        padding: 4px 6px;
        margin: 0px -10px 0px 5px;
    }

    .sortable-ghost {
        border: 2px dashed #eee;
    }

    /* For tab Function */
    .tabcontent {
        animation: fadeEffect 1s; /* Fading effect takes 1 second */
    }

    /* Go from zero to full opacity */
    @keyframes fadeEffect {
        from {opacity: 0;}
        to {opacity: 1;}
    }


</style>


<div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
    <div class="card border-0 noBorderRadius">
        <div class="card-body">
            <div class="row">
                <div class="col text-left" id="myBtnFilter">
                    <!--<button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links" onclick="filterTabElement(event, 'all')">All</button>-->
                    <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links" onclick="filterTabElement(event, 'items-filter')">@lang('items.items')</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links" onclick="filterTabElement(event, 'items-bar')">@lang('items.bar_items')</button>
                </div>
                <div class="col text-right">
                    <a href="{{ route('items.create') }}" class="btn btn-primary noBorderRadius border-0" id="addNewItem" style="background-color: #546e7a">@lang('items.add_new_item')</a>

                    <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" hidden>@lang('items.cancel')</button>
                    <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" hidden>@lang('items.add')</button>
                </div>
            </div>
            <div class="row">
                <div class="col" style="margin-top: 1rem">
                    <select type="text" class="form-control itemsSelect" name="product_id" style="width: 100%!important;"></select>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="contents" id="allItems" style="margin: 0 3rem 2rem 6rem !important;">

    <!-- Tabs  -->
    <!-- All item
    <div id="all" class="tab-filter-content">

    </div>
    -->
    <!-- All item Without Bar -->
    <div id="items-filter" class="tab-filter-content">
        <div class="card-columns" id="itemsList">
            @forelse($items as $item)
                <div class="card itemInCtg noBorderRadius">
                    <div class="card-body" style="padding: 1rem 1rem 1rem 3rem;">
                        <h5 class="card-title">{{ $item["en_name"] }}</h5>
                        <a id="route{{ $item["id"] }}" href="{{ route('items.edit',$item["id"]) }}">
                            <i class="fas fa-pen-square itemEditBtn"></i>
                        </a>
                        <span class="categoryColor" style="background-color: #546e7a"></span>
                        <span class="itemNumber align-middle">1</span>
                        <div class="row">
                            <div class="col">
                                <h6 class="card-subtitle noMargin text-muted">{{ '#'.$item["id"] }}</h6>
                            </div>
                            <div class="col text-right">
                                <h6 class="card-subtitle noMargin text-muted">{{ ($item["limit_quantity"] == 0 || $item["limit_quantity"] == null) ? "unlimited" : $item["limit_quantity"] }}</h6>
                            </div>
                        </div>
                        <div class="row itemDetails" hidden>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.dscription')</h6>
                                <h6 class="noMargin text-muted">{{ $item["description"] }}</h6>
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="card-subtitle noMargin text-muted">{{ $item["cost"].'$' . ' / ' . $item["price"].'$' . ' / ' . $item["delivery_price"].'$'  }}</h6>
                                <h6 class="noMargin">@lang('items.discount_limit') {{ $item["limit_discount"] ? $item["limit_discount"].'%' : 'No Limit' }}</h6>
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                @if($item["is_taxed"] == "yes")
                                    <h6 class="noMargin text-danger">{{ $item['price'] }}$</h6>
                                @else
                                    <h6 class="noMargin text-warning">@lang('items.no_tax')</h6>
                                @endif

                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.categories')</h6>
                                @forelse($item['categories'] as $category)
                                    <span class="badge badge-secondary">{{ $category['en_name'] }}</span>
                                @empty
                                    <span class="badge badge-light">@lang('items.no_categories')</span>
                                @endforelse
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.item_group')</h6>
                                @forelse($item['customize_groups'] as $group)
                                    <span class="badge badge-secondary">{{ $group['group_name'] }}</span>
                                @empty
                                    <span class="badge badge-light">@lang('items.no_groups')</span>
                                @endforelse
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.basics')</h6>
                                @if(isset($item["basics"]))
                                    @forelse($item["basics"] as $basic)
                                        <span class="badge badge-light">{{ $basic["basic_name"] }}</span>
                                    @empty
                                        <span class="badge badge-light">@lang('items.no_basics')</span>
                                    @endforelse
                                @endif
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.options')</h6>
                                @if(isset($item["optionals"]))
                                    @forelse($item["optionals"] as $optional)
                                        <span class="badge badge-light">{{ $optional["option_name"] }}</span>
                                    @empty
                                        <span class="badge badge-light">@lang('items.no_options')</span>
                                    @endforelse
                                @endif

                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <p>@lang('items.no_items')</p>
            @endforelse
        </div>
    </div>

    <!-- All item  bar-->
    <div id="items-bar" class="tab-filter-content">
        <div class="card-columns" id="itemsList">
            @forelse($bar_items as $item)
                <div class="card itemInCtg noBorderRadius">
                    <div class="card-body" style="padding: 1rem 1rem 1rem 3rem;">
                        <h5 class="card-title">{{ $item["en_name"] }}</h5>
                        <a href="{{ route('items.edit',$item["id"]) }}">
                            <i class="fas fa-pen-square itemEditBtn"></i>
                        </a>
                        <span class="categoryColor" style="background-color: #546e7a"></span>
                        <span class="itemNumber align-middle">1</span>
                        <div class="row">
                            <div class="col">
                                <h6 class="card-subtitle noMargin text-muted">{{ '#'.$item["id"] }}</h6>
                            </div>
                            <div class="col text-right">
                                <h6 class="card-subtitle noMargin text-muted">{{ ($item["limit_quantity"] == 0 || $item["limit_quantity"] == null) ? "unlimited" : $item["limit_quantity"] }}</h6>
                            </div>
                        </div>
                        <div class="row itemDetails" hidden>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.description')</h6>
                                <h6 class="noMargin text-muted">{{ $item["description"] }}</h6>
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="card-subtitle noMargin text-muted">{{ $item["cost"].'$' . ' / ' . $item["price"].'$' . ' / ' . $item["delivery_price"].'$'  }}</h6>
                                <h6 class="noMargin">@lang('items.discount_limited') {{ $item["limit_discount"] ? $item["limit_discount"].'%' : 'No Limit' }}</h6>
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                @if($item["is_taxed"] == "yes")
                                    <h6 class="noMargin text-danger">{{ $item['price'] }}$</h6>
                                @else
                                    <h6 class="noMargin text-warning">@lang('items.no_tax')</h6>
                                @endif

                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">Categories</h6>
                                @forelse($item['categories'] as $category)
                                    <span class="badge badge-secondary">{{ $category['en_name'] }}</span>
                                @empty
                                    <span class="badge badge-light">@lang('items.no_categories')</span>
                                @endforelse
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.item_group')</h6>
                                @forelse($item['customize_groups'] as $group)
                                    <span class="badge badge-secondary">{{ $group['group_name'] }}</span>
                                @empty
                                    <span class="badge badge-light">@lang('items.no_groups')</span>
                                @endforelse
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.')Basics</h6>
                                @if(isset($item["basics"]))
                                    @forelse($item["basics"] as $basic)
                                        <span class="badge badge-light">{{ $basic["basic_name"] }}</span>
                                    @empty
                                        <span class="badge badge-light">@lang('items.no_basics')</span>
                                    @endforelse
                                @endif
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <hr>
                                <h6 class="noMargin">@lang('items.options')</h6>
                                @if(isset($item["optionals"]))
                                    @forelse($item["optionals"] as $optional)
                                        <span class="badge badge-light">{{ $optional["option_name"] }}</span>
                                    @empty
                                        <span class="badge badge-light">@lang('items.no_options')</span>
                                    @endforelse
                                @endif

                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <p>@lang('items.no_items')</p>
            @endforelse
        </div>
    </div>



</div>

@endsection



@section('extra-js')
    <!--\\ items Function \\-->
    <!-- Show All Details When Click On item -->
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script>
        $(".itemInCtg").click(function(){
            //$(".itemDetails").removeClass("display-block");
            $(this).find(".itemDetails").toggleClass("display-block");
            //alert(1);
        });

        //limit Item
        function limitItem() {
            if($('#limitThisItem').is(":checked")) {
                //alert(1);
                $("#showlimitItemInput").addClass("display-block");
            }
            else {
                $("#showlimitItemInput").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItem() {
            if($('#discountLimit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInput").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInput").removeClass("display-block");
            }
        }

        //limit Item In Edit
        function limitItemInEdit() {
            if($('#limitThisItemInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitItemInputInEdit").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItemInEdit() {
            if($('#discountLimitInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInputInEdit").removeClass("display-block");
            }
        }

    </script>

    <script>
        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <!-- Add item Group -->
    <script>
        $(".allItemGroup a").click(function(){
            var itemGroupName = $(this).data("item-name") ;
            $(this).parents().find(".ItemGroupForThisItem").append('<a class="btn btn-light itemGroupBtn" href="#" role="button"> '+itemGroupName+' <i class="fas fa-times-circle"></i></a>');
        })
    </script>

    <!-- Remove item Group -->
    <script>
        $(document).on('click', '.itemGroupBtn .fa-times-circle', function(){
            $(this).parent().remove();
            Toastify({
                text: " @lang('items.item_group') <span class='font-weight-bold'> @lang('items.removed') </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        })
    </script>

    <!-- Add Basic & Optional -->
    <script>
        //add Basic to New Item
        $(".addBasicToNewItem").click(function(){
            //$(this).parent().remove();
            var basicInputValue = $(".addBasicToNewItemInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(basicInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error') </span> @lang('items.cant_add_empty_basic')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parents().find(".newItemBasics").append('<button type="button" class="btn btn-light basicOptionalBtn"> '+basicInputValue+' <i class="fas fa-times-circle"></i></button>');
                $(".addBasicToNewItemInput").val("");
            }
        });

        //add Optional to New Item
        $(".addOptionalToNewItem").click(function(){
            //$(this).parent().remove();
            var OptionalInputValue = $(".addOptionalToNewItemInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(OptionalInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error') </span> @lang('items.cant_add_empty_option')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parents().find(".newItemOptional").append('<button type="button" class="btn btn-light basicOptionalBtn"> '+OptionalInputValue+' <i class="fas fa-times-circle"></i></button>');
                $(".addOptionalToNewItemInput").val("");
            }
        });

        //remove Basic & Optional After Add it
        $(document).on('click', '.basicOptionalBtn i', function(){
            $(this).parent().remove();
            Toastify({
                text: "<span class='font-weight-bold'> @lang('items.removed') </span> @lang('items.from_item')",
                duration: 6000,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        });
    </script>

    <!-- Sortable -->
    <script>
        // Simple list
        Sortable.create(itemsList, {
            animation: 150,
            ghostClass: "sortable-ghost",  // Class name for the drop placeholder
            chosenClass: "sortable-chosen",  // Class name for the chosen item
            dragClass: "sortable-drag",  // Class name for the dragging item

            scroll: true, // or HTMLElement
            scrollSensitivity: 30, // px, how near the mouse must be to an edge to start scrolling.
            scrollSpeed: 10, // px

            onEnd: function (/**Event*/evt) {
                $(".itemInCtg").each(function(i) {
                    $(this).find(".itemNumber").text(++i);
                });
            }
        });
    </script>

    <!-- Tab filter Finction -->
    <script>
        function filterTabElement(evt, cityName) {
            // Declare all variables
            var i, tabcontent, tablinks;

            // Get all elements with class="tabcontent" and hide them
            tabcontent = document.getElementsByClassName("tab-filter-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            // Get all elements with class="tablinks" and remove the class "active"
            tablinks = document.getElementsByClassName("tab-filter-links");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }

            // Show the current tab, and add an "active" class to the button that opened the tab
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        function searchingFor()
        {
            var url = '{{ route('items.search') }}';
            if(url == '')
            {
                return;
            }
            $('.itemsSelect').select2({
                placeholder: "@lang('items.search_keyword')",
                minimumInputLength: 2,
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor();

        $('.itemsSelect').on('select2:select', function (event) {
            var item_id = $(event.currentTarget).find("option:selected").val();
            var url = '{!!  route('items.edit','@id@')  !!}';
            url = url.replace("@id@", item_id);
            var text = $(event.currentTarget).find("option:selected").text();

            window.location.href = url;
        });
    </script>

@endsection
