<?php //dd($item); ?>
@extends('layouts.master')


@section('title','UPOS | Items')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">@lang('items.customize_groups')</a>
    </li>
@endsection
@section('page-links')
<li class="breadcrumb-item"><a href="{{ route('items.index') }}">Items</a></li>
<li class="breadcrumb-item active">Update Item</li>
@endsection

@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>

        .itemInCtg{
            border: none;
        }

        .categoryColor {
            position: absolute;
            width: 2.2rem;
            height: 100%;
            top: 0;
            left: 0;
        }

        .itemNumber{
            position: absolute;
            left: 0.8rem;
            top: 50%;
            color: #fff;
            font-size: 25px;
            transform: translate( 0 , -50%);
        }

        .itemEditBtn{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #ccc;
        }

        .itemGroupBtn {
            margin: 5px;
        }

        .itemGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .basicOptional i, .basicOptionalBtn i{
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .sortable-ghost {
            border: 2px dashed #eee;
        }

    </style>
    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">@lang('items.all_items') <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;" hidden>@lang('items.update_item') {{ $item["en_name"] }}</span></h3>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" >@lang('items.cancel')</button>
                        <button type="button" class="btn btn-primary noBorderRadius" onclick="SubmitForm('forms_UpdateItem')" id="saveNewItem" style="background-color: #546e7a">@lang('items.update_item') </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents" id="editItem" style="margin: 0 3rem 2rem 6rem !important;" >
        <form action="{{ route('items.update',$item["id"]) }}" method="POST" id="forms_UpdateItem" enctype="multipart/form-data">
            @csrf
            @method('PUT')
        <div class="row">
            <div class="col-lg-8">
                <!-- Item Information  -->
                <div class="card">
                    <div class="card-body">
                        <!-- Item Name -->
                        <div class="row">
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="@lang('items.en_item_name')" name="en_name" value="{{ $item["en_name"] }}">
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="@lang('items.fr_item_name')" name="fr_name" value="{{ $item["fr_name"] }}">
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="@lang('items.short_name')" name="short_name" value="{{ $item["short_name"] }}">
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius" type="text" placeholder="@lang('items.tasting_short_name')" name="tasting_name" value="{{ $item["tasting_name"] }}">
                            </div>
                        </div>
                        <hr>
                        <!-- Item price and delivery price  -->
                        <div class="row" style="margin-top: 1rem">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-dollar-sign"></i></span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius" placeholder="@lang('items.cost')" name="cost" value="{{ $item["cost"] }}">
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-hand-holding-usd"></i></span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius" placeholder="@lang('items.price')" name="price" value="{{ $item["price"] }}">
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-taxi"></i></span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius" placeholder="@lang('items.delivery_price')" name="delivery_price" value="{{ $item["delivery_price"] }}">
                                </div>
                            </div>
                            <div class="w-100">
                            </div>
                            <div class="col" style="margin-top: 1rem">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius">{{ $taxes[0]["tax_name"] }}</span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius" placeholder="@lang('items.tax')" value="{{ number_format($taxes[0]["percentage"] * $item["price"] / 100, 2) }}" disabled>
                                </div>
                            </div>
                            <div class="col" style="margin-top: 1rem">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius">{{ $taxes[1]["tax_name"] }}</span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius" placeholder="@lang('items.tax')" value="{{ number_format($taxes[1]["percentage"] * $item["price"] / 100, 2) }}" disabled>
                                </div>
                            </div>
                            <div class="col" style="margin-top: 1.8rem">
                                <div class="custom-control custom-checkbox mr-sm-2">
                                    <input type="checkbox" class="custom-control-input" id="noTax" name="is_taxed" {{ ($item["is_taxed"] == "no") ? "checked" : "" }}>
                                    <label class="custom-control-label" for="noTax" >@lang('items.no_tax')</label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <!-- item description and limit inputs -->
                        <div class="row" style="margin-top: 1rem">

                            <div class="col">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="custom-control custom-checkbox mr-sm-2">
                                            <input type="checkbox" class="custom-control-input " id="limitThisItem" onchange="limitItem()">
                                            <label class="custom-control-label" for="limitThisItem">@lang('items.this_item_limit')</label>
                                        </div>
                                        <input type="number" id="showlimitItemInput" style="margin-top: 0.8rem" class="form-control noBorderRadius form-control-lg" placeholder="Ex : 200" name="limit_quantity" value="{{ $item["limit_quantity"] }}">

                                    </div>

                                    <div class="col-lg-4">
                                        <div class="custom-control custom-checkbox mr-sm-2">
                                            <label class="custom-control-label" for="discountLimit">@lang('items.limit_discount') ?</label>
                                        </div>
                                        <input type="number" id="showlimitDiscountItemInput" style="margin-top: 0.8rem" class="form-control noBorderRadius form-control-lg" placeholder="@lang('items.limit_discount')" name="limit_discount" value="{{ $item["limit_discount"] }}">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Basic & Optional -->
                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col">
                                        <h4 class="text-muted"> @lang('items.basics') </h4>
                                    </div>
                                    <div class="col text-right">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <input class="form-control noBorderRadius addBasicToNewItemInput" type="text" placeholder="@lang('items.add_basic_to_item')">
                                            </div>
                                            <div class="col-lg-4">
                                                <button type="button" class="btn btn-primary noBorderRadius addBasicToNewItem">@lang('items.add_basics')</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="newItemBasics">
                                    @forelse($item["basics"] as $itemBasic)
                                        <span class="orginals"><a href="#" onclick="event.preventDefault();removeItemBasic({{ $itemBasic["id"] }})" class="btn btn-light basicOptional"> {{ $itemBasic["basic_name"] }} <i class="fas fa-times-circle"></i></a></span>
                                    @empty
                                    @endforelse

                                </div>
                            </div>
                            <!-- Optional -->
                            <div class="col-lg-12" style="margin-top: 1rem">
                                <div class="row">
                                    <div class="col-2">
                                        <h4 class="text-muted"> @lang('items.options') </h4>
                                    </div>
                                    <div class="col text-right">
                                        <div class="row">
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" onchange="fillFrOption()" id="OptionalEn" type="text" placeholder="@lang('items.en_name')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalFr" type="text" placeholder="@lang('items.fr_name')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalCost" type="number" value="0" placeholder="@lang('items.cost')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalPrice" type="number" value="0" placeholder="@lang('items.price')">
                                            </div>
                                            <div class="col">
                                                <button type="button" class="btn btn-primary noBorderRadius addOptionalToNewItem">@lang('items.add_option')</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="newItemOptional">
                                    @forelse($item["optionals"] as $itemOption)
                                        <span class="orginals"><a href="#" onclick="event.preventDefault();removeItemOption({{$itemOption["id"]}})" class="btn btn-light basicOptional"> {{ $itemOption["option_name"] }} <i class="fas fa-times-circle"></i></a></span>
                                    @empty
                                    @endforelse
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col">
                                        <h4 class="text-muted"> @lang('items.photo') </h4>
                                    </div>
                                    <div class="col text-right">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <input type="file" name="item_photo" class="custom-file-input" id="item_photo">
                                                <label class="custom-file-label" for="item_photo">@lang('items.choose_file')</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="newItemBasics">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <!-- Item Description -->
                <div class="card">
                    <div class="card-body">
                        <textarea class="form-control form-control-lg border-0" placeholder="@lang('items.description')" rows="4" name="description">{{ $item["description"] }}</textarea>
                    </div>
                </div>
                <!-- Items Groups -->
                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <h4>@lang('items.customize_groups')</h4>
                            </div>
                            <div class="col-lg-6 text-right">
                                <div class="dropdown d-inline-block">
                                    <a class="btn btn-light dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        @lang('items.add_customize_group')
                                    </a>
                                    <div class="dropdown-menu allCustomizeGroup">
                                        @forelse($customizes as $customize)
                                            <a class="dropdown-item" href="#" data-cg-name="{{ $customize["group_name"] }}" data-cg-id="{{ $customize["id"] }}">{{ $customize["group_name"] . ' #' . $customize["id"] }}</a>
                                        @empty
                                            <span>@lang('items.no_items')</span>
                                        @endforelse
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="customizeGroupForThisItem" id="IGForNewItem">
                            @forelse($item["customizes"] as $itemCustomize)
                                <span class="orginals" id="group{{ $itemCustomize['id'] }}">
                                    <a class="btn btn-light" href="#" onclick="event.preventDefault();removeItemCustomize({{ $itemCustomize["id"] }})" role="button">{{ $itemCustomize["customize"]["group_name"] }} <i class="fas fa-times-circle"></i></a>
                                </span>
                            @empty

                            @endforelse
                        </div>

                    </div>
                </div>

                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <h4>@lang('items.photo')</h4>
                                <img src="{{ $item["image_url"] }}" class="img-fluid">
                            </div>
                        </div>
                        <hr>

                    </div>
                </div>

            </div>
        </div>
        </form>
    </div>

@endsection



@section('extra-js')
    <!--\\ items Function \\-->
    <!-- Show All Details When Click On item -->

    <script>
        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <!-- Add item Group -->
    <script>
        $(".allCustomizeGroup a").click(function(){
            var customizegroupName = $(this).data("cg-name") ;
            var customizegroupId = $(this).data("cg-id") ;
            $(this).parents().find(".customizeGroupForThisItem").append(`<span><input name="customizes[]" type="hidden" value="${customizegroupId}" ><a class="btn btn-light customizeGroupBtn" href="#" role="button"> ${customizegroupName} <i class="fas fa-times-circle"></i></a><span>`);
        })
    </script>

    <!-- Remove item Group -->
    <script>
        function removeItemCustomize(customizeId)
        {
            var url = '{{ route('customizeGroups.destroy',':id') }}';
            url = url.replace(':id', customizeId);
            var checkdelete = DeleteRecordNormal(url,'{{ @csrf_token() }}');
            if (checkdelete)
            {
                $('#group' + customizeId).remove();
                Toastify({
                    text: " @lang('items.customize_group') <span class='font-weight-bold'> @lang('items.removed') </span>",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#3e3e3e"
                }).showToast();
            }
        }


        function removeItemBasic(basicId)
        {
            var url = '{{ route('items.remove.basic') }}';
            if (confirm('@lang('items.sure_delete_record')')) {
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {id: basicId},
                })
                    .done(function () {
                        console.log("success");
                    })
                    .fail(function () {
                        console.log("error");
                    })
            }
        }



        function removeItemOption(optionId)
        {
            var url = '{{ route('items.remove.optional') }}';
            if (confirm('@lang('items.sure_delete_record')')) {
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {id: optionId},
                })
                    .done(function () {
                        console.log("success");
                    })
                    .fail(function (ex) {

                        console.log(ex);
                    })
            }
        }




    </script>

    <script>
        $(document).on('click', '.customizeGroupBtn .fa-times-circle', function(){
                $(this).parent().closest('span').remove();
                Toastify({
                    text: " @lang('items.customize_group') <span class='font-weight-bold'> @lang('items.removed') </span>",
                    duration: 6000,
                    //destination: 'https://github.com/apvarun/toastify-js',
                    //newWindow: true,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#3e3e3e"
                }).showToast();

        })
    </script>

    <!-- Add Basic & Optional -->
    <script>
        //add Basic to New Item
        $(".addBasicToNewItem").click(function(){
            //$(this).parent().remove();
            var basicInputValue = $(".addBasicToNewItemInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(basicInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error') </span> @lang('items.cant_add_empty_basic')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parents().find(".newItemBasics").append(`<span><input type="hidden" name="basics[]" value=${basicInputValue}><button type="button" class="btn btn-light basicOptionalBtn">${basicInputValue} <i class="fas fa-times-circle"></i></button></span>`);
                $(".addBasicToNewItemInput").val("");
            }
        });

        //add Optional to New Item
        $(".addOptionalToNewItem").click(function(){
            //$(this).parent().remove();
            var OptionalInputEn = $("#OptionalEn").val() ;
            var OptionalInputFr = $("#OptionalFr").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(OptionalInputEn) == "" || $.trim(OptionalInputFr) == "") {
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error') </span> @lang('items.cant_add_empty_option')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            } else {
                var OptionPrice = $('#OptionalPrice').val();
                if (OptionPrice != null) {
                    var OptionalInputPrice = OptionPrice;
                    var OptionalInputCost = $('#OptionalCost').val();
                    //alert(`<span><input type="hidden" name="optionals[]" value=${OptionalInputEn}|${OptionalInputFr}|${OptionalInputCost}|${OptionalInputPrice}> <button type="button" class="btn btn-light basicOptionalBtn"> ${OptionalInputValue}<i class="fas fa-times-circle"></i></button></span>`)
                    $(this).parents().find(".newItemOptional").append(`<span><input type="hidden" name="optionals[]" value=${OptionalInputEn}|${OptionalInputFr}|${OptionalInputCost}|${OptionalInputPrice}> <button type="button" class="btn btn-light basicOptionalBtn"> ${OptionalInputEn}<i class="fas fa-times-circle"></i></button></span>`);
                    $(".addOptionalToNewItemInput").val("");
                }

            }
        });

        //remove Basic & Optional After Add it
        $(document).on('click', '.basicOptionalBtn i', function(){
            var removedVal = $(this).parent().closest('span').remove();

            Toastify({
                text: "<span class='font-weight-bold'> @lang('items.removed') </span> @lang('items.from_item')",
                duration: 6000,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        });

        function fillFrOption () {
            var name = $('#OptionalEn').val();
            $('#OptionalFr').val(name);
        }
    </script>

@endsection
