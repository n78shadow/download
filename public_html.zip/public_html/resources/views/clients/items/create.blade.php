@extends('layouts.master')

@section('title','UPOS | create new category')

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">@lang('items.customize_groups')</a>
    </li>
@endsection
@section('page-links')
    <li class="breadcrumb-item"><a href="{{ route('items.index') }}">Items</a></li>
    <li class="breadcrumb-item active">Create Item</li>
@endsection

@section('extra-styles')

@endsection

@section('content')

    @include('partials.navbar')
    @include('partials.sidebar')

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">@lang('items.items') <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;">@lang('items.add_new_item')</span></h3>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" >@lang('items.cancel')</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" onclick="SubmitForm('forms_CreateItem')">@lang('items.add')</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="contents" id="newItem" style="margin: 0 3rem 2rem 6rem !important;" >
        <form action="{{ route('items.store') }}" method="POST" id="forms_CreateItem" enctype="multipart/form-data">
            @csrf
        <div class="row">
            <div class="col-lg-8">
                <!-- Item Information  -->
                <div class="card">
                    <div class="card-body">
                        <!-- Item Name -->
                        <div class="row">
                            <div class="col">
                                <input onchange="fillNames()" class="form-control form-control-lg noBorderRadius {{ $errors->has('en_name') ? 'is-invalid' : '' }}" type="text" name="en_name" id="en_name" placeholder="@lang('items.en_item_name')" value="{{ old('en_name') }}">
                                @if ($errors->has('en_name'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('en_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius {{ $errors->has('fr_name') ? 'is-invalid' : '' }}" type="text" name="fr_name" id="fr_name" placeholder="@lang('items.fr_item_name')" value="{{ old('fr_name') }}">
                                @if ($errors->has('fr_name'))
                                        <span class="invalid-feedback">
                                <strong>{{ $errors->first('fr_name') }}</strong>
                                </span>
                                @endif
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius {{ $errors->has('short_name') ? 'is-invalid' : '' }}" type="text" name="short_name" id="short_name"  placeholder="@lang('items.')Short Name" value="{{ old('short_name') }}">
                                @if ($errors->has('short_name'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('short_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col">
                                <input class="form-control form-control-lg noBorderRadius {{ $errors->has('tasting_name') ? 'is-invalid' : '' }}" type="text" placeholder="@lang('items.tasting_short_name')" name="tasting_name" value="{{ old('tasting_name') }}">
                                @if ($errors->has('tasting_name'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('tasting_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <hr>
                        <!-- Item price and delivery price  -->
                        <div class="row" style="margin-top: 1rem">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-dollar-sign"></i></span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius {{ $errors->has('cost') ? 'is-invalid' : '' }}" placeholder="@lang('items.cost')" name="cost" value="{{ old('cost') }}">
                                    @if ($errors->has('cost'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('cost') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-hand-holding-usd"></i></span>
                                    </div>
                                    <input type="number"  onchange="calcTax()" class="form-control noBorderRadius {{ $errors->has('price') ? 'is-invalid' : '' }}" placeholder="@lang('items.price')" name="price" id="price" value="{{ old('price') }}">
                                    @if ($errors->has('price'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius"><i class="fas fa-taxi"></i></span>
                                    </div>
                                    <input type="number" class="form-control noBorderRadius {{ $errors->has('delivery_price') ? 'is-invalid' : '' }}" placeholder="@lang('items.delivery_price')" name="delivery_price" value="{{ old('delivery_price') }}">
                                    @if ($errors->has('delivery_price'))
                                        <span class="invalid-feedback">
                                        <strong>{{ $errors->first('delivery_price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="w-100">
                            </div>
                            <div class="col" style="margin-top: 1rem">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius">{{ $taxes[0]["tax_name"] }}</span>
                                    </div>
                                    <input type="number" id="tax{{ $taxes[0]['id'] }}" class="form-control noBorderRadius" placeholder="@lang('items.tax')" disabled value="{{ $taxes[0]["percentage"] }}">
                                </div>
                            </div>
                            <div class="col" style="margin-top: 1rem">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text noBorderRadius">{{ $taxes[1]["tax_name"] }}</span>
                                    </div>
                                    <input type="number" id="tax{{ $taxes[1]['id'] }}" class="form-control noBorderRadius" placeholder="@lang('items.tax')" disabled value="{{ $taxes[1]["percentage"] }}">
                                </div>
                            </div>
                            <div class="col" style="margin-top: 1.8rem">
                                <div class="custom-control custom-checkbox mr-sm-2">
                                    <input type="checkbox" class="custom-control-input" id="noTax" name="is_taxed">
                                    <label class="custom-control-label" for="noTax">@lang('items.no_tax')</label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <!-- item description and limit inputs -->
                        <div class="row" style="margin-top: 1rem">

                            <div class="col">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="custom-control custom-checkbox mr-sm-2">
                                            <input type="checkbox" class="custom-control-input " id="limitThisItem" onchange="limitItem()">
                                            <label class="custom-control-label" for="limitThisItem">@lang('items.this_item_limit')</label>
                                        </div>

                                        <input type="number" id="showlimitItemInput" style="margin-top: 0.8rem" class="form-control noBorderRadius form-control-lg" placeholder="Ex : 200" name="limit_quantity" hidden>

                                    </div>

                                    <div class="col-lg-4">
                                        <div class="custom-control custom-checkbox mr-sm-2">
                                            <input type="checkbox" class="custom-control-input" id="discountLimit"  onchange="limitDiscountItem()" >
                                            <label class="custom-control-label" for="discountLimit">@lang('items.limit_discount') ?</label>
                                        </div>
                                        <input type="number" id="showlimitDiscountItemInput" style="margin-top: 0.8rem" class="form-control noBorderRadius form-control-lg" placeholder="@lang('items.limit_discount')" name="limit_discount" hidden>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Basic & Optional -->
                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col">
                                        <h4 class="text-muted"> @lang('items.basics') </h4>
                                    </div>
                                    <div class="col text-right">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <input class="form-control noBorderRadius addBasicToNewItemInput" type="text" placeholder="@lang('items.add_basics')">
                                            </div>
                                            <div class="col-lg-4">
                                                <button type="button" class="btn btn-primary noBorderRadius addBasicToNewItem">@lang('items.add_basics')</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="newItemBasics">
                                </div>
                            </div>
                            <!-- Optional -->
                            <div class="col-lg-12" style="margin-top: 1rem">
                                <div class="row">
                                    <div class="col-2">
                                        <h4 class="text-muted"> @lang('items.options') </h4>
                                    </div>
                                    <div class="col text-right">

                                        <div class="row">
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" onchange="fillFrOption()" id="OptionalEn" type="text" placeholder="@lang('items.en_name')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalFr" type="text" placeholder="@lang('items.fr_name')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalCost" value="0" type="number" placeholder="@lang('items.cost')">
                                            </div>
                                            <div class="col">
                                                <input class="form-control noBorderRadius addOptionalToNewItemInput" id="OptionalPrice" value="0" type="number" placeholder="@lang('items.price')">
                                            </div>
                                            <div class="col">
                                                <button type="button" class="btn btn-primary noBorderRadius addOptionalToNewItem">@lang('items.add_option')</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="newItemOptional">
                                </div>
                            </div>


                        </div>
                    </div>
                </div>

                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col">
                                        <h4 class="text-muted"> @lang('items.photo') </h4>
                                    </div>
                                    <div class="col text-right">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <input type="file" name="item_photo" class="custom-file-input" id="item_photo">
                                                <label class="custom-file-label" for="item_photo">@lang('items.choose_file')</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="newItemBasics">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <!-- Item Description -->
                <div class="card">
                    <div class="card-body">
                        <textarea class="form-control form-control-lg border-0" placeholder="@lang('items.description')" rows="4" name="description"></textarea>
                    </div>
                </div>
                <!-- Items Groups -->
                <div class="card" style="margin-top: 2rem">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <h4>@lang('items.item_groups')</h4>
                            </div>
                            <div class="col-lg-6 text-right">
                                <div class="dropdown d-inline-block">
                                    <a class="btn btn-light dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        @lang('items.add_item_group')
                                    </a>
                                    <div class="dropdown-menu allCustomizeGroup">
                                        @forelse($customizes as $customize)
                                            <a class="dropdown-item" href="#" data-cg-name="{{ $customize["group_name"] }}" data-cg-id="{{ $customize["id"] }}">{{ $customize["group_name"] . ' #' . $customize["id"] }}</a>
                                        @empty
                                        @endforelse
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="ItemGroupForThisItem" id="IGForNewItem">
                        </div>

                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>

@endsection




@section('extra-js')

    <!--\\ items Function \\-->
    <!-- Show All Details When Click On item -->
    <script>
        $(".itemInCtg").click(function(){
            //$(".itemDetails").removeClass("display-block");
            $(this).find(".itemDetails").toggleClass("display-block");
            //alert(1);
        });

        //Show Items By Groups
        $("#viewByGroup").click(function(){
            $("#itemsGroup").toggleClass("display-block");
            $("#allItems").toggle();
        });

        //Add New Item
        $("#addNewItem").click(function(){
            $("#newItem").addClass("display-block");
            $("#itemsGroup").removeClass("display-block");
            $("#allItems").hide();

            //Buttons
            $("#viewByGroup").hide();
            $("#OrganizeItems").hide();
            $("#addNewItem").hide();

            $("#cancelAddNewItem").addClass("d-inline-block");
            $("#saveNewItem").addClass("d-inline-block");

            $("#addNewItemText").addClass("d-inline-block");
        });

        //Edit Item
        $(".itemEditBtn").click(function(e){
            e.stopPropagation();
            $("#editItem").addClass("display-block");
            $("#allItems").hide();

            //Buttons
            $("#viewByGroup").hide();
            $("#OrganizeItems").hide();
            $("#addNewItem").hide();

            $("#cancelAddNewItem").addClass("d-inline-block");
            $("#saveNewItem").addClass("d-inline-block");
        });

        //save New Item
        $("#saveNewItem, #cancelAddNewItem").click(function(){
            $("#newItem").removeClass("display-block");
            $("#editItem").removeClass("display-block");
            $("#allItems").show();

            //Buttons
            $("#viewByGroup").show();
            $("#OrganizeItems").show();
            $("#addNewItem").show();

            $("#cancelAddNewItem").removeClass("d-inline-block");
            $("#saveNewItem").removeClass("d-inline-block");

            $("#addNewItemText").removeClass("d-inline-block");
        });


        //Show Reapeated Item In Groups
        $(document).on('mouseenter', '.items-list-inGroup li', function(){
            var selector = $(this).data("item-name");
            var selectorCount = 0;

            $("li[data-item-name="+selector+"]").each(function() {
                selectorCount++;
            });

            //alert(selectorCount);

            if(selectorCount > 1) {
                //alert(11)
                $("li[data-item-name]").addClass("halfOpacity");
                $("li[data-item-name="+selector+"]").removeClass("halfOpacity");
                $("li[data-item-name="+selector+"]").append('<span class="badge badge-secondary badge-pill itemCount" style="float: right">'+selectorCount+'</span>');
            }else{
                $("li[data-item-name="+selector+"]").append('<span class="badge badge-secondary badge-pill itemCount" style="float: right">@lang('items.only_this')</span>');
            }
        });

        $(document).on('mouseleave', '.items-list-inGroup li', function(){
            $("li[data-item-name]").removeClass("halfOpacity");
            $(".itemCount").remove();
        });

        //limit Item
        function limitItem() {
            if($('#limitThisItem').is(":checked")) {
                //alert(1);
                $("#showlimitItemInput").addClass("display-block");
            }
            else {
                $("#showlimitItemInput").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItem() {
            if($('#discountLimit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInput").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInput").removeClass("display-block");
            }
        }

        //limit Item In Edit
        function limitItemInEdit() {
            if($('#limitThisItemInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitItemInputInEdit").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItemInEdit() {
            if($('#discountLimitInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInputInEdit").removeClass("display-block");
            }
        }

    </script>

    <script>
        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });
    </script>

    <!-- Add Customize Group -->
    <script>
        $(".allCustomizeGroup a").click(function(){
            var customizegroupName = $(this).data("cg-name") ;
            var customizegroupId = $(this).data("cg-id") ;
            $(this).parents().find(".ItemGroupForThisItem").append(`<span><input name="customizes[]" type="hidden" value="${customizegroupId}" ><a class="btn btn-light customizeGroupBtn" href="#" role="button"> ${customizegroupName} <i class="fas fa-times-circle"></i></a><span>`);
        })
    </script>

    <!-- Remove Customize Group -->
    <script>
        $(document).on('click', '.customizeGroupBtn .fa-times-circle', function(){
            $(this).parent().closest('span').remove();
            Toastify({
                text: " @lang('items.customize_group') <span class='font-weight-bold'> @lang('items.removed') </span>",
                duration: 6000,
                //destination: 'https://github.com/apvarun/toastify-js',
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        })
    </script>

    <!-- Add Basic & Optional -->
    <script>
        //add Basic to New Item
        $(".addBasicToNewItem").click(function(){
            //$(this).parent().remove();
            var basicInputValue = $(".addBasicToNewItemInput").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(basicInputValue) == ""){
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error')</span> @lang('items.cant_add_empty_basic')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            }else{
                $(this).parents().find(".newItemBasics").append(`<span><input type="hidden" name="basics[]" value=${basicInputValue}><button type="button" class="btn btn-light basicOptionalBtn">${basicInputValue} <i class="fas fa-times-circle"></i></button></span>`);
                $(".addBasicToNewItemInput").val("");
            }
        });

        //add Optional to New Item
        $(".addOptionalToNewItem").click(function(){
            //$(this).parent().remove();
            var OptionalInputEn = $("#OptionalEn").val() ;
            var OptionalInputFr = $("#OptionalFr").val() ;
            //alert(filterInputValue);
            //if(filterInputValue == ""){
            if($.trim(OptionalInputEn) == "" || $.trim(OptionalInputFr) == "") {
                Toastify({
                    text: "<span class='font-weight-bold'> @lang('items.error') </span> @lang('items.cant_add_empty_option')",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            } else {
                var OptionPrice = $('#OptionalPrice').val();
                if (OptionPrice != null) {
                    var OptionalInputPrice = OptionPrice;
                    var OptionalInputCost = $('#OptionalCost').val();
                    //alert(`<span><input type="hidden" name="optionals[]" value=${OptionalInputEn}|${OptionalInputFr}|${OptionalInputCost}|${OptionalInputPrice}> <button type="button" class="btn btn-light basicOptionalBtn"> ${OptionalInputValue}<i class="fas fa-times-circle"></i></button></span>`)
                    $(this).parents().find(".newItemOptional").append(`<span><input type="hidden" name="optionals[]" value=${OptionalInputEn}|${OptionalInputFr}|${OptionalInputCost}|${OptionalInputPrice}> <button type="button" class="btn btn-light basicOptionalBtn"> ${OptionalInputEn}<i class="fas fa-times-circle"></i></button></span>`);
                    $(".addOptionalToNewItemInput").val("");
                }

            }
        });

        //remove Basic & Optional After Add it
        $(document).on('click', '.basicOptionalBtn i', function(){
            var removedVal = $(this).parent().closest('span').remove();

            Toastify({
                text: "<span class='font-weight-bold'> @lang('items.removed') </span> @lang('items.from_item')",
                duration: 6000,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#3e3e3e"
            }).showToast();
        });

        function calcTax() {
            var price = parseFloat($('#price').val());
            var percentage = 0.000;
            @forelse($taxes as $tax)
                percentage = parseFloat({{ $tax['percentage'] }});
                var tax = parseFloat(percentage * price / 100).toFixed(2);
                $('#tax{{ $tax['id'] }}').val(tax);
                //alert(tax)
            @empty
            @endforelse

        }

        function fillNames() {
            var name = $('#en_name').val();
            $('#fr_name').val(name);
            $('#short_name').val(name);
        }

        function fillFrOption () {
            var name = $('#OptionalEn').val();
            $('#OptionalFr').val(name);
        }
    </script>


@endsection
