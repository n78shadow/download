@extends('layouts.master')

@section('title','UPOS | create new user')

@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection


@section('extra-styles')
    <style type="text/css">
        .roles-list {
            border: 1p solid #aaa;
        }

        .notSelected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #ccc;
        }

        .selected:before {
            content: '\f111';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-right: .75rem;
            font-size: 14px;
            color: #28a745;
        }
    </style>
@endsection
@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection
@section('page-links')
    <li class="breadcrumb-item"><a href="{{ route('users.index') }}">Users</a></li>
    <li class="breadcrumb-item active">Update User</li>
@endsection
@section('content')

    @include('partials.navbar')
    @include('partials.sidebar')

    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h3 class="noMargin">Users <span class="text-muted" id="addNewItemText" style="margin: 0 15px; font-size: 20px;">Update User</span></h3>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-danger noBorderRadius" id="cancelAddNewItem" >Cancel</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" onclick="SubmitForm('forms_CreateUser')">Update</button>
                        <button type="button" class="btn btn-primary noBorderRadius" id="saveNewItem" style="background-color: #546e7a" onclick="SubmitForm('forms_DeleteUser')">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form method="post" id="forms_DeleteUser" action="{{ route("users.destroy", $user['id']) }}">
        @csrf
        @method('delete')
    </form>
    <div class="contents" id="newEmployee" style="margin: 0 3rem 2rem 6rem !important;">
        <div class="card card-body">
            <h4>Update User</h4>
            <hr>
            <form method="post" id="forms_CreateUser" action="{{ route("users.update", $user['id']) }}">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col">
                        <input class="form-control {{ $errors->has('first_name') ? 'is-invalid' : '' }}" type="text"  value="{{ $user["first_name"] }}" name="first_name" placeholder="First Name">
                        @if ($errors->has('first_name'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('first_name') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('last_name') ? 'is-invalid' : '' }}" type="text" value="{{ $user["last_name"] }}" name="last_name" placeholder="Last Name">
                        @if ($errors->has('last_name'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('last_name') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="col">
                        <input class="form-control {{ $errors->has('phone') ? 'is-invalid' : '' }}" type="text" name="phone" value="{{ $user["phone"] }}" placeholder="Phone Number">
                        @if ($errors->has('phone'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('phone') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" type="email" name="email" value="{{ $user["email"] }}" placeholder="Email">
                        @if ($errors->has('email'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="w-100" style="margin: .5rem 0"></div>

                    <div class="col">
                        <input class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}" type="text" name="username" value="{{ $user["username"] }}" placeholder="Username">
                        @if ($errors->has('username'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('username') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <input id="passwordCreat-field"class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" name="password" type="password" placeholder="Password">
                            <div class="input-group-append">
                                <button toggle="#passwordCreat-field" type="button" class="btn btn-light input-group-append" style="border: 1px solid #ced4da; border-left: none;" data-pass-type='show'><i class="fas fa-eye"></i></button>
                            </div>
                            @if ($errors->has('password'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('confirm_password') ? 'is-invalid' : '' }}" type="password" name="confirm_password" placeholder="Retype Password">
                        @if ($errors->has('confirm_password'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('confirm_password') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="col">
                        <input class="form-control {{ $errors->has('access_code') ? 'is-invalid' : '' }}" type="text" name="access_code" value="{{ $user["access_code"] }}" placeholder="Access Code">
                        @if ($errors->has('access_code'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('access_code') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="col">
                        <input class="form-control {{ $errors->has('salary') ? 'is-invalid' : '' }}" type="text" value="{{ $user["salary"] }}" name="salary" placeholder="Salary">
                        @if ($errors->has('salary'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('salary') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="col">
                        <select class="form-control" name="job">
                            <option value="Administrator" {{ $user['job'] == 'Administrator' ? 'selected' : "" }}>Administrator</option>
                            <option value="Supervisor" {{ $user['job'] == 'Supervisor' ? 'selected' : "" }}>Supervisor</option>
                            <option value="Kitchen" {{ $user['job'] == 'Kitchen' ? 'selected' : "" }}>Kitchen</option>
                            <option value="waiter" {{ $user['job'] == 'waiter' ? 'selected' : "" }}>waiter</option>
                            <option value="Cleaner" {{ $user['job'] == 'Cleaner' ? 'selected' : "" }}>Cleaner</option>
                        </select>

                    </div>
                    <div class="col">
                        <select class="form-control" name="default_route">
                            <option value="">Dashboard</option>
                            @foreach($routes as $route => $name)
                                <option value="{{ $route }}" {{ $user['default_route'] == $route ? 'selected' : "" }}>{{ $name }}</option>
                            @endforeach
                        </select>

                    </div>
                    <div class="w-100" style="margin: .5rem 0"></div>
                    @forelse($roles as $role)
                        <div class="col-2">
                            <a class="btn  btn-light notSelected btn-block" style="text-align: left!important;" id="selector{{ $role['id'] }}" href="#" onclick="setChecked(this, {{ $role['id'] }})" role="button">
                                <input type="checkbox" style="display: none" name="roles[]" value="{{ $role['id'] }}" id="item{{ $role['id'] }}">
                                {{ $role['name'] }}
                            </a>
                        </div>
                    @empty
                    @endforelse
                </div>
            </form>
        </div>
    </div>
@endsection




@section('extra-js')
    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>


        $('.roles-list').select2({
            theme: "bootstrap",
            placeholder: "search for role ...",
            width: "100%",
            height: "100%",
        });

        function SubmitForm(formId)
        {
            if (formId == 'forms_DeleteUser') {
                if (confirm('Are you sure to delete this user')) {
                    $('#'+formId).submit();
                }
            } else {
                $('#'+formId).submit();
            }

        }

        $('.roles-list').on('select2:select', function (event) {
            var role_id = $(event.currentTarget).find("option:selected").val();
            var role_name = $(event.currentTarget).find("option:selected").text();

            if($.trim(role_name) == "") {
                Toastify({
                    text: "<span class='font-weight-bold'> ERROR - </span> Can't add empty role",
                    duration: 6000,
                    close: true,
                    gravity: "bottom", // `top` or `bottom`
                    positionLeft: true, // `true` or `false`
                    backgroundColor: "#dc3545"
                }).showToast();

            } else {
                var html = `<span><input type="hidden" name="roles[]" value=${role_id}> <button type="button" class="btn btn-light basicOptionalBtn"> ${role_name}<i class="fas fa-times-circle remove-role"></i></button></span>`;
                $(".newRole").append(html);
                //$(".addOptionalToNewItemInput").val("");
            }
        });

        $(document).on("click", ".remove-role", function () {
            $(this).parent().parent().remove();
        });

        function setChecked(ele, id) {
            var itemClass = $(ele).attr('class');
            if (itemClass.search('notSelected') != -1) {
                $('#item' + id).attr("checked", "checked");
                $(ele).removeClass('notSelected').addClass('selected');
            } else {
                $('#item' + id).removeAttr('checked');
                $(ele).removeClass('selected').addClass('notSelected');
            }
        }

        $(document).ready(function () {
            @forelse($user['roles'] as $role)
                $('#selector{{ $role['id'] }}').removeClass('notSelected').addClass('selected');
                $('#item{{ $role['id'] }}').attr("checked", "checked");
            @empty
            @endforelse
        })
    </script>


@endsection