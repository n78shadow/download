<?php //dd($category); ?>
@extends('layouts.master')


@section('title','UPOS | Users')


@section('extra-links')
    <li class="nav-item">
        <a class="nav-link" href="#">Customize Groups</a>
    </li>
@endsection

@section('extra-css-links')
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

@endsection
@section('page-links')
<li class="breadcrumb-item active">Users</li>
@endsection
@section('content')
    @include('partials.navbar')
    @include('partials.sidebar')

    <style>
        .ctg , .newCtg{
            padding: 1.5rem 1rem 2rem 1rem;
            margin-top: 1rem;
            border: none;
        }

        .ctg h3 , .newCtg h3 {
            margin: 0;
        }

        .ctg .color {
            position: absolute;
            bottom: 0;
            color: #fff;
            width: 100%;
            left: 0;
            padding: 2px 10px;
        }

        .ctg i {
            position: absolute;
            top: 6px;
            right: 8px;
            font-size: 26px;
            color: #ddd;
        }

        .newCtgIc{
            color: #ddd;
            position: absolute;
            bottom: 0;
            left: 0px;
            padding: 10px;
            font-size: 60px;
        }

        .customizeGroupBtn {
            margin: 5px;
        }

        .customizeGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .itemGroup-list i {
            float: right;
            padding: 4px;
            color: #dc3545;
        }

        .emptyCategory .addItem {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            left: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .emptyCategory .addSub {

            position: absolute;
            top: -24px;
            background-color: #ccc;
            right: -9px;
            height: 150%;
            width: 75%;
            font-size: 40px;
        }

        .subCategory button  {
            background-color: rgba(0,0,0,0.1);
            color: #3e3e3e;
            border: none;
        }

        .deleteItem {
            position: absolute;
            top: 0;
            right: 0;
            padding: 25px;
            font-size: 20px;
            cursor: pointer;
            color: #bd2130;
        }

        h5 {
            display: inline-block;
        }
        /* item style */
        .itemInCtg{
            border: none;
        }

        .categoryColor {
            position: absolute;
            width: 2.2rem;
            height: 100%;
            top: 0;
            left: 0;
        }

        .itemNumber{
            position: absolute;
            left: 0.8rem;
            top: 50%;
            color: #fff;
            font-size: 25px;
            transform: translate( 0 , -50%);
        }

        .itemEditBtn{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #ccc;
        }

        .itemDeleteFromCtg{
            position: absolute;
            top: 0;
            right: 0;
            padding: 15px;
            font-size: 22px;
            color: #eee;
        }

        .itemDeleteFromCtg:hover{
            transition: 0.2s;
            color: #dc3545;
        }

        .itemGroupBtn {
            margin: 5px;
        }

        .itemGroupBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .basicOptionalBtn i {
            color: #dc3545;
            padding: 4px 6px;
            margin: 0px -10px 0px 5px;
        }

        .sortable-ghost {
            border: 2px dashed #eee;
        }
    </style>



    <div class="contents" style="margin:2rem 3rem 2rem 6rem !important;">
        <div class="card border-0 noBorderRadius">
            <div class="card-body" style="padding-bottom: 0.25rem;">
                <div class="row">
                    <div class="col-4">
                        <div class="input-group mb-3">
                            <select class="users-list">

                            </select>
                        </div>
                    </div>

                    <div class="col text-right">
                        <a type="button" class="btn btn-primary border-0" href="{{ route('users.create') }}" role="button" style="background-color: #546e7a"> New Employee </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contents" style="margin: -1rem 3rem 1rem 6rem !important;">
        <div class="row">
            <div class="col text-left" id="myBtnFilter">
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">All</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Managers</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Supervisors</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Waiters</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Clean Worker</button>
                <button type="button" class="btn btn-sm btn-outline-secondary tab-filter-links">Delivery Boy</button>
            </div>
        </div>
    </div>

    <div class="contents" id="allEmployee" style="margin: 0 3rem 2rem 6rem !important;">


        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">phone</th>
                        <th scope="col">Username</th>
                        <th scope="col">email</th>
                        <th scope="col">Access Code</th>
                        <th scope="col">status</th>
                        <th scope="col">Roles</th>
                        <th scope="col">Hourly Paid</th>
                        <th scope="col">Edit</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse ($users as $user)
                        <tr>
                            <td></td>
                            <td>{{ $user['first_name'] . ' ' , $user['last_name'] }}</td>
                            <td>{{ @$user['phone'] }}</td>
                            <td>{{ $user['username'] }}</td>
                            <td>{{ $user['email'] }}</td>
                            <td>{{ $user['access_code'] }}</td>
                            <td>
                                <a id="user-status{{ $user['id'] }}" style="cursor: pointer" onclick="changeStatus({{ $user['id'] }}, '{{ $user['status'] }}')">
                                    <span class="badge badge-{{ ($user['status'] == "active") ? "success" : "danger" }}">{{ $user['status'] }}</span>
                                </a>
                            </td>
                            <td>
                                <select type="text" class="form-control roles-list" name="product_id" style="width: 200px!important; border: 1px solid #888!important;" placeholder="Add Tasting Item">
                                    @forelse($user['roles'] as $role)
                                        <option value="{{ $role['id'] }}">{{ $role['name'] }} </option>
                                    @empty
                                    @endforelse
                                </select>
                            </td>
                            <td>{{ $user['salary'] }}</td>
                            <td><a id="route{{ $user['id'] }}" href="{{ route("users.edit", $user['id']) }}"><i class="fas fa-pen-square"></i></a></td>
                        </tr>
                    @empty
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>




    </div>

    <!-- Modals -->

    <!-- Edit Modal -->
    <!-- Modal -->
    <div class="modal fade" id="editUser" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header row">
                    <div class="col-9">
                        <h4 class="modal-title" id="exampleModalLabel">Edit User - <span class="text-muted">@adnan</span></h4>
                    </div>
                    <div class="col-3">

                    </div>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <input class="form-control" type="text" placeholder="First Name">
                        </div>
                        <div class="col">
                            <input class="form-control" type="text" placeholder="Last Name">
                        </div>

                        <div class="col">
                            <input class="form-control" type="text" placeholder="Phone Number">
                        </div>

                        <div class="w-100" style="margin: .5rem 0"></div>

                        <div class="col">
                            <input class="form-control" type="text" placeholder="Username">
                        </div>
                        <div class="col">
                            <div class="input-group">
                                <input id="passwordEdit-field" class="form-control" type="password" placeholder="Password">
                                <div class="input-group-append">
                                    <button toggle="#passwordEdit-field" type="button" class="btn btn-light input-group-append" style="border: 1px solid #ced4da; border-left: none;" data-pass-type='show'><i class="fas fa-eye"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <input class="form-control" type="password" placeholder="Retype Password">
                        </div>

                        <div class="col">
                            <input class="form-control" type="text" placeholder="Access Code">
                        </div>

                        <div class="col">
                            <div class="dropdown">
                                <button class="btn btn-secondary btn-block dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Roles
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="#">Manager</a>
                                    <a class="dropdown-item" href="#">Supervisor</a>
                                    <a class="dropdown-item" href="#">Waiter</a>
                                </div>
                            </div>
                        </div>

                        <div class="w-100" style="margin: .5rem 0"></div>

                        <div class="col">
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                            <button type="button" class="btn btn-sm btn-light"> Test Role <span class="removeRole"><i class="fas fa-times-circle"></i></span> </button>
                        </div>


                    </div>
                </div>
                <div class="w-100">
                    <hr>
                </div>
                <div class="modal-footer row" style="border: none">

                    <div class="col text-left">
                        <button type="button" class="btn btn-danger deleteUser">Delete This User ?</button>
                    </div>
                    <div class="col text-right">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra-js')

    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/sortable.js') }}"></script>
    <script>
        $("button[data-pass-type='show']").click(function() {
            $(this).find("i").toggleClass("fa-eye-slash");

            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } else {
                input.attr("type", "password");
            }
        });

        $(document).on("click", ".editUser",function(e) {
            $('#editUser').modal({
                backdrop: 'static',
                keyboard: false
            })
        });

        $(document).on("click", ".deleteUser",function(e) {
            $('#editUser').modal('hide');

            Toastify({
                text: " <span class='font-weight-bold'> @adnan </span> Deleted Successfuly ",
                duration: 6000,
                //newWindow: true,
                close: true,
                gravity: "bottom", // `top` or `bottom`
                positionLeft: true, // `true` or `false`
                backgroundColor: "#e74c3c"
            }).showToast();
        });

        $(".itemInCtg").click(function(){
            //$(".itemDetails").removeClass("display-block");
            $(this).find(".itemDetails").toggleClass("display-block");
            //alert(1);
        });

        //Show Items By Groups
        $("#viewByGroup").click(function(){
            $("#itemsGroup").toggleClass("display-block");
            $("#allItems").toggle();
        });

        //Add New Item
        $("#addNewItem").click(function(){
            $("#newItem").addClass("display-block");
            $("#itemsGroup").removeClass("display-block");
            $("#allItems").hide();

            //Buttons
            $("#viewByGroup").hide();
            $("#OrganizeItems").hide();
            $("#addNewItem").hide();

            $("#cancelAddNewItem").addClass("d-inline-block");
            $("#saveNewItem").addClass("d-inline-block");

            $("#addNewItemText").addClass("d-inline-block");
        });

        //Edit Item
        $(".itemEditBtn").click(function(e){
            e.stopPropagation();
            $("#editItem").addClass("display-block");
            $("#allItems").hide();

            //Buttons
            $("#viewByGroup").hide();
            $("#OrganizeItems").hide();
            $("#addNewItem").hide();

            $("#cancelAddNewItem").addClass("d-inline-block");
            $("#saveNewItem").addClass("d-inline-block");
        });

        //save New Item
        $("#saveNewItem, #cancelAddNewItem").click(function(){
            $("#newItem").removeClass("display-block");
            $("#editItem").removeClass("display-block");
            $("#allItems").show();

            //Buttons
            $("#viewByGroup").show();
            $("#OrganizeItems").show();
            $("#addNewItem").show();

            $("#cancelAddNewItem").removeClass("d-inline-block");
            $("#saveNewItem").removeClass("d-inline-block");

            $("#addNewItemText").removeClass("d-inline-block");
        });


        //Show Reapeated Item In Groups
        $(document).on('mouseenter', '.items-list-inGroup li', function(){
            var selector = $(this).data("item-name");
            var selectorCount = 0;

            $("li[data-item-name="+selector+"]").each(function() {
                selectorCount++;
            });

            //alert(selectorCount);

            if(selectorCount > 1) {
                //alert(11)
                $("li[data-item-name]").addClass("halfOpacity");
                $("li[data-item-name="+selector+"]").removeClass("halfOpacity");
                $("li[data-item-name="+selector+"]").append('<span class="badge badge-secondary badge-pill itemCount" style="float: right">'+selectorCount+'</span>');
            }else{
                $("li[data-item-name="+selector+"]").append('<span class="badge badge-secondary badge-pill itemCount" style="float: right">Only This</span>');
            }
        });

        $(document).on('mouseleave', '.items-list-inGroup li', function(){
            $("li[data-item-name]").removeClass("halfOpacity");
            $(".itemCount").remove();
        });

        //limit Item
        function limitItem() {
            if($('#limitThisItem').is(":checked")) {
                //alert(1);
                $("#showlimitItemInput").addClass("display-block");
            }
            else {
                $("#showlimitItemInput").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItem() {
            if($('#discountLimit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInput").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInput").removeClass("display-block");
            }
        }

        //limit Item In Edit
        function limitItemInEdit() {
            if($('#limitThisItemInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitItemInputInEdit").removeClass("display-block");
            }
        }

        //limit Discount
        function limitDiscountItemInEdit() {
            if($('#discountLimitInEdit').is(":checked")) {
                //alert(1);
                $("#showlimitDiscountItemInputInEdit").addClass("display-block");
            }
            else {
                $("#showlimitDiscountItemInputInEdit").removeClass("display-block");
            }
        }

        $('.sideNav > a').tooltip() ;

        $(document).ready(function(){
            $("#showBreadCrumbs").click(function(){
                $(this).hide();
                $(".breadcrumb").show();
            });
        });

        $('.roles-list').select2({
            theme: "bootstrap",
            placeholder: "search for role ...",
            width: "100%"
        });

        function searchingFor()
        {
            var url = '{{ route('users.search') }}';
            if(url == '')
            {
                return;
            }
            $('.users-list').select2({
                placeholder: "Search for a user",
                minimumInputLength: 2,
                width: "100%",
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor();

        $('.users-list').on('select2:select', function (event) {
            var user_id = $(event.currentTarget).find("option:selected").val();
            var text = $(event.currentTarget).find("option:selected").text();
            var url = $('#route' + user_id).attr("href");
            window.location.href = url;
        });

        function changeStatus (id, status) {
            var url = '{{ route('users.change.status') }}';
            var token = '{{ csrf_token() }}';
            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                data: {id: id, _token: token, status: status},
            }).done(function(data) {
                $('#user-status' + id).attr('onclick',"changeStatus(" + id + ", '" + data.status + "')");
                var oldClass = status == 'active' ? 'badge-success' : 'badge-danger';
                var newClass = oldClass == 'badge-danger' ? 'badge-success' : 'badge-danger';
                $('#user-status' + id + ' span').removeClass(oldClass).addClass(newClass).html(data.status);
            }).fail(function(ex){
                console.log(ex);
            });
        }
    </script>
@endsection
