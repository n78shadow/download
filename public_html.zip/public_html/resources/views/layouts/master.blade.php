@include('partials.header')



@yield('content')


@include('partials.footer')