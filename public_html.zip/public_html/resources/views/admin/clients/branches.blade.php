@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Update {{ $branch["branch_name"] . ' branch' }} or Update Print Variables <a href="{{ route('branch.printers', $branch["id"]) }}">here</a></h1>
@stop

@section('content')
    <div class="col-md-4">
        <form action="{{ route('branches.update',$branch["id"]) }}" method="post">
            @csrf
            @method('PUT')
            <div class="form-group has-feedback {{ $errors->has('branch_name') ? 'has-error' : '' }}">
                <input type="text" name="branch_name" class="form-control" value="{{ $branch["branch_name"] }}"
                       placeholder="client name">
                @if ($errors->has('branch_name'))
                    <span class="help-block">
                            <strong>{{ $errors->first('branch_name') }}</strong>
                        </span>
                @endif
            </div>


            <div class="form-group has-feedback {{ $errors->has('country') ? 'has-error' : '' }}">
                <select id="country" class='form-control' name="country"><option value="">{{ $branch["country"] }}</option></select>
            </div>

            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="active" name="status" {{ $branch["status"] == "active" ? 'checked' : ''  }}>Active</label>
                <label class="radio-inline"><input type="radio" value="inactive" name="status" {{ $branch["status"] == "inactive" ? 'checked' : ''  }}>Inactive</label>
            </div>
            <div class="form-group has-feedback {{ $errors->has('country') ? 'has-error' : '' }}">
                <select id="country" class='form-control' name="country"><option value="{{ $branch["country"] }}" selected>{{ $branch["country"] }}</option></select>
            </div>
            <div class="form-group has-feedback {{ $errors->has('country') ? 'has-error' : '' }}">
                <select id="region" class='form-control' name="region"><option value="{{ $branch["region"] }}" selected>{{ $branch["region"] }}</option></select>
            </div>
            <div class="form-group has-feedback {{ $errors->has('country') ? 'has-error' : '' }}">
                <select id="city" class='form-control' name="city"><option value="{{ $branch["city"] }}" selected>{{ $branch["city"] }}</option></select>
            </div>
            <div class="form-group">
                <textarea class="form-control" id="address" name="address" placeholder="address">{{ $branch["address"] }}</textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>

        <a href="#" data-toggle="modal" data-target="#create_branch_modal" class="btn btn-warning btn-xs right" data-clientname="{{ $branch["branch_name"] }}">create new branch admin</a>

        <div class="form-group">
            <h2>update barnch admin password</h2>
            <div class="form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
                <input type="password" id="password" class='form-control' name="password" placeholder="new password">
            </div>

            <div class="form-group has-feedback {{ $errors->has('password_confirmation') ? 'has-error' : '' }}">
                <input type="password" id="password_confirmation" class='form-control' name="password_confirmation" placeholder="confirm password">
            </div>
        </div>
        </form>
    </div>




    <div class="modal fade" id="create_branch_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="exampleModalLabel"></h4>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.assign.branch') }}" method="post" id="create_branches_admin_form">
                        @csrf
                        <input type="hidden" name="branch_id" value="{{ $branch["id"] }}">
                        <div class="form-group has-feedback {{ $errors->has('first_name') ? 'has-error' : '' }}">
                            <input type="text" class="form-control" name="first_name" placeholder="first name">
                            @if ($errors->has('first_name'))
                                <span class="help-block">
                            <strong>{{ $errors->first('first_name') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('last_name') ? 'has-error' : '' }}">
                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="last name">
                            @if ($errors->has('last_name'))
                                <span class="help-block">
                            <strong>{{ $errors->first('last_name') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('username') ? 'has-error' : '' }}">
                            <input type="text" class="form-control" id="username" name="username" placeholder="username">
                            @if ($errors->has('username'))
                                <span class="help-block">
                            <strong>{{ $errors->first('username') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
                            <input type="email" class="form-control" id="email" name="email" placeholder="email">
                            @if ($errors->has('email'))
                                <span class="help-block">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
                            <input type="password" class="form-control" id="password" name="password" placeholder="password">
                            @if ($errors->has('password'))
                                <span class="help-block">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('password_confirmation') ? 'has-error' : '' }}">
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="password_confirmation">
                            @if ($errors->has('password_confirmation'))
                                <span class="help-block">
                            <strong>{{ $errors->first('password_confirmation') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('access_code') ? 'has-error' : '' }}">
                            <input type="text" class="form-control" name="access_code" placeholder="access code">
                            @if ($errors->has('access_code'))
                                <span class="help-block">
                            <strong>{{ $errors->first('access_code') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label class="radio-inline"><input type="radio" value="active" name="status" checked>Active</label>
                            <label class="radio-inline"><input type="radio" value="inactive" name="status">Inactive</label>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="SubmitForm('create_branches_admin_form')">Create branch admin</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')

@stop

@section('js')

    <script>
        $('#create_branch_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var client = button.data('branch_name') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('Create new branch for client ' + client)
            $('#create_branch_modal').submit();
        })
    </script>


    <script>
        $(document).ready(function() {
            //-------------------------------SELECT CASCADING-------------------------//
            var selectedCountry = (selectedRegion = selectedCity = countryCode = "");

            // This is a demo API key for testing purposes. You should rather request your API key (free) from http://battuta.medunes.net/
            var BATTUTA_KEY = "00000000000000000000000000000000";
            // Populate country select box from battuta API
            url =
                "https://battuta.medunes.net/api/country/all/?key=" +
                BATTUTA_KEY +
                "&callback=?";

            // EXTRACT JSON DATA.
            $.getJSON(url, function(data) {
                console.log(data);
                $.each(data, function(index, value) {
                    // APPEND OR INSERT DATA TO SELECT ELEMENT. Set the country code in the id section rather than in the value.
                    $("#country").append(
                        '<option id="' +
                        value.code +
                        '" value="' +
                        value.name +
                        '">' +
                        value.name +
                        "</option>"
                    );
                });
            });
            // Country selected --> update region list .
            $("#country").change(function() {
                selectedCountry = this.options[this.selectedIndex].text;
// get the id of the option which has the country code.
                countryCode = $(this)
                    .children(":selected")
                    .attr("id");
                // Populate country select box from battuta API
                url =
                    "https://battuta.medunes.net/api/region/" +
                    countryCode +
                    "/all/?key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    $("#region option").remove();
                    $('#region').append('<option value="">Please select your region</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#region").append(
                            '<option value="' + value.region + '">' + value.region + "</option>"
                        );
                    });
                });
            });
            // Region selected --> updated city list
            $("#region").on("change", function() {
                selectedRegion = this.options[this.selectedIndex].text;
                // Populate country select box from battuta API
                // countryCode = $("#country").val();
                region = $("#region").val();
                url =
                    "https://battuta.medunes.net/api/city/" +
                    countryCode +
                    "/search/?region=" +
                    region +
                    "&key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    console.log(data);
                    $("#city option").remove();
                    $('#city').append('<option value="">Please select your city</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#city").append(
                            '<option value="' + value.city + '">' + value.city + "</option>"
                        );
                    });
                });
            });
            // city selected --> update location string
            $("#city").on("change", function() {
                selectedCity = this.options[this.selectedIndex].text;
                $("#location").html(
                    "Locatation: Country: " +
                    selectedCountry +
                    ", Region: " +
                    selectedRegion +
                    ", City: " +
                    selectedCity
                );
            });
        });

        // very simple process form function to collect input values.
        function processForm() {
            var username = (password = country = region = city = "");
            username = $("#username").val();
            password = $("#password").val();
            country = $("#country").val();
            region = $("#region").val();
            city = $("#city").val();
            if (
                // username != "" &&
            // password != "" &&
                country != "" &&
                region != "" &&
                city != ""
            ) {
                $("#location").html(
                    // "Username: " +
                    //   username +
                    //   " /Password: " +
                    //   password +
                    "Locatation: Country: " +
                    country +
                    ", Region: " +
                    region +
                    ", City: " +
                    city
                );
            } else {
                $("#location").html("Fill Country, Region and City to view the location");
                return false;
            }
        }

    </script>

@stop
