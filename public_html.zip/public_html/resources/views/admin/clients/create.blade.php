@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Create New Client</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('clients.store') }}" method="post">
        @csrf
        <div class="form-group has-feedback {{ $errors->has('client_name') ? 'has-error' : '' }}">
            <input type="text" name="client_name" class="form-control" value="{{ old('client_name') }}"
                   placeholder="client name">
            @if ($errors->has('client_name'))
                <span class="help-block">
                            <strong>{{ $errors->first('client_name') }}</strong>
                        </span>
            @endif
        </div>


        <div class="form-group">
            <label class="radio-inline"><input type="radio" value="active" name="status" checked>Active</label>
            <label class="radio-inline"><input type="radio" value="inactive" name="status">Inactive</label>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="create">
        </div>
    </form>
    </div>
@stop

@section('css')

@stop

@section('js')

@stop
