@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Update {{ $client["name"] }}</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('clients.update',$client->id) }}" method="post">
        @csrf
        @method('PUT')
        <div class="form-group has-feedback {{ $errors->has('client_name') ? 'has-error' : '' }}">
            <input type="text" name="client_name" class="form-control" value="{{ $client->client_name }}"
                   placeholder="client name">
            @if ($errors->has('client_name'))
                <span class="help-block">
                            <strong>{{ $errors->first('client_name') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group">
            <label class="radio-inline"><input type="radio" value="active" name="status" {{ $client->status == "active" ? 'checked' : ''  }}>Active</label>
            <label class="radio-inline"><input type="radio" value="inactive" name="status" {{ $client->status == "inactive" ? 'checked' : ''  }}>Inactive</label>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Update">
        </div>
    </form>
        <a href="#" data-toggle="modal" data-target="#create_branch_modal" class="btn btn-warning btn-xs right" data-clientname="{{ $client->client_name }}">create new branch</a>
    </div>




    <div class="modal fade" id="create_branch_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="exampleModalLabel"></h4>
                </div>
                <div class="modal-body">
                    <form action="{{ route('branches.store') }}" method="post" id="create_branches_form">
                        @csrf
                        <input type="hidden" name="client_id" value="{{ $client->id }}">
                        <div class="form-group has-feedback {{ $errors->has('branch_name') ? 'has-error' : '' }}">
                            <label for="branch_name">branch_name</label>
                            <input type="text" class="form-control" id="branch_name" name="branch_name" placeholder="branch name">
                            @if ($errors->has('branch_name'))
                                <span class="help-block">
                            <strong>{{ $errors->first('branch_name') }}</strong>
                        </span>
                            @endif
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('country') ? 'has-error' : '' }}">
                            <label for="country">country</label>
                            <input id="country" class='form-control' name="country" placeholder="country" required>
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('region') ? 'has-error' : '' }}">
                            <label for="region">region</label>
                            <input id="region" class='form-control' name="region"  placeholder="region" required>
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('city') ? 'has-error' : '' }}">
                            <label for="city">city</label>
                            <input id="city" class='form-control' name="city" placeholder="city"  required>
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('app_access_username') ? 'has-error' : '' }}">
                            <label for="app_access_username">app access username</label>
                            <input id="app_access_username" class='form-control' name="app_access_username" placeholder="app access username" required>
                        </div>
                        <div class="form-group has-feedback {{ $errors->has('app_access_password') ? 'has-error' : '' }}">
                            <label for="app_access_password">app access password</label>
                            <input id="app_access_password" class='form-control' name="app_access_password" placeholder="app access password" required>
                        </div>

                        <div class="form-group has-feedback {{ $errors->has('app_access_password') ? 'has-error' : '' }}">
                            <label for="app_access_password">database name</label>
                            <input id="database_name" class='form-control' name="database_name" placeholder="database name" required>
                        </div>

                        <div class="form-group">
                            <textarea class="form-control" id="address" name="address" placeholder="address"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="SubmitForm('create_branches_form')">Create branche</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')

@stop

@section('js')

    <script>
        $('#create_branch_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var client = button.data('clientname') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('Create new branch for client ' + client)
            $('#create_branch_modal').submit();
        })
    </script>


    <script>
        $(document).ready(function() {
            //-------------------------------SELECT CASCADING-------------------------//
            var selectedCountry = (selectedRegion = selectedCity = countryCode = "");

            // This is a demo API key for testing purposes. You should rather request your API key (free) from http://battuta.medunes.net/
            var BATTUTA_KEY = "00000000000000000000000000000000";
            // Populate country select box from battuta API
            url =
                "https://battuta.medunes.net/api/country/all/?key=" +
                BATTUTA_KEY +
                "&callback=?";

            // EXTRACT JSON DATA.
            $.getJSON(url, function(data) {
                console.log(data);
                $.each(data, function(index, value) {
                    // APPEND OR INSERT DATA TO SELECT ELEMENT. Set the country code in the id section rather than in the value.
                    $("#country").append(
                        '<option id="' +
                        value.code +
                        '" value="' +
                        value.name +
                        '">' +
                        value.name +
                        "</option>"
                    );
                });
            });
            // Country selected --> update region list .
            $("#country").change(function() {
                selectedCountry = this.options[this.selectedIndex].text;
// get the id of the option which has the country code.
                countryCode = $(this)
                    .children(":selected")
                    .attr("id");
                // Populate country select box from battuta API
                url =
                    "https://battuta.medunes.net/api/region/" +
                    countryCode +
                    "/all/?key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    $("#region option").remove();
                    $('#region').append('<option value="">Please select your region</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#region").append(
                            '<option value="' + value.region + '">' + value.region + "</option>"
                        );
                    });
                });
            });
            // Region selected --> updated city list
            $("#region").on("change", function() {
                selectedRegion = this.options[this.selectedIndex].text;
                // Populate country select box from battuta API
                // countryCode = $("#country").val();
                region = $("#region").val();
                url =
                    "https://battuta.medunes.net/api/city/" +
                    countryCode +
                    "/search/?region=" +
                    region +
                    "&key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    console.log(data);
                    $("#city option").remove();
                    $('#city').append('<option value="">Please select your city</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#city").append(
                            '<option value="' + value.city + '">' + value.city + "</option>"
                        );
                    });
                });
            });
            // city selected --> update location string
            $("#city").on("change", function() {
                selectedCity = this.options[this.selectedIndex].text;
                $("#location").html(
                    "Locatation: Country: " +
                    selectedCountry +
                    ", Region: " +
                    selectedRegion +
                    ", City: " +
                    selectedCity
                );
            });
        });

        // very simple process form function to collect input values.
        function processForm() {
            var username = (password = country = region = city = "");
            username = $("#username").val();
            password = $("#password").val();
            country = $("#country").val();
            region = $("#region").val();
            city = $("#city").val();
            if (
                // username != "" &&
            // password != "" &&
                country != "" &&
                region != "" &&
                city != ""
            ) {
                $("#location").html(
                    // "Username: " +
                    //   username +
                    //   " /Password: " +
                    //   password +
                    "Locatation: Country: " +
                    country +
                    ", Region: " +
                    region +
                    ", City: " +
                    city
                );
            } else {
                $("#location").html("Fill Country, Region and City to view the location");
                return false;
            }
        }

    </script>

@stop
