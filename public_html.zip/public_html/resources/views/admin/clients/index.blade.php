@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Clients Manager</h1>
@stop

@section('content')
    <table id="clients_DataTable" class="table table-bordered table-striped table-responsive">
        <thead>
        <tr>
            <th>Name</th>
            <th>Status</th>
            <th>branches list</th>
            <th>Setting</th>
        </tr>
        </thead>
        <tbody>
        @foreach ($clients as $client)
            <tr class="text-center" style="font-size: 16px;">
                <td>{{ $client->client_name }}</td>
                <td><span class="label label-{{ ($client->status == "active") ? "success" : "danger" }}">{{ $client->status }}</span></td>
                <td>
                    <div class="dropdown">
                        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            {{ $client->branches->count() }}
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                            @foreach($client->branches as $branch)
                                <li>
                                    <a href="{{ route("clients.showbranch",$branch->id) }}">{{ $branch->branch_name }}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </td>
                <td>
                    <a href="{{ route('clients.edit',$client->id) }}" class="btn btn-success btn-xs">Edit</a>
                    <a href="#" class="btn btn-danger btn-xs" onclick="DeleteRecord('{{ route('clients.destroy',$client->id) }}','{{ csrf_token() }}');">Delete</a>
                    @if ($client->status == 'inactive')
                        <a href="#">Activate</a>
                    @endif
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>

@stop

@section('css')

@stop

@section('js')

    <script>
        $('#clients_DataTable').DataTable();

    </script>

@stop