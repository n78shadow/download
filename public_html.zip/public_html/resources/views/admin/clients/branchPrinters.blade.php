@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Update Print Variables</h1>
@stop

@section('content')


        <form action="{{ route('branch.printers.update',$transInfo["id"]) }}" method="post">
            <div class="row">
            <div class="col-md-4">
            @csrf
            @method('PUT')
            <div class="form-group has-feedback {{ $errors->has('resturant_name') ? 'has-error' : '' }}">
                <input type="text" name="resturant_name" class="form-control" value="{{ $transInfo["resturant_name"] }}"
                       placeholder="resturant name">
                @if ($errors->has('resturant_name'))
                    <span class="help-block">
                            <strong>{{ $errors->first('resturant_name') }}</strong>
                        </span>
                @endif
            </div>
            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="O" name="modeTrans" {{ $transInfo["modeTrans"] == "O" ? 'checked' : ''  }}>Operation Mode</label>
                <label class="radio-inline"><input type="radio" value="F" name="modeTrans" {{ $transInfo["modeTrans"] == "F" ? 'checked' : ''  }}>Training Mode</label>
            </div>
            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="yes" name="show_tips" {{ $transInfo["show_tips"] == "yes" ? 'checked' : ''  }}>Show Tips</label>
                <label class="radio-inline"><input type="radio" value="no" name="show_tips" {{ $transInfo["show_tips"] == "no" ? 'checked' : ''  }}>Hide Tips</label>
            </div>
            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="yes" name="html_print" {{ $transInfo["html_print"] == "yes" ? 'checked' : ''  }}>Html Print</label>
                <label class="radio-inline"><input type="radio" value="no" name="html_print" {{ $transInfo["html_print"] == "no" ? 'checked' : ''  }}>Mev Print</label>
            </div>
            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="notification" name="kitchen_mode" {{ $transInfo["kitchen_mode"] == "notification" ? 'checked' : ''  }}>Notification mode (supervisor only)</label>
                <label class="radio-inline"><input type="radio" value="paper" name="kitchen_mode" {{ $transInfo["kitchen_mode"] == "paper" ? 'checked' : ''  }}>Paper mode (category pinter only)</label>
                <label class="radio-inline"><input type="radio" value="both" name="kitchen_mode" {{ $transInfo["kitchen_mode"] == "both" ? 'checked' : ''  }}>both</label>
            </div>

            <div class="form-group">
                <label class="radio-inline"><input type="radio" value="numbers" name="table_mode" {{ $transInfo["table_mode"] == "numbers" ? 'checked' : ''  }}>Table mode</label>
                <label class="radio-inline"><input type="radio" value="take-out" name="table_mode" {{ $transInfo["table_mode"] == "take-out" ? 'checked' : ''  }}>Take out mode</label>
            </div>


            {{--<div class="form-group">
                <label class="radio-inline"><input type="radio" value="online" name="print_type" {{ $transInfo["print_type"] == "online" ? 'checked' : ''  }}>print node</label>
                <label class="radio-inline"><input type="radio" value="local" name="print_type" {{ $transInfo["print_type"] == "local" ? 'checked' : ''  }}>local</label>
            </div>--}}


            <div class="form-group">
                <textarea class="form-control" id="address_line_1" name="address_line_1" placeholder="address 1">{{ $transInfo["address_line_1"] }}</textarea>
            </div>

            <div class="form-group">
                <textarea class="form-control" id="address_line_2" name="address_line_2" placeholder="address 2">{{ $transInfo["address_line_2"] }}</textarea>
            </div>

            <div class="form-group">
                <textarea class="form-control" id="welcomeMsg" name="welcomeMsg" placeholder="Welcome Message">{{ $transInfo["welcomeMsg"] }}</textarea>
            </div>

            <div class="form-group">
                <label for="">app privileges</label>
                <select name="app_privileges[]" class="form-control" multiple>
                    <option value="table" {{ in_array("table",explode('-',$transInfo["app_privileges"])) ? 'selected' : '' }}>table</option>
                    <option value="takeAway" {{ in_array("takeAway",explode('-',$transInfo["app_privileges"])) ? 'selected' : '' }}>takeAway</option>
                    <option value="delivery" {{ in_array("delivery",explode('-',$transInfo["app_privileges"])) ? 'selected' : '' }}>delivery</option>
                    <option value="supervisor" {{ in_array("supervisor",explode('-',$transInfo["app_privileges"])) ? 'selected' : '' }}>supervisor</option>
                    <option value="kitchen" {{ in_array("kitchen",explode('-',$transInfo["app_privileges"])) ? 'selected' : '' }}>kitchen</option>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>
        </div>
                <div class="row">
                <div class="col-md-4">
                    <h1>Taxes</h1>
                    <div class="form-group">
                        <label for="">tps tax code</label>
                        <input type="text" class="form-control" name="tax_tps_code" value="{{ $transInfo["tax_tps_code"] }}">
                    </div>

                    <div class="form-group">
                        <label for="">tvq tax code</label>
                        <input type="text" class="form-control" name="tax_tvq_code" value="{{ $transInfo["tax_tvq_code"] }}">
                    </div>

                    <div class="form-group">
                        <label class="radio-inline"><input type="radio" value="yes" name="show_codes" {{ $transInfo["show_codes"] == "yes" ? 'checked' : ''  }}>show tax codes</label>
                        <label class="radio-inline"><input type="radio" value="no" name="show_codes" {{ $transInfo["show_codes"] == "no" ? 'checked' : ''  }}>hide tax codes</label>
                    </div>
                </div>
                </div>
        </div>
        </form>


    @stop

@section('css')

@stop

@section('js')

    <script>
        $('#create_branch_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var client = button.data('branch_name') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('Create new branch for client ' + client)
            $('#create_branch_modal').submit();
        })
    </script>


    <script>
        $(document).ready(function() {
            //-------------------------------SELECT CASCADING-------------------------//
            var selectedCountry = (selectedRegion = selectedCity = countryCode = "");

            // This is a demo API key for testing purposes. You should rather request your API key (free) from http://battuta.medunes.net/
            var BATTUTA_KEY = "00000000000000000000000000000000";
            // Populate country select box from battuta API
            url =
                "https://battuta.medunes.net/api/country/all/?key=" +
                BATTUTA_KEY +
                "&callback=?";

            // EXTRACT JSON DATA.
            $.getJSON(url, function(data) {
                console.log(data);
                $.each(data, function(index, value) {
                    // APPEND OR INSERT DATA TO SELECT ELEMENT. Set the country code in the id section rather than in the value.
                    $("#country").append(
                        '<option id="' +
                        value.code +
                        '" value="' +
                        value.name +
                        '">' +
                        value.name +
                        "</option>"
                    );
                });
            });
            // Country selected --> update region list .
            $("#country").change(function() {
                selectedCountry = this.options[this.selectedIndex].text;
// get the id of the option which has the country code.
                countryCode = $(this)
                    .children(":selected")
                    .attr("id");
                // Populate country select box from battuta API
                url =
                    "https://battuta.medunes.net/api/region/" +
                    countryCode +
                    "/all/?key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    $("#region option").remove();
                    $('#region').append('<option value="">Please select your region</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#region").append(
                            '<option value="' + value.region + '">' + value.region + "</option>"
                        );
                    });
                });
            });
            // Region selected --> updated city list
            $("#region").on("change", function() {
                selectedRegion = this.options[this.selectedIndex].text;
                // Populate country select box from battuta API
                // countryCode = $("#country").val();
                region = $("#region").val();
                url =
                    "https://battuta.medunes.net/api/city/" +
                    countryCode +
                    "/search/?region=" +
                    region +
                    "&key=" +
                    BATTUTA_KEY +
                    "&callback=?";
                $.getJSON(url, function(data) {
                    console.log(data);
                    $("#city option").remove();
                    $('#city').append('<option value="">Please select your city</option>');
                    $.each(data, function(index, value) {
                        // APPEND OR INSERT DATA TO SELECT ELEMENT.
                        $("#city").append(
                            '<option value="' + value.city + '">' + value.city + "</option>"
                        );
                    });
                });
            });
            // city selected --> update location string
            $("#city").on("change", function() {
                selectedCity = this.options[this.selectedIndex].text;
                $("#location").html(
                    "Locatation: Country: " +
                    selectedCountry +
                    ", Region: " +
                    selectedRegion +
                    ", City: " +
                    selectedCity
                );
            });
        });

        // very simple process form function to collect input values.
        function processForm() {
            var username = (password = country = region = city = "");
            username = $("#username").val();
            password = $("#password").val();
            country = $("#country").val();
            region = $("#region").val();
            city = $("#city").val();
            if (
                // username != "" &&
            // password != "" &&
                country != "" &&
                region != "" &&
                city != ""
            ) {
                $("#location").html(
                    // "Username: " +
                    //   username +
                    //   " /Password: " +
                    //   password +
                    "Locatation: Country: " +
                    country +
                    ", Region: " +
                    region +
                    ", City: " +
                    city
                );
            } else {
                $("#location").html("Fill Country, Region and City to view the location");
                return false;
            }
        }

    </script>

@stop
