@extends('adminlte::page')

@section('title', 'UPOS | taxes')

@section('content_header')
    <h1>Create New Tax</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('taxes.store') }}" method="post">
        @csrf
        <div class="form-group has-feedback {{ $errors->has('tax_name') ? 'has-error' : '' }}">
            <input type="text" name="tax_name" class="form-control" value="{{ old('tax_name') }}"
                   placeholder="tax name">
            @if ($errors->has('tax_name'))
                <span class="help-block">
                            <strong>{{ $errors->first('tax_name') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('percentage') ? 'has-error' : '' }}">
            <input type="text" name="percentage" class="form-control" value="{{ old('percentage') }}"
                   placeholder="percentage">
            @if ($errors->has('percentage'))
                <span class="help-block">
                            <strong>{{ $errors->first('percentage') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="create">
        </div>
    </form>
    </div>
@stop

@section('css')

@stop

@section('js')

@stop
