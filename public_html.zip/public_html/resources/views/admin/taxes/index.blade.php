@extends('adminlte::page')

@section('title', 'UPOS | taxes')

@section('content_header')
    <h1>taxes Manager</h1>
@stop

@section('content')
    <table id="taxes_DataTable" class="table table-bordered table-striped table-responsive">
        <thead>
        <tr>
            <th>tax name</th>
            <th>percentage</th>
            <th>settings</th>
        </tr>
        </thead>
        <tbody>
        @foreach ($taxes as $tax)
            <tr>
                <td>{{ $tax->tax_name }}</td>
                <td>{{ $tax->percentage }}</td><td>
                    <a href="{{ route('taxes.edit',$tax->id) }}" class="btn btn-success btn-xs">Edit</a>
                    <a href="#" class="btn btn-danger btn-xs" onclick="DeleteRecord('{{ route('taxes.destroy',$tax->id) }}','{{ csrf_token() }}');">Delete</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>

@stop

@section('css')

@stop

@section('js')

    <script>
        $('#taxes_DataTable').DataTable();
    </script>

@stop