@extends('adminlte::page')

@section('title', 'UPOS | taxes')

@section('content_header')
    <h1>Update {{ $tax->tax_name . ' Tax' }}</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('taxes.update',$tax->id) }}" method="post">
        @csrf
        @method('PUT')
        <div class="form-group has-feedback {{ $errors->has('tax_name') ? 'has-error' : '' }}">
            <input type="text" name="tax_name" class="form-control" value="{{ $tax->tax_name }}"
                   placeholder="tax name">
            @if ($errors->has('tax_name'))
                <span class="help-block">
                            <strong>{{ $errors->first('tax_name') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('percentage') ? 'has-error' : '' }}">
            <input type="text" name="percentage" class="form-control" value="{{ $tax->percentage }}"
                   placeholder="percentage">
            @if ($errors->has('percentage'))
                <span class="help-block">
                            <strong>{{ $errors->first('percentage') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Update">
        </div>
    </form>
    </div>
@stop

@section('css')

@stop

@section('js')

@stop
