@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Update {{ $role->name . ' Role'}}</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('roles.update',$role->id) }}" method="post">
        @csrf
        @method('PUT')
        <div class="form-group has-feedback {{ $errors->has('name') ? 'has-error' : '' }}">
            <input type="text" name="name" class="form-control" value="{{ $role->name }}"
                   placeholder="role name">
            @if ($errors->has('name'))
                <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('slug') ? 'has-error' : '' }}">
            <input type="text" name="slug" class="form-control" value="{{ $role->slug }}"
                   placeholder="slug">
            @if ($errors->has('slug'))
                <span class="help-block">
                            <strong>{{ $errors->first('slug') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('description') ? 'has-error' : '' }}">
            <textarea class="form-control" rows="5" name="description" placeholder="description">{{ $role->description }}</textarea>
            @if ($errors->has('description'))
                <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Update">

        </div>

    </form>
        <a href="#" data-toggle="modal" data-target="#create_permission_modal" class="btn btn-warning btn-xs right" data-roleid="{{ $role->id }}">add new permission</a>
    </div>


    <div class="modal fade" id="create_permission_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="exampleModalLabel">New message</h4>
                </div>
                <div class="modal-body">
                    <form>
                        @csrf

                        <div class="form-group">
                            <label for="name" class="control-label">Choose old permission:</label>
                            <select class="form-control itemsSelect" type="text" id="permission_id" name="permission_id">
                            </select>
                        </div>
                        <input type="hidden" name="role_id" id="role_id" value="{{ $role->id }}">
                        <input type="hidden" name="permissions_id" id="permissions_id" value="">
                        <div class="form-group new-permission">
                            <label for="name" class="control-label">New permission name:</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="form-group new-permission">
                            <label for="slug" class="control-label">Slug:</label>
                            <input type="text" class="form-control" id="slug" name="slug">
                        </div>
                        <div class="form-group new-permission">
                            <label for="description" class="control-label">description:</label>
                            <textarea class="form-control" id="description" name="description"></textarea>
                        </div>
                    </form>
                    <div class="lables-container">
                        @forelse($role->permissions as $permission)
                            <a href="#" class="badge badge-primary">{{ $permission->name }}</a>
                        @empty
                        @endforelse
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="attachPermission()">Create Permission</button>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="permission-type" value="new">
@stop

@section('css')

@stop

@section('js')

    <script>
        $('#create_permission_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var roleid = button.data('roleid') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('Create new permission for role ' + roleid)
            $('#create_permission_modal').submit();
        });

        function attachPermission() {
            var token = '{{ csrf_token() }}';
            var url = '{{ route('roles.permission.attach') }}';
            var data = {role_id: $('#role_id').val(), permission_id: $('#permissions_id').val(), _token :token};
            if ($("#permission-type").val() == "new") {
                url = '{{ route('permissions.store') }}';
                data = {role_id: $('#role_id').val(), name: $('#name').val(), slug: $('#slug').val(), description: $('#description').val(), _token :token};
            }
            console.log(data);
            console.log(url);
            $.ajax({
                url: url,
                type: 'post',
                data: data,
            }).done(function(data) {
                //window.location.reload();
                $('.lables-container').append('<a href="#" class="badge badge-primary">' + $('#name').val() + '</a>')
                $.notify({
                    // options
                    message: $('#name').val() + ' added to this role'
                },{
                    // settings
                    type: 'success',
                    placement: {
                        from: "bottom",
                        align: "right"
                    },
                    z_index: 10310,
                });
            }).fail(function(ex){
                console.log(ex);
            });
        }

        function searchingFor() {
            var url = '{{ route('roles.permissions.search') }}';
            if (url == '') {
                return;
            }
            $('.itemsSelect').select2({
                placeholder: "type any word to find ...",
                minimumInputLength: 2,
                width: "100%",
                dropdownParent: $('#create_permission_modal'),
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor();

        $('.itemsSelect').on('select2:select', function (event) {
            $(".new-permission").hide();
            $('#permission-type').val("old");
            var id = $(event.currentTarget).find("option:selected").val();
            var text = $(event.currentTarget).find("option:selected").text();
            $('#name').val(text);
            $('#permissions_id').val(id);
            $("#create_permission_form").attr("action", "{{ route("roles.permission.attach") }}");
        });
    </script>

@stop
