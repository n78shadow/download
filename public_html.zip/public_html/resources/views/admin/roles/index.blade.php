@extends('adminlte::page')

@section('title', 'UPOS | roles')

@section('content_header')
    <h1>roles Manager</h1>
@stop

@section('content')
    <table id="roles_DataTables" class="table table-bordered table-striped table-responsive">
        <thead>
        <tr>
            <th>Name</th>
            <th>description</th>
            <th>permissions list</th>
            <th>settings</th>
        </tr>
        </thead>
        <tbody>
        @foreach ($roles as $role)
            <tr>
                <td>{{ $role->name }}</td>
                <td>{{ $role->description }}</td>
                <td>
                    <select class="pemissions_list">
                        <option></option>
                        @foreach($role->permissions as $permission)
                            <option value="[{{ $role->id }}, {{ $permission->id }}]">{{ $permission->name }} <a href="#" class="btn btn-success right">delete</a></option>
                        @endforeach
                    </select>
                </td>
                <td>
                    <a href="{{ route('roles.edit',$role->id) }}" class="btn btn-success btn-xs">Edit</a>
                    <a href="#" class="btn btn-danger btn-xs" onclick="DeleteRecord('{{ route('roles.destroy',$role->id) }}','{{ csrf_token() }}');">Delete</a>
                </td>
            </tr>
        @endforeach

        </tbody>
    </table>

@stop

@section('css')

@stop

@section('js')

    <script>
        $('#roles_DataTables').DataTable();
        $('.pemissions_list').select2({
            theme: "bootstrap",
            placeholder: "Type permession name",
            width: "100%"
        });

        $('.pemissions_list').on('select2:select', function (event) {
            var id = JSON.parse($(event.currentTarget).find("option:selected").val());
            var text = $(event.currentTarget).find("option:selected").text();

            if (confirm("Are you sure to delete " + text + " From this role")) {
                var role_id = id[0];
                var permission_id = id[1];
                var url = '{{ route('roles.permission.delete') }}';
                var token = '{{ csrf_token() }}';
                $.ajax({
                    url: url,
                    type: 'post',
                    data: {role_id: role_id, permission_id: permission_id, _token :token},
                }).done(function(data) {
                    window.location.reload();
                }).fail(function(ex){
                    console.log(ex);
                });
            }
        });

    </script>

@stop