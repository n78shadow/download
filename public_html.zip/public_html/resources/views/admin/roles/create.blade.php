@extends('adminlte::page')

@section('title', 'UPOS | Roles')

@section('content_header')
    <h1>Create New Role</h1>
@stop

@section('content')
    <div class="col-md-4">
    <form action="{{ route('roles.store') }}" method="post">
        @csrf
        <div class="form-group has-feedback {{ $errors->has('name') ? 'has-error' : '' }}">
            <input type="text" name="name" class="form-control" value="{{ old('name') }}"
                   placeholder="role name">
            @if ($errors->has('name'))
                <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('slug') ? 'has-error' : '' }}">
            <input type="text" name="slug" class="form-control" value="{{ old('slug') }}"
                   placeholder="slug">
            @if ($errors->has('slug'))
                <span class="help-block">
                            <strong>{{ $errors->first('slug') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group has-feedback {{ $errors->has('description') ? 'has-error' : '' }}">
            <textarea class="form-control" rows="5" name="description" placeholder="description">{{ old('description') }}</textarea>
            @if ($errors->has('description'))
                <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
            @endif
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="create">
        </div>
    </form>
    </div>
@stop

@section('css')

@stop

@section('js')

@stop
