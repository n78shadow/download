@extends('adminlte::page')

@section('title', 'UPOS | Clients')

@section('content_header')
    <h1>Update {{ $role->name . ' Role'}}</h1>
@stop


@section('content')
    <div class="col-md-4">
        <form action="{{ route('roles.kitchens.add') }}" method="post" id="create_permission_form">
            @csrf
            <input type="hidden" name="role_id" id="role_id" value="{{ $role->id }}">
            <div class="form-group">
                <label for="name" class="control-label">Name:</label>
                <select class="form-control itemsSelect" type="text" id="category_id" name="category_id">
                </select>
            </div>
            <input type="hidden" id="categories_id">
            <input type="hidden" id="category_name">
            <!--<div class="form-group">
                <label for="slug" class="control-label">Slug:</label>
                <input type="text" class="form-control" id="slug" name="slug">
            </div>
            <div class="form-group">
                <label for="description" class="control-label">description:</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div> -->

        </form>
        <div class="lables-container">
            @forelse($role->categories as $category)
                <a href="#" class="badge badge-primary">{{ $category->en_name }}</a>
            @empty
            @endforelse
        </div>
        <div class="form-group" style="margin-top: 1rem">
            <input type="submit" onclick="attachCategory()" class="btn btn-primary" value="Update">

        </div>
    </div>




@stop

@section('css')

@stop

@section('js')

    <script>
        $('#create_permission_modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var roleid = button.data('roleid') // Extract info from data-* attributes
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var modal = $(this)
            modal.find('.modal-title').text('Create new permission for role ' + roleid)
            $('#create_permission_modal').submit();
        });

        function attachCategory() {
            var token = '{{ csrf_token() }}';
            var url = '{{ route('roles.kitchens.add') }}';
            var data = {role_id: $('#role_id').val(), category_id: $('#categories_id').val(), _token :token};
            console.log(data);
            console.log(url);
            $.ajax({
                url: url,
                type: 'post',
                data: data,
            }).done(function(data) {
                //window.location.reload();
                $('.lables-container').append('<a href="#" class="badge badge-primary">' + $('#category_name').val() + '</a>')
                $.notify({
                    // options
                    message: $('#category_name').val() + ' added to this role'
                },{
                    // settings
                    type: 'success',
                    placement: {
                        from: "bottom",
                        align: "right"
                    },
                    z_index: 10310,
                });
            }).fail(function(ex){
                console.log(ex);
            });
        }

        $('.itemsSelect').on('select2:select', function (event) {
            var id = $(event.currentTarget).find("option:selected").val();
            var text = $(event.currentTarget).find("option:selected").text();
            $('#category_name').val(text);
            $('#categories_id').val(id);
        });

        function searchingFor() {
            var url = '{{ route('roles.kitchens.search') }}';
            if (url == '') {
                return;
            }
            $('.itemsSelect').select2({
                placeholder: "type any word to find ...",
                minimumInputLength: 2,
                width: "100%",
                ajax: {
                    url: url,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: $.trim(params.term)
                        };
                    },
                    processResults: function (data) {
                        //console.log(data);
                        return {
                            results: data
                        };
                    },
                    error: function (err) {
                        console.log(err);
                    },
                    cache: true
                }
            });
        }

        searchingFor();
    </script>

@stop
