@extends('adminlte::page')

@section('title', 'UPOS | Dashboard')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')

    <div class="col-md-3">
            <button class="btn btn-primary btn-block" data-toggle="modal" data-target="#change_password_modal"> <h1 class="text-center">Change Password</h1></button>
    </div>



    <div class="modal fade" id="change_password_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="gridSystemModalLabel">Enter New Password</h4>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.password.change') }}" id="change_password_form" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="">username</label>
                            <input type="text" class="form-control" name="username" value="{{ auth()->user()->username }}">
                        </div>
                        <div class="form-group">
                            <label for="">password</label>
                            <input type="password" class="form-control" name="password">
                        </div>

                        <div class="form-group">
                            <label for="">confirm password</label>
                            <input type="password" class="form-control" name="password_confirmation">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="$('#change_password_form').submit()">Save changes</button>
                </div>
            </div>
        </div>
    </div>

@stop

@section('css')

@stop

@section('js')

@stop
