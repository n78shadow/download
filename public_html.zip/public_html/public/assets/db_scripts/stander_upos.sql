-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.37-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

use @db_name@;

-- Dumping structure for table upos_stander.branches
CREATE TABLE IF NOT EXISTS `branches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(191) NOT NULL,
  `branch_logo` varchar(191) NOT NULL DEFAULT 'branch_default.png',
  `country` varchar(191) DEFAULT NULL,
  `region` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `timezone` varchar(191) NOT NULL DEFAULT 'GMT-5',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `address` text,
  `lat` text,
  `lng` text,
  `client_id` int(10) unsigned NOT NULL,
  `app_access_username` varchar(50) NOT NULL,
  `app_access_password` varchar(50) NOT NULL,
  `app_access_token` varchar(255) NOT NULL,
  `database_name` varchar(50) DEFAULT NULL,
  `token_expired` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.branches: ~0 rows (approximately)


-- Dumping structure for table upos_stander.branch_tax
CREATE TABLE IF NOT EXISTS `branch_tax` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.branch_tax: ~0 rows (approximately)
/*!40000 ALTER TABLE `branch_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch_tax` ENABLE KEYS */;

-- Dumping structure for table upos_stander.branch_transinfos
CREATE TABLE IF NOT EXISTS `branch_transinfos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `resturant_name` varchar(100) DEFAULT NULL,
  `address_line_1` varchar(100) DEFAULT NULL,
  `address_line_2` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `welcomeMsg` varchar(255) DEFAULT NULL,
  `modeTrans` enum('F','O') NOT NULL DEFAULT 'F',
  `show_tips` enum('yes','no') NOT NULL DEFAULT 'no',
  `html_print` enum('yes','no') NOT NULL DEFAULT 'no',
  `kitchen_mode` enum('notification','paper','both') DEFAULT 'notification',
  `table_mode` enum('numbers','take-out') NOT NULL DEFAULT 'numbers',
  `app_privileges` varchar(50) NOT NULL DEFAULT 'table-takeAway-delivery',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.branch_transinfos: ~0 rows (approximately)
/*!40000 ALTER TABLE `branch_transinfos` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch_transinfos` ENABLE KEYS */;

-- Dumping structure for table upos_stander.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `en_name` varchar(191) NOT NULL,
  `fr_name` varchar(191) NOT NULL,
  `category_color` varchar(191) DEFAULT '#ccc',
  `category_description` text,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `branch_id` int(10) unsigned DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_parent_category` (`parent_id`),
  KEY `fk_branch_id` (`branch_id`),
  CONSTRAINT `fk_branch_id` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `fk_parent_category` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.categories: ~0 rows (approximately)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Dumping structure for table upos_stander.category_printer
CREATE TABLE IF NOT EXISTS `category_printer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `printer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.category_printer: ~0 rows (approximately)
/*!40000 ALTER TABLE `category_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_printer` ENABLE KEYS */;

-- Dumping structure for table upos_stander.category_product
CREATE TABLE IF NOT EXISTS `category_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `sequence` int(10) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_id` (`product_id`),
  KEY `fk_category_id` (`category_id`),
  CONSTRAINT `fk_category_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.category_product: ~0 rows (approximately)
/*!40000 ALTER TABLE `category_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_product` ENABLE KEYS */;

-- Dumping structure for table upos_stander.category_role
CREATE TABLE IF NOT EXISTS `category_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.category_role: ~0 rows (approximately)
/*!40000 ALTER TABLE `category_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_role` ENABLE KEYS */;

-- Dumping structure for table upos_stander.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_name` varchar(191) NOT NULL,
  `client_logo` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.clients: ~0 rows (approximately)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Dumping structure for table upos_stander.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `street_number` varchar(100) DEFAULT NULL,
  `apartment` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.customers: ~0 rows (approximately)
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Dumping structure for table upos_stander.customizes
CREATE TABLE IF NOT EXISTS `customizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL DEFAULT '0',
  `branch_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.customizes: ~0 rows (approximately)
/*!40000 ALTER TABLE `customizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `customizes` ENABLE KEYS */;

-- Dumping structure for table upos_stander.customize_groups
CREATE TABLE IF NOT EXISTS `customize_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customize_id` int(11) NOT NULL DEFAULT '0',
  `assignable_type` varchar(100) DEFAULT NULL COMMENT '-- related model type',
  `assignable_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customize_name` (`customize_id`),
  CONSTRAINT `fk_customize_name` FOREIGN KEY (`customize_id`) REFERENCES `customizes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='-- customize groups for categories or for products also ';

-- Dumping data for table upos_stander.customize_groups: ~0 rows (approximately)
/*!40000 ALTER TABLE `customize_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customize_groups` ENABLE KEYS */;

-- Dumping structure for table upos_stander.customize_items
CREATE TABLE IF NOT EXISTS `customize_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_name` varchar(100) NOT NULL,
  `custom_price` varchar(100) NOT NULL DEFAULT '0',
  `customize_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customize` (`customize_id`),
  CONSTRAINT `fk_customize` FOREIGN KEY (`customize_id`) REFERENCES `customizes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.customize_items: ~0 rows (approximately)
/*!40000 ALTER TABLE `customize_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `customize_items` ENABLE KEYS */;

-- Dumping structure for table upos_stander.deliveries
CREATE TABLE IF NOT EXISTS `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `note` text,
  `delivery_time` varchar(100) DEFAULT NULL,
  `delivered` enum('yes','no') DEFAULT 'no',
  `delivered_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.deliveries: ~0 rows (approximately)
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;

-- Dumping structure for table upos_stander.invoices
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `status` enum('addition_print','cancel_addition_print','eq_splitted','clients_splitted','combined','paid','refunded','closed','repaid') NOT NULL,
  `is_partial` enum('yes','no') NOT NULL DEFAULT 'no',
  `table_number` varchar(255) DEFAULT NULL,
  `sub_total` decimal(10,2) DEFAULT NULL,
  `sub_total_without_discount` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `title` varchar(255) DEFAULT NULL,
  `invoice_reference` text,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.invoices: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;

-- Dumping structure for table upos_stander.invoice_details
CREATE TABLE IF NOT EXISTS `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `is_tasting` enum('yes','no') NOT NULL DEFAULT 'no',
  `has_tax` enum('yes','no') NOT NULL DEFAULT 'yes',
  `item_count` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_clients` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.invoice_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_details` ENABLE KEYS */;

-- Dumping structure for table upos_stander.invoice_taxes
CREATE TABLE IF NOT EXISTS `invoice_taxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `tax_name` varchar(100) NOT NULL,
  `tax_value` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.invoice_taxes: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_taxes` ENABLE KEYS */;

-- Dumping structure for table upos_stander.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table upos_stander.jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;

-- Dumping structure for table upos_stander.log_orders
CREATE TABLE IF NOT EXISTS `log_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.log_orders: ~0 rows (approximately)
/*!40000 ALTER TABLE `log_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_orders` ENABLE KEYS */;

-- Dumping structure for table upos_stander.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.migrations: ~0 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table upos_stander.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `printer_id` int(11) DEFAULT NULL,
  `table_number` varchar(50) NOT NULL DEFAULT 'take-out',
  `status` enum('active','hold','closed','paid') NOT NULL DEFAULT 'active',
  `bar_status` enum('active','hold','closed','paid') NOT NULL DEFAULT 'active',
  `type` enum('postpaid','prepaid','delivery','take-out') NOT NULL DEFAULT 'postpaid',
  `cost` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `discount` decimal(10,2) DEFAULT '0.00',
  `note` mediumtext,
  `sequence` int(11) DEFAULT '1',
  `sequence_string` varchar(50) DEFAULT NULL,
  `invoiced_details` int(11) DEFAULT '0',
  `visited_by` varchar(100) DEFAULT NULL,
  `allowed_op` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.orders: ~0 rows (approximately)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Dumping structure for table upos_stander.order_details
CREATE TABLE IF NOT EXISTS `order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `replace_id` int(11) DEFAULT NULL,
  `product_customizes` mediumtext,
  `product_optionals` mediumtext,
  `client_number` mediumtext,
  `dish_number` int(11) DEFAULT NULL,
  `service_number` int(11) DEFAULT NULL,
  `service_status` enum('Called','ToBeCall') NOT NULL DEFAULT 'ToBeCall',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `isServed` enum('0','1','2') DEFAULT '0',
  `tasting_id` int(11) DEFAULT NULL,
  `tasting_sequence` int(11) DEFAULT NULL,
  `served_date` datetime DEFAULT NULL,
  `call_time` time DEFAULT NULL,
  `call_date` datetime DEFAULT NULL,
  `note` mediumtext,
  `invoiced` enum('yes','no') DEFAULT 'no',
  `user_id` int(11) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.order_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;

-- Dumping structure for table upos_stander.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table upos_stander.paymentgatewayes
CREATE TABLE IF NOT EXISTS `paymentgatewayes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(50) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.paymentgatewayes: ~8 rows (approximately)
/*!40000 ALTER TABLE `paymentgatewayes` DISABLE KEYS */;
INSERT INTO `paymentgatewayes` (`id`, `gateway_name`, `parent_id`, `created_at`, `updated_at`) VALUES
	(1, 'cash', NULL, '2019-02-21 20:14:36', '2019-02-21 20:14:39'),
	(2, 'credit', NULL, '2019-02-21 20:15:04', '2019-02-21 20:15:03'),
	(3, 'debit', NULL, '2019-02-21 20:15:37', '2019-02-21 20:15:39'),
	(4, 'coupon', NULL, '2019-02-21 20:19:54', '2019-02-21 20:19:55'),
	(5, 'master_card', 2, '2019-02-21 20:17:50', '2019-02-21 20:17:53'),
	(6, 'visa_card', 2, '2019-02-21 20:18:16', '2019-02-21 20:18:20'),
	(7, 'amx', 2, '2019-02-21 20:18:38', '2019-02-21 20:18:40'),
	(8, 'other_card', 2, '2019-02-21 20:19:15', '2019-02-21 20:19:16');
/*!40000 ALTER TABLE `paymentgatewayes` ENABLE KEYS */;

-- Dumping structure for table upos_stander.payments
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paymentGateway_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `paid_value` decimal(10,2) NOT NULL,
  `tips_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.payments: ~0 rows (approximately)
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

-- Dumping structure for table upos_stander.permissions
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.permissions: ~17 rows (approximately)
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
	(1, 'Payment', 'payment', 'payment test', '2019-02-05 23:56:47', '2019-02-05 23:56:47'),
	(2, 'print invoice', 'print_invoice', NULL, '2019-02-05 23:57:27', '2019-02-05 23:57:27'),
	(3, 'Supervisor', 'supervisor', NULL, '2019-02-06 00:02:10', '2019-02-06 00:02:10'),
	(4, 's-super', 's_super', NULL, '2019-02-06 00:04:51', '2019-02-06 00:04:51'),
	(5, 'Salad-kitchen', 'salad-kitchen', NULL, '2019-02-07 05:00:04', '2019-02-07 05:00:04'),
	(6, 'kitchen', 'kitchen', NULL, '2019-02-07 05:06:48', '2019-02-07 05:06:48'),
	(7, 'Category Admin', 'category_admin', 'Admin for linking subcategories and items to category', '2019-02-08 02:01:52', '2019-02-08 02:01:52'),
	(8, 'Items Admin', 'items_admin', 'Can view, add and edit items', '2019-02-08 02:02:26', '2019-02-08 02:02:26'),
	(9, 'Tasting Admin', 'tasting_admin', 'Adding, Editing and viewing tasting and its items and replacement', '2019-02-08 02:02:49', '2019-02-08 02:02:49'),
	(10, 'Preperation', 'preperation', 'Access preperation page', '2019-02-08 02:03:11', '2019-02-08 02:03:11'),
	(11, 'Users Admin', 'users_admin', 'Add, Edit and View users', '2019-02-08 02:03:37', '2019-02-08 02:03:37'),
	(12, 'product admin', 'product_admin', 'manage items', '2019-02-11 04:26:37', '2019-02-11 04:26:37'),
	(13, 'Login', 'login', 'Can login to system', '2019-03-20 05:04:29', '2019-03-20 05:04:29'),
	(14, 'Reports', 'reports', 'Can Access Reports Page', '2019-03-20 05:05:59', '2019-03-20 05:05:59'),
	(15, 'Punch In & Out', 'punch', 'Access Punch In page', '2019-03-20 05:07:08', '2019-03-20 05:07:08'),
	(16, 'Printers', 'printers', NULL, '2019-03-20 05:18:21', '2019-03-20 05:18:21'),
	(17, 'Tasting Admin', 'tasting-admin', NULL, '2019-03-24 22:12:48', '2019-03-24 22:12:48');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

-- Dumping structure for table upos_stander.permission_role
CREATE TABLE IF NOT EXISTS `permission_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_index` (`permission_id`),
  KEY `permission_role_role_id_index` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.permission_role: ~25 rows (approximately)
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 8, '2019-02-05 23:56:47', '2019-02-05 23:56:47'),
	(3, 2, 8, '2019-02-05 23:58:42', '2019-02-05 23:58:42'),
	(46, 1, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(47, 2, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(48, 3, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(49, 4, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(50, 5, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(51, 6, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(52, 7, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(53, 8, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(54, 9, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(55, 10, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(56, 11, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(57, 12, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(58, 13, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(59, 14, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(60, 15, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(61, 16, 6, '2019-03-20 05:25:39', '2019-03-20 05:25:39'),
	(62, 13, 25, '2019-03-20 05:42:01', '2019-03-20 05:42:01'),
	(67, 3, 9, '2019-03-23 23:24:25', '2019-03-23 23:24:25'),
	(68, 13, 9, '2019-03-23 23:24:25', '2019-03-23 23:24:25'),
	(69, 4, 10, '2019-03-23 23:24:34', '2019-03-23 23:24:34'),
	(78, 6, 11, '2019-03-23 23:30:07', '2019-03-23 23:30:07'),
	(79, 13, 11, '2019-03-23 23:30:07', '2019-03-23 23:30:07'),
	(80, 17, 26, '2019-03-24 22:12:56', '2019-03-24 22:12:56');
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;

-- Dumping structure for table upos_stander.printers
CREATE TABLE IF NOT EXISTS `printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(100) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `printer_name` varchar(100) DEFAULT NULL,
  `printer_type` enum('mev','normal') DEFAULT 'normal',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.printers: ~0 rows (approximately)
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;

-- Dumping structure for table upos_stander.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(10) unsigned NOT NULL,
  `en_name` varchar(191) NOT NULL,
  `fr_name` varchar(191) NOT NULL,
  `short_name` varchar(191) NOT NULL,
  `tasting_name` varchar(191) DEFAULT NULL,
  `limit_quantity` int(11) DEFAULT '0',
  `limit_discount` int(11) DEFAULT '0',
  `description` text,
  `cost` decimal(10,2) NOT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `delivery_price` varchar(191) DEFAULT '0',
  `is_taxed` enum('yes','no') NOT NULL DEFAULT 'yes',
  `is_bar` enum('yes','no') NOT NULL DEFAULT 'no',
  `sequence` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_branch_id_index` (`branch_id`),
  CONSTRAINT `fk_product_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.products: ~0 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table upos_stander.product_basics
CREATE TABLE IF NOT EXISTS `product_basics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_name` varchar(50) NOT NULL,
  `basic_name_fr` varchar(50) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.product_basics: ~0 rows (approximately)
/*!40000 ALTER TABLE `product_basics` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_basics` ENABLE KEYS */;

-- Dumping structure for table upos_stander.product_optionals
CREATE TABLE IF NOT EXISTS `product_optionals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_name` varchar(100) DEFAULT NULL,
  `option_name_fr` varchar(100) DEFAULT NULL,
  `option_price` int(11) NOT NULL DEFAULT '0',
  `option_cost` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.product_optionals: ~0 rows (approximately)
/*!40000 ALTER TABLE `product_optionals` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_optionals` ENABLE KEYS */;

-- Dumping structure for table upos_stander.product_tasting
CREATE TABLE IF NOT EXISTS `product_tasting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasting_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `service_number` int(11) DEFAULT NULL,
  `replacement_of` int(11) DEFAULT NULL,
  `categories_list` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.product_tasting: ~0 rows (approximately)
/*!40000 ALTER TABLE `product_tasting` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_tasting` ENABLE KEYS */;

-- Dumping structure for table upos_stander.punches
CREATE TABLE IF NOT EXISTS `punches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `status` enum('in','out') DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.punches: ~0 rows (approximately)
/*!40000 ALTER TABLE `punches` DISABLE KEYS */;
/*!40000 ALTER TABLE `punches` ENABLE KEYS */;

-- Dumping structure for table upos_stander.punches_logins
CREATE TABLE IF NOT EXISTS `punches_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `punch_id` int(11) NOT NULL,
  `enter_date` datetime NOT NULL,
  `exit_date` datetime DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `order_counts` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.punches_logins: ~0 rows (approximately)
/*!40000 ALTER TABLE `punches_logins` DISABLE KEYS */;
/*!40000 ALTER TABLE `punches_logins` ENABLE KEYS */;

-- Dumping structure for table upos_stander.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.roles: ~15 rows (approximately)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
	(5, 'Administrator', 'administrator', 'system administrator', '2018-12-28 09:52:43', '2018-12-28 09:52:43'),
	(6, 'Branch Admin', 'branch_admin', 'have all branch permissions', '2018-12-28 09:53:55', '2018-12-28 09:53:55'),
	(7, 'Branch General Supervisor', 'branch_general_supervisor', 'general branch supervisor', '2018-12-28 10:00:18', '2018-12-28 10:01:09'),
	(8, 'Waiter', 'waiter', 'waiter test', '2019-02-05 23:55:14', '2019-02-05 23:55:14'),
	(9, 'Super', 'super', NULL, '2019-02-06 00:00:48', '2019-02-07 04:56:28'),
	(10, 'S-Super', 's-super', NULL, '2019-02-06 00:03:10', '2019-02-07 05:12:06'),
	(11, 'Kitchen', 'kitchen', NULL, '2019-02-07 04:58:07', '2019-03-21 19:46:21'),
	(19, 'salad access', 'super-salad', NULL, '2019-02-07 05:28:47', '2019-03-21 20:17:41'),
	(20, 'suate access', 'super-suate', NULL, '2019-02-07 05:29:51', '2019-03-21 20:18:11'),
	(21, 'grill access', 'Super-grill', NULL, '2019-02-07 05:30:04', '2019-03-21 20:18:51'),
	(22, 'bar access', 'super_bar', NULL, '2019-02-07 05:30:24', '2019-03-21 20:19:08'),
	(23, 'Products', 'products', NULL, '2019-02-07 05:38:46', '2019-02-07 05:38:46'),
	(24, 'Report', 'report', NULL, '2019-02-07 05:39:07', '2019-02-07 05:39:07'),
	(25, 'Backend-login', 'Backendlogin', NULL, '2019-03-20 05:42:01', '2019-03-20 05:42:01'),
	(26, 'Tasting Admin', 'tasting-admin', 'Can See all tasting items in the kitchen', '2019-03-24 22:12:56', '2019-03-24 22:12:56');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table upos_stander.role_user
CREATE TABLE IF NOT EXISTS `role_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8;


-- Dumping structure for table upos_stander.tastings
CREATE TABLE IF NOT EXISTS `tastings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `en_name` varchar(100) NOT NULL,
  `fr_name` varchar(100) NOT NULL,
  `cost` decimal(10,0) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `is_taxed` enum('yes','no') NOT NULL DEFAULT 'yes',
  `color` varchar(50) NOT NULL,
  `branch_id` int(11) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.tastings: ~0 rows (approximately)
/*!40000 ALTER TABLE `tastings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tastings` ENABLE KEYS */;

-- Dumping structure for table upos_stander.taxes
CREATE TABLE IF NOT EXISTS `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(191) NOT NULL,
  `percentage` decimal(10,3) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.taxes: ~2 rows (approximately)
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` (`id`, `tax_name`, `percentage`, `created_at`, `updated_at`) VALUES
	(3, 'TPS', 5.000, '2019-02-12 12:30:43', '2019-05-08 04:09:50'),
	(4, 'TVQ', 9.975, '2019-02-12 12:30:45', '2019-05-08 04:09:57');
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;

-- Dumping structure for table upos_stander.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `username` varchar(191) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `access_code` varchar(191) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `job` enum('Administrator','Supervisor','Kitchen','waiter','Cleaner') NOT NULL,
  `status` enum('active','inactive','blocked') NOT NULL DEFAULT 'active',
  `branch_id` int(10) unsigned DEFAULT NULL,
  `default_route` varchar(255) DEFAULT 'clients.sitemap',
  `salary` decimal(10,2) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- Dumping data for table upos_stander.users: ~3 rows (approximately)


/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
