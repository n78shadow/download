/*************************************************
 ==================================================
 ||     General Classes      ||
 ||     By : Adnan Diab      ||
 ==================================================
 *************************************************/

//activate tooltip
$('.sideNav > a').tooltip() ;

//activate Breadcrumb
$(document).ready(function(){
    $("#showBreadCrumbs").click(function(){
        $(this).hide();
        $(".breadcrumb").show();
    });
});

//Active link Srtyle JS CODE
$('.sideNav > a').click(function(){
    $(".sideNav > a").removeClass('active');
    $(this).addClass('active');
});

$('.bottomBTNtab').click(function(){
    $("#bottomTabs > a").removeClass('active');
    $(this).toggleClass('active');
});

$('.sideIconNav > a').click(function(){
    $(".sideIconNav > a").removeClass('active');
    $(this).toggleClass('active');
});

$('.ofcathotTabs').click(function(){
    $(".ofcathotTabs").removeClass('active');
    $(this).toggleClass('active');
});

$('.avilableDriverModal').click(function(){
    $(".avilableDriverModal").removeClass('active');
    $(this).toggleClass('active');
});

// End Active Links JS Code


//add class to item to watch Details when we click on it
$(document).ready(function(){

    $('.services > ul').addClass('itemSelectedDetails');

});

$('.services > ul > li').click(function (){
    $(".itemSelectedDetails > li").removeClass('itemDetails');
    $(this).toggleClass('itemDetails');
});


//increase and decrease input [touch and keyboard]
function increaseValue() {
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('number').value = value;
}

function decreaseValue() {
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;
    document.getElementById('number').value = value;
}


