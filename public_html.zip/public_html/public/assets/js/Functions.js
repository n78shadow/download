function DeleteRecord(url,token)
{
    Swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: url,
                type: 'post',
                data: {_method: 'delete', _token :token},
            }).done(function() {
                Swal(
                    'Deleted!',
                    'Your Record has been deleted.',
                    'success'
                ).then(function(){
                        location.reload();
                    }
                );

            }).fail(function(ex){
                console.log(ex);
                Swal(
                    'Error',
                    ex.status + ' ' +  ex.statusText,
                    'error'
                )
            });

        }
    })


}


function DeleteRecordNormal(url,token,redirect = false) {
    if (confirm('Are you sure you want to delete this record ?')) {
        $.ajax({
            url: url,
            type: 'post',
            data: {_method: 'delete', _token :token},
        }).done(function() {
            if(redirect)
            {window.location.replace(redirect);}

        }).fail(function(ex){
            console.log(ex);
        });
        return true;
    } else {
        return false;
    }
}

function SubmitForm(formId)
{
    $('#'+formId).submit();
}