var printFile = function (id,str) {
    var API_KEY = 'e4d0e705480b29cadc47f1afcaef03ebff4ccc55';
    var options = {
        // changes the value of 'this' in the success, error, timeout and complete
        // handlers. The default value of 'this' is the instance of the PrintNodeApi
        // object used to make the api call
        context: null,
        // called if the api call was a 2xx success
        success: function (response, headers, xhrObject) {
            console.log(this);
            console.log("success", response, headers);
        },
        // called if the api call failed in any way
        error: function (response, headers, xhrObject) {
            console.log("error", response, headers);
        },
        // called afer the api call has completed after success or error callback
        complete: function (xhrObject) {
          console.log(
              "%d %s %s returned %db in %dms",
              response.xhr.status,
              response.reqMethod,
              response.reqUrl,
              response.xhr.responseText.length,
              response.getDuration()
          );
        },
        // called if the api call timed out
        timeout: function (url, duration) {
            console.log("timeout", url, duration);
        },
        // the timeout duration in ms
        timeoutDuration: 3000
    };

    var api = new PrintNode.HTTP(
        new PrintNode.HTTP.ApiKey(API_KEY),
        options
    );
    
        var CallbackOptions = {
            // changes the value of 'this' in the success, error, timeout and complete
            // handlers. The default value of 'this' is the instance of the PrintNodeApi
            // object used to make the api call
            context: null,
            // called if the api call was a 2xx success
            success: function (response, headers, xhrObject) {
               console.log("success",response);
            },
            // called if the api call failed in any way
            error: function (response, headers, xhrObject) {
                console.log("error", response);
            },
            // called afer the api call has completed after success or error callback
            complete: function (xhrObject) {;  
              console.log("complete",xhrObject.response);   
              //console.log(api.getState());   
            },
            // called if the api call timed out
            timeout: function (url, duration) {
                console.log("timeout", url, duration);
            },
            // the timeout duration in ms
            timeoutDuration: 3000
        }; 

                           
        var printJobPayload = {
            "printer": id,
            "title": "test printjob",
            "contentType": "raw_base64",
            "content": str,    
            "source": "javascript api client",
            //"options":{
                //"paper": "ZPrinter Paper(80(72) x 210mm)",
                //"endJob": "<DD>",
            //} 
        };
        api.createPrintjob(CallbackOptions, printJobPayload);
        //api.printers(CallbackOptions);        
    
    
};