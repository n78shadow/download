let host = "127.0.0.1";
let RedisPort = "6379";
let nodePort = "2053";
let server = require('http').Server();

/*

const https = require('https');
const fs = require('fs');

const options = {
    key: fs.readFileSync('key.pem','utf8'),
    cert: fs.readFileSync('csr.pem','utf8'),
    requestCert: true,
    rejectUnauthorized: false,
};
*/



//server = https.createServer(options);


let io = require('socket.io')(server);


let redis = require('redis'),
    client = redis.createClient(RedisPort,host);






server.listen(nodePort);

client.subscribe('order-created-channel');
client.subscribe('order-updated-channel');
client.subscribe('order-paid-channel');
client.subscribe('order-delete-channel');
client.subscribe('order-splitted-channel');
client.subscribe('order-transferred-channel');

client.on("message", function (channel, message) {
    if (channel == "order-created-channel")
    {
        io.sockets.emit('order_created', message);
    }

    if (channel == "order-updated-channel")
    {
        io.sockets.emit('order_updated', message);
    }

    if (channel == "order-paid-channel")
    {
        io.sockets.emit('order_closed', message);
    }

    if (channel == "order-delete-channel")
    {
        io.sockets.emit('order_deleted', message);
    }

    if (channel == "order-splitted-channel")
    {
        io.sockets.emit('order_splitted', message);
    }

    if (channel == "order-transferred-channel")
    {
        io.sockets.emit('order_transferred', message);
    }



});


client.on("error", function (err) {
    console.log("Error " + err);
});

// let data = {
//     normal:[],
//     bar:[]
// }


//await storage.init();

io.on('connection' ,(socket) => {

    //   socket.on('savedata',function(info){
    //         let savedata = JSON.parse(info);
    //         let {type,Called} = savedata;
    //         data[type] = [];
    //         data[type] = Called;



    //   });



    //   socket.on('retrive_data',function(){


    //       io.to(socket.id).emit('new_data',JSON.stringify(data));
    //   })

    console.log('made socket connection', socket.id);


    socket.on('updateinvoices',function (data) {
        console.log('ok done');
        socket.broadcast.emit('broadcast', data);
    });

    socket.on('serve_item',function(data){
        // socket.broadcast.emit('serveitem',data);
        io.sockets.emit('serveitem',data);
    });

    socket.on('call_service',function(data){
        //socket.broadcast.emit('callservice',data);
        io.sockets.emit('callservice',data);
    });



    socket.on('reOrder',function (data) {
        socket.broadcast.emit('orders_reordered', data);
    });

    socket.on('undo',function (data) {
        socket.broadcast.emit('order_undo', data);
    });


    socket.on('timer',function (data) {
        io.sockets.emit('order_timer', data);
    });

    socket.on('flip',function (data) {
        io.sockets.emit('order_flipped', data);
    });

    socket.on('hold',function (data) {
        io.sockets.emit('order_hold', data);
    });

    socket.on('hide_station',function (data) {
        io.sockets.emit('station_hidden', data);
    });
    socket.on('mute_kitchen',function (data) {
        console.log('event kitchen sound')
        io.sockets.emit('mute_kitchen', data);


    });

    //update
    socket.on('notify',function (data) {
        //socket.broadcast.emit('updateRequire', data);
        io.sockets.emit('updateRequire', data);
    });

});




















